﻿// Copyright (c) Microsoft Corporation and Contributors.
// Licensed under the MIT License.

using Microsoft.UI;
using Microsoft.UI.Windowing;
using Microsoft.UI.Xaml;
using System;
using WinRT.Interop;

namespace Fees_DBASC
{
    public partial class App : Application
    {
        public App()
        {
            this.InitializeComponent();
        }

        protected override void OnLaunched(Microsoft.UI.Xaml.LaunchActivatedEventArgs args)
        {
            ApplicationWindow = new MainWindow();
            IntPtr handle = WindowNative.GetWindowHandle(ApplicationWindow);

            AppWindow appWindow = AppWindow.GetFromWindowId(Win32Interop.GetWindowIdFromWindow(handle));
            OverlappedPresenter presenter = (OverlappedPresenter)appWindow.Presenter;

            presenter.Maximize();
            ApplicationWindow.Activate();
        }

        public Window ApplicationWindow
        {
            get;
            private set;
        }
    }
}
