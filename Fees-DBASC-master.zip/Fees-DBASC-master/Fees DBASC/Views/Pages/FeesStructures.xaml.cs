// Copyright (c) Microsoft Corporation and Contributors.
// Licensed under the MIT License.

using CommunityToolkit.WinUI;
using Fees_DBASC.Core.Authentication;
using Fees_DBASC.Core.Database;
using Fees_DBASC.Core.Routing;
using Fees_DBASC.Data.Models;
using Fees_DBASC.Data.Sources;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Input;
using MySql.Data.MySqlClient;
using Org.BouncyCastle.Asn1.X509;
using System;
using System.Diagnostics;
using System.Linq;
using System.Reflection.Emit;
using System.Reflection;
using System.Threading.Tasks;
using System.Collections.Generic;
using Fees_DBASC.Core.Exceptions;

namespace Fees_DBASC.Views.Pages
{
    public sealed partial class FeesStructures : Page
    {
        private IncrementalLoadingCollection<FeesStructureDataSource, FeesData> collection;
        private FeesStructureDataSource feesStructureDataSource;
        private List<string> academicYears;

        public FeesStructures()
        {
            this.InitializeComponent();
        }

        private void PageLoaded(object sender, RoutedEventArgs e)
        {
            HandleUserRoleType();
            academicYears = new();
            LoadAcademicYears();
        }

        private async void LoadAcademicYears()
        {
            await Task.Run(async () =>
            {
                try
                {
                    using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                    await connection.OpenAsync();

                    MySqlCommand command = connection.CreateCommand();
                    command.CommandText = "SELECT DISTINCT academic_year as academicYear from fees_structure;";
                    await command.ExecuteNonQueryAsync();

                    using MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync();

                    if(reader.HasRows)
                    {
                        while (await reader.ReadAsync())
                        {
                            int academicYearOrdinal = reader.GetOrdinal("academicYear");
                            string academicYear = reader.IsDBNull(academicYearOrdinal) ? null : reader.GetString(academicYearOrdinal);
                            academicYears.Add(academicYear);
                        }

                        await reader.CloseAsync();
                    }
                    else
                    {
                        await reader.CloseAsync();
                        throw new EmptyFeesStructureException("No Fees Structures are added yet");
                    }
                }
                catch (Exception e)
                {
                    Debug.WriteLine(e.Message);
                    throw;
                }
            }).ContinueWith(async t =>
            {
                if (t.Exception != null)
                { 
                    EmptyListMessage.Visibility = Visibility.Visible;
                    FeesStructureList.Visibility = Visibility.Collapsed;
                    ProgressBar.Visibility = Visibility.Collapsed;
                    AcademicYearList.IsEnabled = false;
                }
                else
                {
                    EmptyListMessage.Visibility = Visibility.Collapsed;
                    FeesStructureList.Visibility = Visibility.Visible;
                    AcademicYearList.IsEnabled = true;

                    AcademicYearList.ItemsSource = academicYears;
                    AcademicYearList.SelectedIndex = 0;

                    string selectedAcademicYear = AcademicYearList.SelectedItem.ToString();
                    await Task.Run(() =>
                    {
                        feesStructureDataSource = new FeesStructureDataSource();
                        feesStructureDataSource.SetAcademicYear(selectedAcademicYear);
                        collection = new IncrementalLoadingCollection<FeesStructureDataSource, FeesData>(feesStructureDataSource, 20, null, null, null);
                        collection.OnStartLoading += CollectionLoading;
                        collection.OnEndLoading += CollectionLoaded;
                        collection.OnError += OnError;
                    });

                    FeesStructureList.ItemsSource = collection;
                    await FeesStructureList.LoadMoreItemsAsync();
                }

            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        private void HandleUserRoleType()
        {
            if (GlobalUserRole.Role == 0)
            {
                AddFeesStructureButton.Visibility = Visibility.Collapsed;
                Edit.Visibility = Visibility.Collapsed;
                Delete.Visibility = Visibility.Collapsed;
            }
            else if(GlobalUserRole.Role == 2)
            {
                AddFeesStructureButton.Visibility = Visibility.Collapsed;
                Edit.Visibility = Visibility.Collapsed;
                Delete.Visibility = Visibility.Collapsed;
            }
        }

        private void CollectionLoaded()
        {
            Task.Delay(800).ContinueWith(t =>
            {
                ProgressBar.Visibility = Visibility.Collapsed;
                ProgressBar.IsIndeterminate = false;
            }, TaskScheduler.FromCurrentSynchronizationContext());

            if (SelectAllCheckbox.IsChecked == true)
            {
                FeesStructureList.SelectAll();
            }

            if (collection.Count <= 0 && ListErrorMessage.Visibility == Visibility.Collapsed)
            {
                EmptyListMessage.Visibility = Visibility.Visible;
            }
            else
            {
                EmptyListMessage.Visibility = Visibility.Collapsed;
            }
        }

        private void OnError(Exception e)
        {
            if (collection.Count > 0)
            {
                ListErrorMessage.Visibility = Visibility.Collapsed;
                ErrorInfoBar.Message = e.Message;
                ErrorInfoBar.IsOpen = true;
            }
            else
            {
                ListErrorMessage.Visibility = Visibility.Visible;
                ErrorMessage.Text = e.Message;
            }
        }

        private void CollectionLoading()
        {
            ProgressBar.IsIndeterminate = true;
            ProgressBar.Visibility = Visibility.Visible;
        }

        private void SelectAll(object sender, RoutedEventArgs e)
        {
            FeesStructureList.SelectAll();
        }

        private void UnSelectAll(object sender, RoutedEventArgs e)
        {
            FeesStructureList.SelectedItems.Clear();
        }

        private void FeesStructureListRightTapped(object sender, RightTappedRoutedEventArgs e)
        {
            ListView listView = (ListView)sender;
            Delete.IsEnabled = listView.SelectedItems.Count > 0;
            Edit.IsEnabled = listView.SelectedItems.Count == 1;
            View.IsEnabled = listView.SelectedItems.Count == 1;
            ContextMenu.ShowAt(listView, e.GetPosition(listView));
        }

        private void FeesStructureListSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (FeesStructureList.SelectedItems.Count <= 0)
            {
                SelectAllCheckbox.IsChecked = false;
            }
            else if (collection.Count == FeesStructureList.SelectedItems.Count)
            {
                SelectAllCheckbox.IsChecked = true;
            }
            else if (collection.Count > FeesStructureList.SelectedItems.Count)
            {
                SelectAllCheckbox.IsChecked = null;
            }
        }

        private void ViewFeesStructureClick(object sender, RoutedEventArgs e)
        {
            if (FeesStructureList.SelectedItems.Count == 1)
            {
                FeesData feesData = FeesStructureList.SelectedItem as FeesData;
                NavigationService.Navigate(this, new ViewFeesStructure(), feesData);
            }
        }

        private async void DeleteFeesStructure(object sender, RoutedEventArgs e)
        {
            var result = await DeleteConfirmDialog.ShowAsync();
            if (result == ContentDialogResult.Primary)
            {
                if (SelectAllCheckbox.IsChecked == true)
                {
                    HandleDeleteFeesStructure(false);
                }
                else
                {
                    HandleDeleteFeesStructure(false);
                }
            }
        }

        private async void HandleDeleteFeesStructure(bool deleteAll)
        {
            var coursesToRemove = FeesStructureList.SelectedItems.Cast<FeesData>().Join(collection, c => c.Id, ci => ci.Id, (c, ci) => ci).ToList();
            string idList = string.Join(",", coursesToRemove.Select(x => x.Id));

            await Task.Run(async () =>
            {
                using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                await connection.OpenAsync();

                MySqlCommand command = connection.CreateCommand();
                MySqlTransaction transaction = connection.BeginTransaction();
                command.Connection = connection;
                command.Transaction = transaction;

                // Add additional remove options here
                try
                {
                    if (deleteAll)
                    {
                        command.CommandText = "TRUNCATE TABLE fees_structure;";
                        await command.ExecuteNonQueryAsync();
                    }
                    else
                    {
                        command.CommandText = $"DELETE FROM fees_structure WHERE id in({idList});";
                        await command.ExecuteNonQueryAsync();
                    }

                    await transaction.CommitAsync();
                }
                catch (Exception)
                {
                    transaction.Rollback();
                    throw;
                }
            }).ContinueWith(t =>
            {
                if (t.Exception != null)
                {
                    InfoBar.IsOpen = false;
                    ErrorInfoBar.IsOpen = true;
                    ErrorInfoBar.Message = t.Exception.Message;
                }
                else
                {
                    int selectedItemsCount = FeesStructureList.SelectedItems.Count;
                    coursesToRemove.ForEach(c => collection.Remove(c));
                    FeesStructureList.UpdateLayout();

                    ErrorInfoBar.IsOpen = false;
                    InfoBar.IsOpen = true;
                    InfoBar.Title = "Delete Fees Structure";

                    if (selectedItemsCount > 1)
                    {
                        InfoBar.Message = $"{selectedItemsCount} Fees Structures has been removed.";
                    }
                    else
                    {
                        InfoBar.Message = $"{selectedItemsCount} Fees Structure has been removed.";
                    }

                    if (collection.Count <= 0)
                    {
                        EmptyListMessage.Visibility = Visibility.Visible;
                    }
                    else
                    {
                        EmptyListMessage.Visibility = Visibility.Collapsed;
                    }
                }
            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        private void AddFeesStructureClicked(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(this, new UploadFeesStructure());
        }

        private void EditFeesStructureClicked(object sender, RoutedEventArgs e)
        {
            if (FeesStructureList.SelectedItems.Count == 1)
            {
                FeesData feesData = FeesStructureList.SelectedItem as FeesData;
                NavigationService.Navigate(this, new EditFeesStructures(), feesData);
            }
        }

        private async void AcademicYearListSelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            ComboBox yearSelector = sender as ComboBox;
            string selectedYear = yearSelector.SelectedItem.ToString();
            await Task.Run(() =>
            {
                feesStructureDataSource = new FeesStructureDataSource();
                feesStructureDataSource.SetAcademicYear(selectedYear);
                collection = new IncrementalLoadingCollection<FeesStructureDataSource, FeesData>(feesStructureDataSource, 20, null, null, null);
                collection.OnStartLoading += CollectionLoading;
                collection.OnEndLoading += CollectionLoaded;
                collection.OnError += OnError;
            });

            FeesStructureList.ItemsSource = collection;
            await FeesStructureList.LoadMoreItemsAsync();
        }
    }
}
