// Copyright (c) Microsoft Corporation and Contributors.
// Licensed under the MIT License.

using Fees_DBASC.Core.Routing;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Controls.Primitives;
using Microsoft.UI.Xaml.Data;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Navigation;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;

// To learn more about WinUI, the WinUI project structure,
// and more about our project templates, see: http://aka.ms/winui-project-info.

namespace Fees_DBASC.Views.Pages
{
    public sealed partial class UploadStudentDetails : Page
    {
        public UploadStudentDetails()
        {
            this.InitializeComponent();
        }

        private void InduvidualStudentUploadClick(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(this, new InduvidualStudentUpload());
        }

        private void StudentGroupUploadClick(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(this, new StudentGroupUpload());
        }
    }
}
