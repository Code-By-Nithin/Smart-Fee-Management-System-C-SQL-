using Fees_DBASC.Core.Database;
using Fees_DBASC.Core.Exceptions;
using Fees_DBASC.Core.Generators;
using Fees_DBASC.Core.Printing;
using Fees_DBASC.Data.Models;
using Fees_DBASC.Data.Parsers;
using Google.Protobuf.WellKnownTypes;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Navigation;
using MySql.Data.MySqlClient;
using Newtonsoft.Json.Linq;
using System;
using System.Buffers;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Transactions;
using Windows.ApplicationModel;
using Windows.Data.Json;
using Windows.Networking.Vpn;

namespace Fees_DBASC.Views.Pages
{
    public sealed partial class Report : Page
    {
        private DateTime date;
        private List<FeesReportSource> feesReportSources;
        private List<FeesReport> feesReports;
        private List<Bank> banks;

        public Report()
        {
            this.InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);
            if (e.Parameter != null && e.Parameter is DateTimeOffset date)
            {
                this.date = date.Date;
                feesReportSources = new();
                banks = new();
                GetBankDetails();
            }
        }

        private async void GetBankDetails()
        {
            await Task.Run(async () =>
            {
                try
                {
                    using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                    await connection.OpenAsync();

                    MySqlCommand command = connection.CreateCommand();
                    command.CommandText = "SELECT * from banks";

                    using MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync();
                    while (await reader.ReadAsync())
                    {
                        int idOrdinal = reader.GetOrdinal("id");
                        int nameOrdinal = reader.GetOrdinal("name");
                        int accountNumber = reader.GetOrdinal("account_number");
                        int ifscOrdinal = reader.GetOrdinal("ifsc_code");
                        int dateOrdinal = reader.GetOrdinal("date");

                        Bank bank = new()
                        {
                            Id = reader.IsDBNull(idOrdinal) ? 0 : reader.GetInt32(idOrdinal),
                            Name = reader.IsDBNull(nameOrdinal) ? null : reader.GetString(nameOrdinal),
                            AccountNumber = reader.IsDBNull(accountNumber) ? null : reader.GetString(accountNumber),
                            IFSCCode = reader.IsDBNull(ifscOrdinal) ? null : reader.GetString(ifscOrdinal),
                            Date = reader.IsDBNull(dateOrdinal) ? DateTime.Now : reader.GetDateTime(dateOrdinal),
                        };

                        banks.Add(bank);
                    }
                    await reader.CloseAsync();
                }
                catch (Exception e)
                {
                    Debug.WriteLine(e.Message);
                    throw;
                }
            }).ContinueWith(t =>
            {
                if (t.Exception != null)
                {
                    ReportError.IsOpen = true;
                    ReportError.Message = t.Exception.Message;
                }
                else
                {
                    GetPaymentDetails(date.Date);
                }

            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        public async void GetPaymentDetails(DateTime requestedDate)
        {
            List<Payment> payments = new();

            await Task.Run(async () =>
            {
                try
                {
                    using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                    await connection.OpenAsync();

                    MySqlCommand command = connection.CreateCommand();
                    command.CommandText = "SELECT p.*,c.name as course_name,r.id as receipt_id FROM payments p JOIN courses c ON p.course_id = c.id JOIN receipts r ON r.payment_id = p.id where DATE(p.date)=@date";
                    command.Parameters.AddWithValue("@date", requestedDate);

                    using MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync();
                    while (await reader.ReadAsync())
                    {
                        int idOrdinal = reader.GetOrdinal("id");
                        int studentIdOrdinal = reader.GetOrdinal("student_id");
                        int courseIdOrdinal = reader.GetOrdinal("course_id");
                        int amountOrdinal = reader.GetOrdinal("amount");
                        int semesterOrdinal = reader.GetOrdinal("semester");
                        int paymentMethodOrdinal = reader.GetOrdinal("payment_method");
                        int bankIdOrdinal = reader.GetOrdinal("bank_id");
                        int dateOrdinal = reader.GetOrdinal("date");
                        int courseNameOrdinal = reader.GetOrdinal("course_name");
                        int receiptIdOrdinal = reader.GetOrdinal("receipt_id");
                        int fineOrdinal = reader.GetOrdinal("fine");
                        int partialOrdinal = reader.GetOrdinal("partial");

                        Payment payment = new()
                        {
                            Id = reader.IsDBNull(idOrdinal) ? 0 : reader.GetInt32(idOrdinal),
                            StudentId = reader.IsDBNull(studentIdOrdinal) ? 0 : reader.GetInt32(studentIdOrdinal),
                            Amount = reader.IsDBNull(amountOrdinal) ? 0 : reader.GetDouble(amountOrdinal),
                            CourseId = reader.IsDBNull(courseIdOrdinal) ? 0 : reader.GetInt32(courseIdOrdinal),
                            Semester = reader.IsDBNull(semesterOrdinal) ? 0 : reader.GetInt32(semesterOrdinal),
                            PaymentMethod = reader.IsDBNull(paymentMethodOrdinal) ? null : reader.GetString(paymentMethodOrdinal),
                            CourseName = reader.IsDBNull(courseNameOrdinal) ? null : reader.GetString(courseNameOrdinal),
                            BankId = reader.IsDBNull(bankIdOrdinal) ? 0 : reader.GetInt32(bankIdOrdinal),
                            Date = reader.IsDBNull(dateOrdinal) ? DateTime.Now : reader.GetDateTime(dateOrdinal),
                            Fine = reader.IsDBNull(fineOrdinal) ? 0 : reader.GetDouble(fineOrdinal),
                            ReceiptId = reader.IsDBNull(receiptIdOrdinal) ? null : reader.GetString(receiptIdOrdinal),
                            Partial = !reader.IsDBNull(partialOrdinal) && reader.GetBoolean(partialOrdinal),
                        };

                        payments.Add(payment);
                    }
                    await reader.CloseAsync();
                }
                catch (Exception e)
                {
                    Debug.WriteLine(e.Message);
                    throw;
                }
            }).ContinueWith(t =>
            {
                if (t.Exception != null)
                {
                    ReportError.IsOpen = true;
                    ReportError.Message = t.Exception.Message;
                }
                else
                {
                    GetFeesStructures(payments);
                }

            }, TaskScheduler.FromCurrentSynchronizationContext());
        }


        public async void GetFeesStructures(List<Payment> payments)
        {
            List<FeesData> feesStructures = new();

            await Task.Run(async () =>
            {
                try
                {
                    using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                    await connection.OpenAsync();

                    foreach (Payment payment in payments)
                    {
                        MySqlCommand command = connection.CreateCommand();
                        command.CommandText = "SELECT fs.*,s.academic_year FROM fees_structure fs JOIN students s ON fs.academic_year = s.academic_year AND s.id=@studentId where fs.course_id=@courseId AND fs.active=1";
                        command.Parameters.AddWithValue("@studentId", payment.StudentId);
                        command.Parameters.AddWithValue("@courseId", payment.CourseId);

                        using MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync();

                        if(reader.HasRows)
                        {
                            while (await reader.ReadAsync())
                            {
                                int idOrdinal = reader.GetOrdinal("id");
                                int courseIdOrdinal = reader.GetOrdinal("course_id");
                                int dateOrdinal = reader.GetOrdinal("date");
                                int academicYearOrdinal = reader.GetOrdinal("academic_year");
                                int activeOrdinal = reader.GetOrdinal("active");
                                int jsonOrdinal = reader.GetOrdinal("data");

                                FeesData feesData = new()
                                {
                                    Id = reader.IsDBNull(idOrdinal) ? 0 : reader.GetInt32(idOrdinal),
                                    CourseId = reader.IsDBNull(courseIdOrdinal) ? 0 : reader.GetInt32(courseIdOrdinal),
                                    Date = reader.IsDBNull(dateOrdinal) ? DateTime.Now : reader.GetDateTime(dateOrdinal),
                                    AcademicYear = reader.IsDBNull(academicYearOrdinal) ? "" : reader.GetString(academicYearOrdinal),
                                    Active = !reader.IsDBNull(activeOrdinal) && reader.GetBoolean(activeOrdinal),
                                    Json = reader.IsDBNull(jsonOrdinal) ? "" : reader.GetString(jsonOrdinal),
                                };

                                FeesReportSource feesReport = new()
                                {
                                    Payment = payment,
                                    FeesStructure = feesData
                                };

                                feesStructures.Add(feesData);
                                feesReportSources.Add(feesReport);
                            }
                        }
                        else
                        {
                            throw new FeesStructureUnavailableException("Sorry the fees structure of this date is currently not avilable.");
                        }

                        await reader.CloseAsync();
                    }
                }
                catch (Exception e)
                {
                    Debug.WriteLine(e.Message);
                    throw;
                }
            }).ContinueWith(t =>
            {
                if (t.Exception != null)
                {
                    ProgressBar.Visibility = Visibility.Collapsed;
                    if(t.Exception.InnerException!=null)
                    {
                        ReportError.IsOpen = true;
                        ReportError.Message = t.Exception.InnerException.Message;
                    }
                    else
                    {
                        ReportError.IsOpen = true;
                        ReportError.Message = t.Exception.Message;
                    }
                }
                else
                {
                    ParseFeesReport(feesReportSources);
                }

            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        static void SetValuesToZero(JToken token)
        {
            /* 
             * Zero out the entire fees structure including serial number
             * 
            if (token is JValue value)
            {
                value.Replace(0);
            }
            else if (token is JContainer container)
            {
                foreach (var child in container.Children())
                {
                    Debug.WriteLine(child);
                    SetValuesToZero(child);
                }
            }
            */

            if (token is JValue value)
            {
                value.Replace(0);
            }
            else if (token is JContainer container)
            {
                foreach (var child in container.Children())
                {
                    if (token is JProperty property)
                    {
                        if (property.Name != "label" && property.Name != "serialNumber")
                        {
                            SetValuesToZero(child);
                        }
                    }
                    else
                    {
                        SetValuesToZero(child);
                    }
                }
            }
        }

        private string ZeroOutFeesStructure(string json)
        {
            JToken root = JToken.Parse(json);
            SetValuesToZero(root);
            return root.ToString();
        }

        //This function merges the data if all parameters are equal such as Semster,Academic Year,Course,Payment Method
        private void ParseFeesReport(List<FeesReportSource> source)
        {
            feesReports = new();
            feesReports.Clear();

            foreach (var sourceItem in source)
            {
                Payment payment = sourceItem.Payment;
                FeesData feesStructure = sourceItem.FeesStructure;
                FeesReport feesReport = null;

                


                if (payment.Partial)
                {
                    if (payment.PaymentMethod == "Cash")
                    {
                        feesReport = feesReports.FirstOrDefault(fr => fr.Semester == payment.Semester && fr.Course == payment.CourseId && fr.PaymentMethod == payment.PaymentMethod && fr.AcademicYear == feesStructure.AcademicYear && fr.IsPartialPayment == payment.Partial);
                    }
                    else
                    {
                        feesReport = feesReports.FirstOrDefault(fr => fr.Semester == payment.Semester && fr.Course == payment.CourseId && fr.PaymentMethod == payment.PaymentMethod && fr.AcademicYear == feesStructure.AcademicYear && fr.Bank == payment.BankId && fr.IsPartialPayment == payment.Partial);
                    }

                    if (feesReport != null)
                    {
                        feesReport.Count++;
                        feesReport.PartialPaymentCount++;
                        feesReport.Reference += "," + payment.Id;
                        feesReport.Fine += payment.Fine;
                        feesReport.IsPartialPayment = true;
                        feesReport.PartialPayment += payment.Amount;
                    }
                    else
                    {
                        feesReport = new FeesReport()
                        {
                            Date = date,
                            Semester = payment.Semester,
                            SourceFeesData = ZeroOutFeesStructure(feesStructure.Json),
                            CourseName = payment.CourseName,
                            Course = payment.CourseId,
                            PaymentMethod = payment.PaymentMethod,
                            Count = 1,
                            PartialPaymentCount = 1,
                            Bank = payment.BankId,
                            Fine = payment.Fine,
                            PartialPayment = payment.Amount,
                            IsPartialPayment = true,
                            BankName = banks.Where(item => item.Id == payment.BankId).Select(item => item.Name).FirstOrDefault(),
                            AcademicYear = feesStructure.AcademicYear,
                            Reference = payment.ReceiptId
                        };

                        feesReports.Add(feesReport);
                    }
                }
                else
                {
                    if (payment.PaymentMethod == "Cash")
                    {
                        feesReport = feesReports.FirstOrDefault(fr => fr.Semester == payment.Semester && fr.Course == payment.CourseId && fr.PaymentMethod == payment.PaymentMethod && fr.AcademicYear == feesStructure.AcademicYear && fr.IsPartialPayment == payment.Partial);
                    }
                    else
                    {
                        feesReport = feesReports.FirstOrDefault(fr => fr.Semester == payment.Semester && fr.Course == payment.CourseId && fr.PaymentMethod == payment.PaymentMethod && fr.AcademicYear == feesStructure.AcademicYear && fr.Bank == payment.BankId && fr.IsPartialPayment == payment.Partial);
                    }

                    Debug.WriteLine("Not Partial");
                    if (feesReport != null)
                    {
                        Debug.WriteLine("Not Partial not null");
                        feesReport.Count++;
                        feesReport.Reference += "," + payment.Id;
                        feesReport.Fine += payment.Fine;
                    }
                    else
                    {
                        Debug.WriteLine("Not Partial  null");
                        feesReport = new FeesReport()
                        {
                            Date = date,
                            Semester = payment.Semester,
                            SourceFeesData = feesStructure.Json,
                            CourseName = payment.CourseName,
                            Course = payment.CourseId,
                            PaymentMethod = payment.PaymentMethod,
                            Count = 1,
                            PartialPaymentCount = 0,
                            Bank = payment.BankId,
                            Fine = payment.Fine,
                            IsPartialPayment = false,
                            BankName = banks.Where(item => item.Id == payment.BankId).Select(item => item.Name).FirstOrDefault(),
                            AcademicYear = feesStructure.AcademicYear,
                            Reference = payment.ReceiptId
                        };

                        feesReports.Add(feesReport);
                    }
                }
            }


            foreach (var feesReport in feesReports)
            {
                if(feesReport.IsPartialPayment)
                {
                    feesReport.ReportData = feesReport.SourceFeesData;
                }
                else
                {
                    if (feesReport.Count > 1)
                    {
                        feesReport.ReportData = FeesReportParser.Multiply(feesReport.SourceFeesData, feesReport.Count);
                    }
                    else
                    {
                        feesReport.ReportData = feesReport.SourceFeesData;
                    }
                }


                //Minify the data
                feesReport.ReportData = MergeCategories(MinifyJson(feesReport.ReportData, feesReport.Semester));
            }

            RenderReport(feesReports);

        }

        void print_r(List<FeesReport> rpt)
        {
            foreach(FeesReport rp in rpt)
            {
                Debug.WriteLine(rp.CourseName);
                Debug.WriteLine(rp.PartialPayment);
                Debug.WriteLine("===============================================\n");
            }
        }

        private static List<FeesReport> SortListViewItems(string propertyName, ListSortDirection direction, List<FeesReport> source)
        {
            PropertyDescriptor propDesc = TypeDescriptor.GetProperties(typeof(FeesReport)).Find(propertyName, false);

            if (propDesc != null)
            {
                var groupedData = source.GroupBy(p => p.Semester).ToList();

                groupedData = direction == ListSortDirection.Ascending
                    ? groupedData.OrderBy(g => propDesc.GetValue(g.First())).ToList()
                    : groupedData.OrderByDescending(g => propDesc.GetValue(g.First())).ToList();

                List<FeesReport> sortedData = new();
                foreach (var group in groupedData)
                {
                    sortedData.AddRange(group);
                }

                return sortedData;
            }

            return new List<FeesReport>();
        }


        private void RenderReport(List<FeesReport> reports)
        {
            List<FeesReport> cashReports = new();
            List<FeesReport> bankReports = new();

            foreach (var report in reports)
            {
                if (report.PaymentMethod == "Cash")
                {
                    cashReports.Add(report);
                }
                else if (report.PaymentMethod == "Bank")
                {
                    bankReports.Add(report);
                }
            }

            cashReports = GroupByCourse(cashReports);
            bankReports = GroupByCourse(bankReports);

            BankPaymentsList.ItemsSource = SortListViewItems("Semester", ListSortDirection.Ascending, bankReports);
            CashPaymentsList.ItemsSource = SortListViewItems("Semester", ListSortDirection.Ascending, cashReports);

            ProgressBar.Visibility = Visibility.Collapsed;

            if(bankReports.Count > 0)
            {
                BankPaymentsEmptyMessage.Visibility = Visibility.Collapsed;
                PrintBankReportBtn.IsEnabled = true;
                PreviewBankReportBtn.IsEnabled = true;
            }
            else
            {
                BankPaymentsEmptyMessage.Visibility = Visibility.Visible;
                PrintBankReportBtn.IsEnabled = false;
                PreviewBankReportBtn.IsEnabled = false;
            }

            if (cashReports.Count > 0)
            {
                CashPaymentsEmptyMessage.Visibility = Visibility.Collapsed;
                PrintCashReportBtn.IsEnabled = true;
                PreviewCashReportBtn.IsEnabled = true;
            }
            else
            {
                CashPaymentsEmptyMessage.Visibility = Visibility.Visible;
                PrintCashReportBtn.IsEnabled = false;
                PreviewCashReportBtn.IsEnabled = false;
            }
        }

        private static string MinifyJson(string json, int semester)
        {
            Dictionary<string, object> feesStructure = JsonSerializer.Deserialize<Dictionary<string, object>>(json);

            foreach (var row in feesStructure)
            {
                Dictionary<string, object> rowData = JsonSerializer.Deserialize<Dictionary<string, object>>(row.Value.ToString());

                foreach (var cell in rowData)
                {
                    if (cell.Key == "fees")
                    {
                        Dictionary<string, object> semesters = JsonSerializer.Deserialize<Dictionary<string, object>>(cell.Value.ToString());
                        rowData["fees"] = semesters[$"sem{semester}"];
                    }
                    else if (cell.Key == "categories")
                    {
                        List<Dictionary<string, object>> feesList = JsonSerializer.Deserialize<List<Dictionary<string, object>>>(cell.Value.ToString());
                        foreach (var item in feesList)
                        {
                            foreach (var cellItem in item)
                            {
                                if (cellItem.Key == "fees")
                                {
                                    Dictionary<string, object> semesters = JsonSerializer.Deserialize<Dictionary<string, object>>(cellItem.Value.ToString());
                                    item["fees"] = semesters[$"sem{semester}"];
                                }
                            }
                        }

                        rowData["categories"] = feesList;
                    }
                }
                feesStructure[row.Key] = rowData;
            }

            return JsonSerializer.Serialize(feesStructure);
        }

        private static string MergeCategories(string json)
        {
            JsonDocument jsonDocument = JsonDocument.Parse(json);
            Dictionary<string, object> modifiedJson = new();

            foreach (JsonProperty property in jsonDocument.RootElement.EnumerateObject())
            {
                JsonElement parentCategory = property.Value;
                Dictionary<string, object> modifiedParentCategory = new();

                if (parentCategory.TryGetProperty("categories", out JsonElement categoriesArray))
                {
                    double totalFees = 0;
                    foreach (JsonElement category in categoriesArray.EnumerateArray())
                    {
                        double fees = 0;
                        if (category.TryGetProperty("fees", out JsonElement feesElement) && feesElement.ValueKind == JsonValueKind.Number)
                        {
                            fees = category.GetProperty("fees").GetDouble();
                        }
                        else if (category.TryGetProperty("fees", out JsonElement feesItem) && feesItem.ValueKind == JsonValueKind.String)
                        {
                            fees = double.Parse(category.GetProperty("fees").GetString());
                        }

                        totalFees += fees;
                    }

                    modifiedParentCategory["fees"] = totalFees.ToString();
                }

                foreach (JsonProperty parentProperty in parentCategory.EnumerateObject())
                {
                    if (parentProperty.Name != "categories")
                    {
                        modifiedParentCategory[parentProperty.Name] = parentProperty.Value.ToString();
                    }
                }

                modifiedJson[property.Name] = modifiedParentCategory;
            }

            return JsonSerializer.Serialize(modifiedJson);
        }

        private async void PrintReport(List<FeesReport> source,string paymentMethod)
        {
            ProgressBar.Visibility = Visibility.Visible;
            PrintBankReportBtn.IsEnabled = false;
            PrintCashReportBtn.IsEnabled = false;
            PreviewCashReportBtn.IsEnabled = false;
            PreviewBankReportBtn.IsEnabled = false;

            await Task.Run(async () =>
            {
                using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                await connection.OpenAsync();

                MySqlTransaction transaction = connection.BeginTransaction();

                try
                {
                    MySqlCommand deleteCommand = connection.CreateCommand();
                    deleteCommand.CommandText = "DELETE FROM reports WHERE DATE(date)=@date AND payment_method=@payment_method";
                    deleteCommand.Parameters.AddWithValue("@date", date);
                    deleteCommand.Parameters.AddWithValue("@payment_method", paymentMethod);
                    await deleteCommand.ExecuteNonQueryAsync();

                    foreach (var report in source)
                    {
                        MySqlCommand insertCommand = connection.CreateCommand();
                        insertCommand.CommandText = "INSERT INTO reports (date,count,course,course_name,academic_year,semester,payment_method,source_fees_data,reference,report_data) VALUES(@date,@count,@course,@course_name,@academic_year,@semester,@payment_method,@source_fees_data,@reference,@report_data)";
                        insertCommand.Parameters.AddWithValue("@date", report.Date);
                        insertCommand.Parameters.AddWithValue("@count", report.Count);
                        insertCommand.Parameters.AddWithValue("@course", report.Course);
                        insertCommand.Parameters.AddWithValue("@course_name", report.CourseName);
                        insertCommand.Parameters.AddWithValue("@academic_year", report.AcademicYear);
                        insertCommand.Parameters.AddWithValue("@semester", report.Semester);
                        insertCommand.Parameters.AddWithValue("@payment_method", report.PaymentMethod);
                        insertCommand.Parameters.AddWithValue("@source_fees_data", report.SourceFeesData);
                        insertCommand.Parameters.AddWithValue("@reference", report.Reference);
                        insertCommand.Parameters.AddWithValue("@report_data", report.ReportData);
                        await insertCommand.ExecuteNonQueryAsync();

                        MySqlCommand fetchIdCommand = connection.CreateCommand();
                        fetchIdCommand.CommandText = "SELECT LAST_INSERT_ID();";
                        report.Id = Convert.ToInt32(await fetchIdCommand.ExecuteScalarAsync());
                    }

                    transaction.Commit();
                }
                catch (Exception e)
                {
                    transaction.Rollback();
                    Debug.WriteLine(e.Message);
                    throw;
                }
            }).ContinueWith(async t =>
            {
                if (t.Exception != null)
                {
                    ProgressBar.Visibility = Visibility.Collapsed;
                    Debug.WriteLine(t.Exception.Message);
                    ReportError.IsOpen = true;
                    ReportError.Message = t.Exception.Message;
                }
                else
                {
                    ReportError.IsOpen = false;

                    await Task.Run(async () =>
                    {
                        ReportGenerator receiptGenerator = new();
                        //string path = Path.Combine(Package.Current.InstalledLocation.Path, "Reports", paymentMethod);
                        string path = Path.Combine(@"C:\", "Reports", paymentMethod);
                        if (Directory.Exists(path))
                        {
                            path = $"{path}\\Report-{date:dd-MM-yyyy}.pdf";
                            receiptGenerator.GenerateReport(source, path);
                        }
                        else
                        {
                            try
                            {
                                Directory.CreateDirectory(path);
                                path = $"{path}\\Report-{date:dd-MM-yyyy}.pdf";
                                receiptGenerator.GenerateReport(source, path);
                            }
                            catch (Exception ex)
                            {
                                Debug.WriteLine(ex.Message);
                                throw;
                            }
                        }

                        PrintRouter printRouter = new();
                        await printRouter.SendForPrinting(path);
                    }).ContinueWith(t =>
                    {
                        ProgressBar.Visibility = Visibility.Collapsed;
                        if (t.Exception != null)
                        {
                            ReportError.IsOpen = true;
                            ReportError.Message = t.Exception.Message;
                        }
                        else
                        {
                            PrintBankReportBtn.IsEnabled = true;
                            PrintCashReportBtn.IsEnabled = true;

                            PreviewCashReportBtn.IsEnabled = true;
                            PreviewBankReportBtn.IsEnabled = true;
                        }
                    }, TaskScheduler.FromCurrentSynchronizationContext());
                }

            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        private List<FeesReport> GroupByCourse(List<FeesReport> reports)
        {
            List<FeesReport> finalizedReport = new();
            var groupedReports = reports.GroupBy(reportData => reportData.Course);

            foreach (var group in groupedReports)
            {
                List<FeesReport> reportGroupList = group.ToList();
                
                FeesReport addedReport = null;
                foreach (FeesReport report in reportGroupList)
                {
                    if (addedReport == null)
                    {
                        addedReport = new FeesReport()
                        {
                            Id = report.Id,
                            Date = report.Date,
                            Count = report.Count,
                            Course = report.Course,
                            CourseName = report.CourseName,
                            AcademicYear = report.AcademicYear,
                            Semester = report.Semester,
                            PaymentMethod = report.PaymentMethod,
                            Bank = report.Bank,
                            BankName = report.BankName,
                            SourceFeesData = report.SourceFeesData,
                            Reference = report.Reference,
                            Fine = report.Fine,
                            PartialPayment = report.PartialPayment,
                            ReportData = report.ReportData,
                            Semesters = report.Semester.ToString(),
                            AcademicYears = report.AcademicYear,
                            PaymentsReceived = report.Count
                        };

                    }
                    else
                    {
                        addedReport.ReportData =  FeesReportParser.MergeJson(addedReport.ReportData.ToString(), report.ReportData.ToString());

                        if (!addedReport.Semesters.Contains(report.Semester.ToString()))
                        {
                            addedReport.Semesters += "," + report.Semester;
                        }

                        if (!addedReport.AcademicYears.Contains(report.AcademicYear.ToString()))
                        {
                            addedReport.AcademicYears += "," + report.AcademicYear;
                        }

                        addedReport.Fine += report.Fine;
                        addedReport.PartialPayment += report.PartialPayment;
                        addedReport.Reference += "," + report.Reference;
                        addedReport.PaymentsReceived += report.Count;
                    }
                }

                finalizedReport.Add(addedReport);
            }

            return finalizedReport;
        }

        private void PrintBankReport(object sender, RoutedEventArgs e)
        {
            List<FeesReport> bankReports = new();

            foreach (var report in feesReports)
            {
                if (report.PaymentMethod == "Bank")
                {
                    bankReports.Add(report);
                }
            }

            bankReports = GroupByCourse(bankReports);
            PrintReport(bankReports, "Bank");
        }


        private void PrintCashReport(object sender, RoutedEventArgs e)
        {
            List<FeesReport> cashReports = new();

            foreach (var report in feesReports)
            {
                if (report.PaymentMethod == "Cash")
                {
                    cashReports.Add(report);
                }
            }


            cashReports = GroupByCourse(cashReports);

            PrintReport(cashReports, "Cash");
        }

        private async void LoadPaymentsList(string referenceId)
        {
            List<ReportPayments> paymentsList = new();
            await Task.Run(async () =>
            {
                try
                {
                    using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                    await connection.OpenAsync();

                    MySqlCommand command = connection.CreateCommand();
                    command.CommandText = $"SELECT r.*,s.student_name as student_name,c.name as course_name,s.academic_year from receipts r LEFT JOIN students s on s.id = r.student_id LEFT JOIN courses c on c.id = r.course_id WHERE r.id in ({referenceId})";

                    using MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync();
                    while (await reader.ReadAsync())
                    {
                        int idOrdinal = reader.GetOrdinal("id");
                        int nameOrdinal = reader.GetOrdinal("student_name");
                        int semesterOrdinal = reader.GetOrdinal("semester");
                        int courseOrdinal = reader.GetOrdinal("course_name");
                        int courseIdOrdinal = reader.GetOrdinal("course_id");
                        int academicYearOrdinal = reader.GetOrdinal("academic_year");

                        ReportPayments payment = new()
                        {
                            Id = reader.IsDBNull(idOrdinal) ? -1 : reader.GetInt32(idOrdinal),
                            Name = reader.IsDBNull(nameOrdinal) ? null : reader.GetString(nameOrdinal),
                            Semester = ", Semester " + (reader.IsDBNull(semesterOrdinal) ? 0 : reader.GetInt32(semesterOrdinal).ToString()),
                            Course = reader.IsDBNull(courseOrdinal) ? null : reader.GetString(courseOrdinal),
                            CourseId = reader.IsDBNull(courseIdOrdinal) ? -1 : reader.GetInt32(courseIdOrdinal),
                            AcademicYear = ", Academic Year " + (reader.IsDBNull(academicYearOrdinal) ? null : reader.GetString(academicYearOrdinal).ToString()),
                        };

                        paymentsList.Add(payment);
                    }

                }
                catch (Exception e)
                {
                    Debug.WriteLine(e.Message);
                    throw;
                }
            }).ContinueWith(t =>
            {
                if (t.Exception != null)
                {
                    Debug.WriteLine(t.Exception.Message);
                    ReportError.IsOpen = true;
                    ReportError.Message = t.Exception.Message;
                }
                else
                {
                    ReportError.IsOpen = false;
                    DialogPaymentsList.ItemsSource = paymentsList;
                }

            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        private async void CashPaymentsListDoubleTapped(object sender, Microsoft.UI.Xaml.Input.DoubleTappedRoutedEventArgs e)
        {
            var fees = CashPaymentsList.SelectedItem as FeesReport;
            PaymentsListDialog.Title = "Cash Payments";
            LoadPaymentsList(fees.Reference);
            await PaymentsListDialog.ShowAsync();
        }

        private async void BankPaymentsListDoubleTapped(object sender, Microsoft.UI.Xaml.Input.DoubleTappedRoutedEventArgs e)
        {
            var fees = BankPaymentsList.SelectedItem as FeesReport;
            PaymentsListDialog.Title = "Bank Payments";
            LoadPaymentsList(fees.Reference);
            await PaymentsListDialog.ShowAsync();
        }

        private async void PreviewCashReport(object sender, RoutedEventArgs e)
        {
            PrintBankReportBtn.IsEnabled = false;
            PrintCashReportBtn.IsEnabled = false;

            PreviewCashReportBtn.IsEnabled = false;
            PreviewBankReportBtn.IsEnabled = false;

            ProgressBar.Visibility = Visibility.Visible;

            List<FeesReport> cashReports = new();

            foreach (var report in feesReports)
            {
                if (report.PaymentMethod == "Cash")
                {
                    report.Id = 0;
                    cashReports.Add(report);
                }
            }

            cashReports = GroupByCourse(cashReports);

            ReportError.IsOpen = false;

            await Task.Run(async () =>
            {
                ReportGenerator receiptGenerator = new();
                string path = Path.Combine(@"C:\","Reports","Previews", "Cash");
                if (Directory.Exists(path))
                {
                    path = $"{path}\\Report-Preview.pdf";
                    receiptGenerator.GenerateReport(cashReports, path,true);
                }
                else
                {
                    try
                    {
                        Directory.CreateDirectory(path);
                        path = $"{path}\\Report-Preview.pdf";
                        receiptGenerator.GenerateReport(cashReports, path, true);
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine(ex.Message);
                        throw;
                    }
                }

                PrintRouter printRouter = new();
                await printRouter.SendForPrinting(path);
            }).ContinueWith(t =>
            {
                ProgressBar.Visibility = Visibility.Collapsed;
                if (t.Exception != null)
                {
                    ReportError.IsOpen = true;
                    ReportError.Message = t.Exception.Message;
                }
                else
                {
                    PrintBankReportBtn.IsEnabled = true;
                    PrintCashReportBtn.IsEnabled = true;

                    PreviewCashReportBtn.IsEnabled = true;
                    PreviewBankReportBtn.IsEnabled = true;
                }
            }, TaskScheduler.FromCurrentSynchronizationContext());

        }

        private async void PreviewBankReport(object sender, RoutedEventArgs e)
        {
            PrintBankReportBtn.IsEnabled = false;
            PrintCashReportBtn.IsEnabled = false;

            PreviewCashReportBtn.IsEnabled = false;
            PreviewBankReportBtn.IsEnabled = false;

            ProgressBar.Visibility = Visibility.Visible;

            List<FeesReport> bankReports = new();

            foreach (var report in feesReports)
            {
                if (report.PaymentMethod == "Bank")
                {
                    report.Id = 0;
                    bankReports.Add(report);
                }
            }

            bankReports = GroupByCourse(bankReports);

            ReportError.IsOpen = false;

            await Task.Run(async () =>
            {
                ReportGenerator receiptGenerator = new();
                string path = Path.Combine(@"C:\", "Reports", "Previews", "Bank");
                if (Directory.Exists(path))
                {
                    path = $"{path}\\Report-Preview.pdf";
                    receiptGenerator.GenerateReport(bankReports, path, true);
                }
                else
                {
                    try
                    {
                        Directory.CreateDirectory(path);
                        path = $"{path}\\Report-Preview.pdf";
                        receiptGenerator.GenerateReport(bankReports, path, true);
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine(ex.Message);
                        throw;
                    }
                }

                PrintRouter printRouter = new();
                await printRouter.SendForPrinting(path);
            }).ContinueWith(t =>
            {
                ProgressBar.Visibility = Visibility.Collapsed;
                if (t.Exception != null)
                {
                    ReportError.IsOpen = true;
                    ReportError.Message = t.Exception.Message;
                }
                else
                {
                    PrintBankReportBtn.IsEnabled = true;
                    PrintCashReportBtn.IsEnabled = true;

                    PreviewCashReportBtn.IsEnabled = true;
                    PreviewBankReportBtn.IsEnabled = true;
                }
            }, TaskScheduler.FromCurrentSynchronizationContext());
        }
    }
}