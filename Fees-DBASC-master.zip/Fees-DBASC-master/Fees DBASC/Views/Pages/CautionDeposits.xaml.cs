using CommunityToolkit.WinUI;
using Fees_DBASC.Core.Authentication;
using Fees_DBASC.Core.Database;
using Fees_DBASC.Core.Generators;
using Fees_DBASC.Core.Printing;
using Fees_DBASC.Data.Models;
using Fees_DBASC.Data.Sources;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Controls.Primitives;
using Microsoft.UI.Xaml.Data;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Navigation;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.Foundation.Collections;

namespace Fees_DBASC.Views.Pages
{

    public sealed partial class CautionDeposits : Page
    {
        private IncrementalLoadingCollection<CautionDepositDataSource, CautionDeposit> collection;
        private CautionDepositDataSource cautionDepositDataSource;
        private ObservableCollection<CautionDeposit> pagedItems;
        private bool isSearching = false;
        private int userRole = 0;

        public CautionDeposits()
        {
            this.InitializeComponent();
        }

        private async void PageLoaded(object sender, RoutedEventArgs e)
        {
            userRole = GlobalUserRole.Role;
            if(userRole != 1)
            {
                HideRefundButton = true;
            }
            await Task.Run(() =>
            {
                cautionDepositDataSource = new CautionDepositDataSource();
                collection = new IncrementalLoadingCollection<CautionDepositDataSource, CautionDeposit>(cautionDepositDataSource, 20, null, null, null);
                collection.OnStartLoading += CollectionLoading;
                collection.OnEndLoading += CollectionLoaded;
                collection.OnError += OnError;
            });

            CautionDepositList.ItemsSource = collection;
            await CautionDepositList.LoadMoreItemsAsync();
        }

        private void CollectionLoaded()
        {
            Debug.WriteLine("Searching:" + isSearching);

            Task.Delay(800).ContinueWith(t =>
            {
                ProgressBar.Visibility = Visibility.Collapsed;
                ProgressBar.IsIndeterminate = false;
            }, TaskScheduler.FromCurrentSynchronizationContext());

            if (SelectAllCheckbox.IsChecked == true)
            {
                CautionDepositList.SelectAll();
            }

            if (collection.Count <= 0 && ListErrorMessage.Visibility == Visibility.Collapsed)
            {
                EmptyListMessage.Visibility = Visibility.Visible;
            }
            else
            {
                EmptyListMessage.Visibility = Visibility.Collapsed;
            }
        }

        private void OnError(Exception e)
        {
            if (collection.Count > 0)
            {
                ListErrorMessage.Visibility = Visibility.Collapsed;
                ErrorInfoBar.Message = e.Message;
                ErrorInfoBar.IsOpen = true;
            }
            else
            {
                ListErrorMessage.Visibility = Visibility.Visible;
                ErrorMessage.Text = e.Message;
            }
        }

        private void CollectionLoading()
        {
            ProgressBar.IsIndeterminate = true;
            ProgressBar.Visibility = Visibility.Visible;
        }

        private void SelectAll(object sender, RoutedEventArgs e)
        {
            CautionDepositList.SelectAll();
        }

        private void UnSelectAll(object sender, RoutedEventArgs e)
        {
            CautionDepositList.SelectedItems.Clear();
        }

        private void CautionDepositListSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CautionDepositList.SelectedItems.Count <= 0)
            {
                SelectAllCheckbox.IsChecked = false;
            }
            else if (collection.Count == CautionDepositList.SelectedItems.Count)
            {
                SelectAllCheckbox.IsChecked = true;
            }
            else if (collection.Count > CautionDepositList.SelectedItems.Count)
            {
                SelectAllCheckbox.IsChecked = null;
            }
        }

        private void CautionDepositListRightTapped(object sender, RightTappedRoutedEventArgs e)
        {
            if (GlobalUserRole.Role != 0)
            {
                ListView listView = (ListView)sender;
            }
        }

        private async void AutoSuggestBoxTextChanged(AutoSuggestBox sender, AutoSuggestBoxTextChangedEventArgs args)
        {
            string searchQuery = searchBox.Text;
            CancellationToken cancellationToken = default;

            if (searchQuery.Length > 0)
            {
                int id = -1;
                if (int.TryParse(searchQuery, out id))
                {
                    cautionDepositDataSource.EmptyCollection();
                    cautionDepositDataSource.Search(searchQuery, 0);
                    pagedItems = new(await cautionDepositDataSource.GetPagedItemsAsync(0, 40, cancellationToken));
                    CautionDepositList.ItemsSource = pagedItems.ToList();
                    isSearching = true;
                }
                else
                {
                    cautionDepositDataSource.EmptyCollection();
                    cautionDepositDataSource.Search(searchQuery, 1);
                    pagedItems = new(await cautionDepositDataSource.GetPagedItemsAsync(0, 40, cancellationToken));
                    CautionDepositList.ItemsSource = pagedItems.ToList();
                    isSearching = true;
                }
            }
            else
            {

                cautionDepositDataSource.Search(null, -1);
                await Task.Run(() =>
                {
                    cautionDepositDataSource = new CautionDepositDataSource();
                    collection = new IncrementalLoadingCollection<CautionDepositDataSource, CautionDeposit>(cautionDepositDataSource, 20, null, null, null);
                    collection.OnStartLoading += CollectionLoading;
                    collection.OnEndLoading += CollectionLoaded;
                    collection.OnError += OnError;
                });
                isSearching = false;
                CautionDepositList.ItemsSource = collection;
                await CautionDepositList.LoadMoreItemsAsync();
            }

        }

        private async void HandleCautionRefund(object sender, RoutedEventArgs e)
        {
            Button refundButton = sender as Button;
            int id = int.Parse(refundButton.Tag.ToString());

            await Task.Run(async () =>
            {
                try
                {
                    using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                    await connection.OpenAsync();

                    try
                    {
                        MySqlCommand command = connection.CreateCommand();
                        command.CommandText = "UPDATE students SET caution_refunded=1, caution_refund_date= CURRENT_TIMESTAMP WHERE id=@id";
                        command.Parameters.AddWithValue("id", id);
                        await command.ExecuteScalarAsync();
                    }
                    catch (Exception e)
                    {
                        Debug.WriteLine(e.Message);
                        throw;
                    }

                }
                catch (Exception e)
                {
                    Debug.WriteLine(e.Message);
                    throw;
                }
            }).ContinueWith(t =>
            {
                if(t.Exception !=null)
                {
                    ErrorInfoBar.Message = t.Exception.Message;
                    ErrorInfoBar.IsOpen = true;
                }
                else
                {
                    AutoSuggestBoxTextChanged(null,null);
                }

            }, TaskScheduler.FromCurrentSynchronizationContext());
        }


        #region Dependency Property

        public bool HideRefundButton
        {
            get { return (bool)GetValue(HideRefuncButtonProperty); }
            set { SetValue(HideRefuncButtonProperty, value); }
        }
        
        public static readonly DependencyProperty HideRefuncButtonProperty =  DependencyProperty.Register("HideRefundButton", typeof(bool), typeof(CautionDeposit), new PropertyMetadata(false));

        #endregion

        private void HideOnUserRole(object sender, RoutedEventArgs e)
        {
            if(sender is Button)
            {
                Button refundButton = sender as Button;
                if (userRole != 1)
                {
                    refundButton.Visibility = Visibility.Collapsed;
                }
            }
            else if(sender is TextBlock)
            {
                TextBlock refundLabel = sender as TextBlock;
                if (userRole != 1)
                {
                    refundLabel.Visibility = Visibility.Collapsed;
                }
            }
            else if (sender is Grid)
            {
                Grid wrapper = sender as Grid;
                if (userRole != 1)
                {
                    wrapper.ColumnDefinitions.RemoveAt(6);
                }
            }
        }
    }
}
