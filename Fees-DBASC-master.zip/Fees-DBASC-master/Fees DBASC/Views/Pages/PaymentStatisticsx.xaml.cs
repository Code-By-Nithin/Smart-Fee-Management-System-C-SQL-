// Copyright (c) Microsoft Corporation and Contributors.
// Licensed under the MIT License.

using Fees_DBASC.Controls;
using Fees_DBASC.Core.Database;
using Fees_DBASC.Core.Exceptions;
using Fees_DBASC.Data.Models;
using K4os.Compression.LZ4.Internal;
using Microsoft.UI;
using Microsoft.UI.Text;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;
using MySql.Data.MySqlClient;
using MySqlX.XDevAPI.Common;
using MySqlX.XDevAPI.Relational;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using Windows.ApplicationModel.Payments;
using Windows.UI;
using Windows.UI.Text;

// To learn more about WinUI, the WinUI project structure,
// and more about our project templates, see: http://aka.ms/winui-project-info.

namespace Fees_DBASC.Views.Pages
{
    public sealed partial class PaymentStatisticsx : Page
    {
        private readonly List<Course> courses;
        private readonly List<string> academicYears;

        public PaymentStatisticsx()
        {
            this.InitializeComponent();
            courses = new();
            academicYears = new();
        }

        private void PageLoaded(object sender, RoutedEventArgs e)
        {
            LoadCourseDetails();
        }

        private async void LoadCourseDetails()
        {
            await Task.Run(async () =>
            {
                try
                {
                    using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                    await connection.OpenAsync();

                    MySqlCommand command = connection.CreateCommand();
                    command.CommandText = "SELECT * FROM courses";

                    using MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync();
                    while (await reader.ReadAsync())
                    {
                        int idOrdinal = reader.GetOrdinal("id");
                        int nameOrdinal = reader.GetOrdinal("name");
                        int semestersOrdinal = reader.GetOrdinal("semesters");
                        int timestampOrdinal = reader.GetOrdinal("timestamp");
                        int typeOrdinal = reader.GetOrdinal("type");

                        Course course = new()
                        {
                            Id = reader.IsDBNull(idOrdinal) ? -1 : reader.GetInt32(idOrdinal),
                            Name = reader.IsDBNull(nameOrdinal) ? null : reader.GetString(nameOrdinal),
                            Semesters = reader.IsDBNull(semestersOrdinal) ? 0 : reader.GetInt32(semestersOrdinal),
                            Timestamp = reader.IsDBNull(timestampOrdinal) ? DateTime.Now : reader.GetDateTime(timestampOrdinal),
                            Type = reader.IsDBNull(typeOrdinal) ? -1 : reader.GetInt32(typeOrdinal),
                        };

                        courses.Add(course);
                    }
                    await reader.CloseAsync();
                }
                catch (Exception e)
                {
                    Debug.WriteLine(e.Message);
                    throw;
                }
            }).ContinueWith(t =>
            {
                ProgressBar.Visibility = Visibility.Collapsed;
                CourseList.IsEnabled = true;

                if (t.Exception != null)
                {
                    ErrorInfoBar.IsOpen = true;
                    ErrorInfoBar.Message = t.Exception.Message;
                }
                else
                {
                    ErrorInfoBar.IsOpen = false;
                    if (courses.Count > 0)
                    {
                        CourseList.ItemsSource = courses;
                    }
                }

            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        private async void LoadAcademicYear(int courseId)
        {
            ProgressBar.Visibility = Visibility.Visible;
            AcademicYearList.IsEnabled = false;
            CourseList.IsEnabled = false;
            GetDetailsBtn.IsEnabled = false;

            await Task.Run(async () =>
            {
                try
                {
                    using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                    await connection.OpenAsync();

                    MySqlCommand command = connection.CreateCommand();
                    command.CommandText = "SELECT DISTINCT academic_year FROM students WHERE course_id=@id";
                    command.Parameters.AddWithValue("id", courseId);

                    using MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync();

                    academicYears.Clear();
                    while (await reader.ReadAsync())
                    {
                        int academicYearOrdinal = reader.GetOrdinal("academic_year");
                        academicYears.Add(reader.IsDBNull(academicYearOrdinal) ? null : reader.GetString(academicYearOrdinal));
                    }
                    await reader.CloseAsync();
                }
                catch (Exception e)
                {
                    Debug.WriteLine(e.Message);
                    throw;
                }
            }).ContinueWith(t =>
            {
                ProgressBar.Visibility = Visibility.Collapsed;
                CourseList.IsEnabled = true;

                if (t.Exception != null)
                {
                    ErrorInfoBar.IsOpen = true;
                    ErrorInfoBar.Message = t.Exception.Message;
                }
                else
                {
                    ErrorInfoBar.IsOpen = false;
                    if (academicYears.Count > 0)
                    {
                        ErrorInfoBar.IsOpen = false;
                        AcademicYearList.Items.Clear();
                        foreach(var item in academicYears)
                        {
                            AcademicYearList.Items.Add(item);
                        }

                        AcademicYearList.IsEnabled = true;
                        GetDetailsBtn.IsEnabled = true;
                        AcademicYearList.SelectedIndex = 0;
                    }
                    else
                    {
                        AcademicYearList.IsEnabled = false;
                        ErrorInfoBar.IsOpen = true;
                        ErrorInfoBar.Message = "There is no students added to this course, please select another courese and try again";
                    }
                }

            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        private static string GetSemesterFees(FeesData feesData, int semester)
        {
            double total = 0;
            Dictionary<string, object> feesStructure = JsonSerializer.Deserialize<Dictionary<string, object>>(feesData.Json);

            foreach (var row in feesStructure)
            {
                Dictionary<string, object> rowData = JsonSerializer.Deserialize<Dictionary<string, object>>(row.Value.ToString());
                foreach (var keyValuePair in rowData)
                {
                    if (!string.IsNullOrEmpty(keyValuePair.Key) && keyValuePair.Key == "fees")
                    {
                        Dictionary<string, object> fees = JsonSerializer.Deserialize<Dictionary<string, object>>(keyValuePair.Value.ToString());
                        foreach (var fee in fees)
                        {
                            if (fee.Key == $"sem{semester}")
                            {
                                total += Double.Parse(fee.Value.ToString());
                            }
                        }
                    }
                    else if (!string.IsNullOrEmpty(keyValuePair.Key) && keyValuePair.Key == "categories")
                    {
                        List<Dictionary<string, object>> categories = JsonSerializer.Deserialize<List<Dictionary<string, object>>>(keyValuePair.Value.ToString());

                        foreach (var category in categories)
                        {
                            foreach (var item in category)
                            {
                                if (!string.IsNullOrEmpty(item.Key) && item.Key == "fees")
                                {
                                    Dictionary<string, object> fees = JsonSerializer.Deserialize<Dictionary<string, object>>(item.Value.ToString());
                                    foreach (var fee in fees)
                                    {
                                        if (fee.Key == $"sem{semester}")
                                        {
                                            total += double.Parse(fee.Value.ToString());
                                        }
                                    }
                                }
                            }
                        }
                    }

                }
            }
            return total.ToString();
        }

        private async void LoadPaymentsDetails(Course course, string academicYear, FeesData feesData)
        {
            List<Payment> payments = new();

            ProgressBar.Visibility = Visibility.Visible;
            CourseList.IsEnabled = false;
            AcademicYearList.IsEnabled = false;
            GetDetailsBtn.IsEnabled = false;

            await Task.Run(async () =>
            {
                try
                {
                    using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                    await connection.OpenAsync();

                    MySqlCommand command = connection.CreateCommand();
                    //command.CommandText = "SELECT p.*,s.student_name as student_name from payments p JOIN students s on s.id = p.student_id where s.course_id=@id";
                    command.CommandText = "SELECT s.*,p.* from students s LEFT JOIN payments p ON p.student_id = s.id where s.course_id=@id and s.academic_year=@academic_year ORDER BY s.id";
                    command.Parameters.AddWithValue("@id", course.Id);
                    command.Parameters.AddWithValue("@academic_year", academicYear);
                    using MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync();
                    while (await reader.ReadAsync())
                    {
                        int idOrdinal = reader.GetOrdinal("id");
                        int studentIdOrdinal = reader.GetOrdinal("student_id");
                        int courseIdOrdinal = reader.GetOrdinal("course_id");
                        int amountOrdinal = reader.GetOrdinal("amount");
                        int semesterOrdinal = reader.GetOrdinal("semester");
                        int paymentMethodOrdinal = reader.GetOrdinal("payment_method");
                        int bankIdOrdinal = reader.GetOrdinal("bank_id");
                        int dateOrdinal = reader.GetOrdinal("date");
                        int studentNameOrdinal = reader.GetOrdinal("student_name");
                        int partialOrdinal = reader.GetOrdinal("partial");

                        Payment payment = new()
                        {
                            Id = reader.IsDBNull(idOrdinal) ? 0 : reader.GetInt32(idOrdinal),
                            StudentId = reader.IsDBNull(studentIdOrdinal) ? 0 : reader.GetInt32(studentIdOrdinal),
                            Amount = reader.IsDBNull(amountOrdinal) ? 0 : reader.GetDouble(amountOrdinal),
                            CourseId = reader.IsDBNull(courseIdOrdinal) ? 0 : reader.GetInt32(courseIdOrdinal),
                            Semester = reader.IsDBNull(semesterOrdinal) ? 0 : reader.GetInt32(semesterOrdinal),
                            PaymentMethod = reader.IsDBNull(paymentMethodOrdinal) ? null : reader.GetString(paymentMethodOrdinal),
                            BankId = reader.IsDBNull(bankIdOrdinal) ? 0 : reader.GetInt32(bankIdOrdinal),
                            Date = reader.IsDBNull(dateOrdinal) ? DateTime.Now : reader.GetDateTime(dateOrdinal),
                            StudentName = reader.IsDBNull(studentNameOrdinal) ? "" : reader.GetString(studentNameOrdinal),
                            Partial = reader.IsDBNull(partialOrdinal) ? false : reader.GetBoolean(partialOrdinal),
                        };

                        var semester = reader.IsDBNull(semesterOrdinal) ? 0 : reader.GetInt32(semesterOrdinal);
                        if(semester!=0)
                        {
                            payment.TotalFees = double.Parse(GetSemesterFees(feesData, semester));
                        }

                        payments.Add(payment);
                    }
                    await reader.CloseAsync();
                }
                catch (Exception e)
                {
                    Debug.WriteLine(e.Message);
                    throw;
                }
            }).ContinueWith(t =>
            {
                CourseList.IsEnabled = true;
                AcademicYearList.IsEnabled = true;
                GetDetailsBtn.IsEnabled = true;

                if (t.Exception != null)
                {
                    ErrorInfoBar.IsOpen = true;
                    ErrorInfoBar.Message = t.Exception.Message;
                }
                else
                {
                    ErrorInfoBar.IsOpen = false;
                    List<PaymentStatisticsModel> statistics = new();

                    foreach (var payment in payments)
                    {
                        var item = statistics.FirstOrDefault(s => s.Id == payment.Id);
                        if (item != null)
                        {
                            if (payment.Partial)
                            {
                                if(item.SemestersPartiallyPaid!=null)
                                {
                                    item.SemestersPartiallyPaid += "," + payment.Semester;
                                }
                                else
                                {
                                    item.SemestersPartiallyPaid += payment.Semester;
                                }
                            }

                            item.SemestersPaid += "," + payment.Semester;
                        }
                        else
                        {
                            statistics.Add(new PaymentStatisticsModel()
                            {
                                Name = payment.StudentName,
                                StudentId = payment.StudentId,
                                Id = payment.Id,
                                SemestersPaid = payment.Semester.ToString(),
                                SemestersPartiallyPaid = (payment.Partial) ? payment.Semester.ToString() : null
                            });
                        }
                    }

                    RenderPaymentDetails(statistics,course,payments);
                    ProgressBar.Visibility = Visibility.Collapsed;
                }

            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        private async void LoadFeeDetails(Course course, string academicYear)
        {
            FeesData feesData = null;
            await Task.Run(async () =>
            {
                try
                {
                    using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                    await connection.OpenAsync();

                    MySqlCommand command = connection.CreateCommand();
                    command.CommandText = "SELECT * FROM fees_structure WHERE course_id=@course AND academic_year=@academic_year AND active=1";
                    command.Parameters.AddWithValue("@course", course.Id);
                    command.Parameters.AddWithValue("@academic_year", academicYear);
                    using MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync();

                    if (reader.HasRows)
                    {
                        while (await reader.ReadAsync())
                        {
                            int idOrdinal = reader.GetOrdinal("id");
                            int dataOrdinal = reader.GetOrdinal("data");
                            int academicYearOrdinal = reader.GetOrdinal("academic_year");
                            int courseIdOrdinal = reader.GetOrdinal("course_id");
                            int dateOrdinal = reader.GetOrdinal("date");

                            feesData = new()
                            {
                                Id = reader.IsDBNull(idOrdinal) ? 0 : reader.GetInt32(idOrdinal),
                                Json = reader.IsDBNull(dataOrdinal) ? null : reader.GetString(dataOrdinal),
                                AcademicYear = reader.IsDBNull(academicYearOrdinal) ? null : reader.GetString(academicYearOrdinal),
                                CourseId = reader.IsDBNull(courseIdOrdinal) ? 0 : reader.GetInt32(courseIdOrdinal),
                                Date = reader.IsDBNull(dateOrdinal) ? DateTime.Now : reader.GetDateTime(dateOrdinal),
                            };
                        }
                    }
                    else
                    {
                        throw new FeesStructureUnavailableException("Sorry a fees structure for current course and academic year is not active or available.");
                    }

                    await reader.CloseAsync();
                }
                catch (Exception e)
                {
                    Debug.WriteLine(e.Message);
                    throw;
                }
            }).ContinueWith(t =>
            {
                if (t.Exception != null)
                {
                    if (t.Exception.InnerException != null)
                    {
                        ErrorInfoBar.IsOpen = true;
                        ErrorInfoBar.Message = t.Exception.InnerException.Message;
                    }
                    else
                    {
                        ErrorInfoBar.IsOpen = true;
                        ErrorInfoBar.Message = t.Exception.Message;
                    }
                }
                else
                {
                    ErrorInfoBar.IsOpen = false;

                    if (feesData != null)
                    {
                        ErrorInfoBar.IsOpen = false;
                        LoadPaymentsDetails(course, academicYear, feesData);
                    }
                    else
                    {
                        ErrorInfoBar.IsOpen = true;
                        ErrorInfoBar.Message = "Sorry there is no fees structure associated with the student course and academic year";
                    }
                }

            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        private double GetPaidFees(List<Payment> transactions,int semester,int studentId)
        {
            double total=0;
            foreach(Payment payment in transactions)
            {
                if(payment.Semester == semester && payment.StudentId == studentId)
                {
                    total += payment.Amount;
                }
            }

            return total;
        }

        private double getCourseFees(List<Payment> transactions,int semester)
        {
            double fees = 0;
            foreach(Payment payment in transactions)
            {
                if(payment.Semester == semester)
                {
                    fees = payment.TotalFees;
                }
            }
            return fees;
        }

        private void RenderPaymentDetails(List<PaymentStatisticsModel> payments,Course course,List<Payment> transactions)
        {
            PaymetsDataWrap.Children.Clear();

            // Generate Header
            Grid header = new()
            {
                HorizontalAlignment = HorizontalAlignment.Stretch,
                Height = 50
            };

            header.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(50)});
            header.ColumnDefinitions.Add(new ColumnDefinition());

            TextBlock idHeader = new()
            {
                Text = "ID",
                HorizontalAlignment = HorizontalAlignment.Left,
                FontWeight = FontWeights.Medium,
                TextAlignment = TextAlignment.Center,
            };

            TextBlock nameHeader = new()
            {
                Text = "Student Name",
                HorizontalAlignment = HorizontalAlignment.Left,
                FontWeight = FontWeights.Medium
            };

            Grid.SetColumn(idHeader, 0);
            Grid.SetColumn(nameHeader, 1);

            header.Children.Add(idHeader);
            header.Children.Add(nameHeader);

            for (var i=1;i<=course.Semesters;i++)
            {
                header.ColumnDefinitions.Add(new ColumnDefinition());
                TextBlock semester = new()
                {
                    Text = $"Semester {i}",
                    HorizontalAlignment = HorizontalAlignment.Center,
                    FontWeight = FontWeights.Medium
                };
                header.Children.Add(semester);
                Grid.SetColumn(semester, i +1);
            }

            PaymetsDataWrap.RowDefinitions.Add(new RowDefinition() { Height=GridLength.Auto});
            PaymetsDataWrap.Children.Add(header);
            Grid.SetRow(header,0);

            //Render Cells
            PaymetsDataWrap.RowDefinitions.Add(new RowDefinition() { Height=GridLength.Auto});
            Grid contentContainer = new() 
            {
                HorizontalAlignment = HorizontalAlignment.Stretch,
                RowSpacing = 30
            };
            PaymetsDataWrap.Children.Add(contentContainer);
            Grid.SetRow(contentContainer, 1);


            int rowCount = 0;
            foreach (var payment in payments)
            {
                contentContainer.RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
                var row = new Grid()
                {
                    HorizontalAlignment = HorizontalAlignment.Stretch,
                };

                Grid.SetRow(row,rowCount);
                contentContainer.Children.Add(row);

                row.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(50)});
                TextBlock id = new()
                {
                    Text = payment.Id.ToString(),
                    HorizontalAlignment = HorizontalAlignment.Left
                };
                Grid.SetColumn(id,0);
                row.Children.Add(id);

                row.ColumnDefinitions.Add(new ColumnDefinition());
                TextBlock name = new()
                {
                    Text = payment.Name,
                    HorizontalAlignment = HorizontalAlignment.Left
                };
                Grid.SetColumn(name, 1);
                row.Children.Add(name);


                for (var i = 1; i <= course.Semesters; i++)
                {
                    var paidSemesters = (payment.SemestersPaid != null) ? payment.SemestersPaid.Split(',').ToList() : new List<string>();
                    var partiallyPaidSemesters = (payment.SemestersPartiallyPaid!=null)? payment.SemestersPartiallyPaid.Split(',').ToList():new List<string>();

                    paidSemesters = paidSemesters.Distinct().ToList();
                    partiallyPaidSemesters = partiallyPaidSemesters.Distinct().ToList();

                    if (paidSemesters.Contains($"{i}"))
                    { 
                        var courseFees = getCourseFees(transactions, i);
                        var totalPaid = GetPaidFees(transactions, i,payment.StudentId);
                        var balance = courseFees - totalPaid;

                        if (partiallyPaidSemesters.Contains($"{i}") && balance>0)
                        {
                            row.ColumnDefinitions.Add(new ColumnDefinition());
                            StatusButton semFee = new()
                            {
                                StatusText = "Partial",
                                GlyphBackground = new SolidColorBrush(Colors.Orange),
                                Glyph = "\ue915",
                                HorizontalAlignment = HorizontalAlignment.Center,
                            };
                            row.Children.Add(semFee);
                            Grid.SetColumn(semFee, i + 1);
                        }
                        else
                        {
                            row.ColumnDefinitions.Add(new ColumnDefinition());
                            StatusButton semFee = new()
                            {
                                StatusText = "Paid",
                                GlyphBackground = new SolidColorBrush((Color)Application.Current.Resources["SystemAccentColor"]),
                                Glyph = "\uf13e",
                                HorizontalAlignment = HorizontalAlignment.Center,
                            };
                            row.Children.Add(semFee);
                            Grid.SetColumn(semFee, i + 1);
                        }
                    }
                    else
                    {
                        row.ColumnDefinitions.Add(new ColumnDefinition());
                        StatusButton semFee = new()
                        {
                            StatusText = "Not Paid",
                            GlyphBackground = new SolidColorBrush(Colors.Red),
                            Glyph = "\uf13d",
                            HorizontalAlignment = HorizontalAlignment.Center,
                        };
                        row.Children.Add(semFee);
                        Grid.SetColumn(semFee, i + 1);
                    }
                }

                rowCount++;
            }

        }

        private void CourseListSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if(AcademicYearList.Items.Count > 0)
            {
                academicYears.Clear();
                AcademicYearList.SelectedItem = null;
            }
            Course course = CourseList.SelectedItem as Course;
            LoadAcademicYear(course.Id);
            
        }

        private void HandleGetDetails(object sender, RoutedEventArgs e)
        {
            var course = CourseList.SelectedItem as Course;

            if(course != null )
            {
                if(AcademicYearList.SelectedItem!=null)
                {
                    var academicYear = AcademicYearList.SelectedItem.ToString();
                    ErrorInfoBar.IsOpen = false;
                    LoadFeeDetails(course, academicYear);
                }
                else
                {
                    ErrorInfoBar.IsOpen = true;
                    ErrorInfoBar.Message = "Please Choose the Academic year to Continue";
                }
            }
            else
            {
                ErrorInfoBar.IsOpen = true;
                ErrorInfoBar.Message = "Please Choose the course to Continue";
            }
        }
    }
}
