// Copyright (c) Microsoft Corporation and Contributors.
// Licensed under the MIT License.

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Controls.Primitives;
using Microsoft.UI.Xaml.Data;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Navigation;
using System.Globalization;
using Windows.Globalization;
using Fees_DBASC.Core.Routing;
using Fees_DBASC.Data.Models;

// To learn more about WinUI, the WinUI project structure,
// and more about our project templates, see: http://aka.ms/winui-project-info.

namespace Fees_DBASC.Views.Pages
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class GenerateReport : Page
    {
        public GenerateReport()
        {
            this.InitializeComponent();
            ReportDatePicker.MaxDate = DateTime.Today;
            ReportDatePicker.CalendarIdentifier = CalendarIdentifiers.Gregorian;
            ReportDatePicker.DateFormat = "{day.integer(2)}-{month.integer(2)}-{year.full}";
        }

        private void GenerateReportClicked(object sender, RoutedEventArgs e)
        {
            if (ReportDatePicker.Date != null)
            {
                DateError.IsOpen = false;
                NavigationService.Navigate(this, new Report(), ReportDatePicker.Date);
            }
            else
            {
                DateError.IsOpen = true;
                DateError.Message = "Please select a valid date to continue";
            }

        }
    }
}
