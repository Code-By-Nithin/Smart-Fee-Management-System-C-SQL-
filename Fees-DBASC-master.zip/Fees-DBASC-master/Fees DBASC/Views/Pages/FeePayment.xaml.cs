﻿using Fees_DBASC.Controls;
using Fees_DBASC.Core.Database;
using Fees_DBASC.Core.Exceptions;
using Fees_DBASC.Core.Generators;
using Fees_DBASC.Core.Printing;
using Fees_DBASC.Data.Models;
using Microsoft.UI;
using Microsoft.UI.Text;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Media.Imaging;
using Microsoft.UI.Xaml.Navigation;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using Windows.ApplicationModel;
using Windows.UI;
using Windows.UI.Text;

namespace Fees_DBASC.Views.Pages
{
    public sealed partial class FeePayment : Page
    {
        private string studentId = null;
        private Student studentData;
        private Course courseData;
        private readonly List<Bank> banks = new();

        public FeePayment()
        {
            this.InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);
            if (e.Parameter != null && e.Parameter is string id)
            {
                studentId = id;
                searchBox.Text = studentId;
            }
        }

        private void PageLoaded(object sender, RoutedEventArgs e)
        {
            if (Application.Current.RequestedTheme == ApplicationTheme.Dark)
            {
                BitmapImage bitmapImage = new()
                {
                    UriSource = new Uri("ms-appx:///Assets/EmptyRecordDark.png")
                };

                EmptyRecordImage.Source = bitmapImage;
            }
            else
            {
                BitmapImage bitmapImage = new()
                {
                    UriSource = new Uri("ms-appx:///Assets/EmptyRecordLight.png")
                };

                EmptyRecordImage.Source = bitmapImage;
            }

            if (studentId != null)
            {
                FillStudentDetails(studentId);
                FetchBankDetails();
                searchBox.Focus(FocusState.Programmatic);
                searchBox.Select(searchBox.Text.Length, 0);
            }
        }

        private void PageThemeChanged(FrameworkElement sender, object args)
        {
            if (Application.Current.RequestedTheme == ApplicationTheme.Dark)
            {
                BitmapImage bitmapImage = new()
                {
                    UriSource = new Uri("ms-appx:///Assets/EmptyRecordDark.png")
                };

                EmptyRecordImage.Source = bitmapImage;
            }
            else
            {
                BitmapImage bitmapImage = new()
                {
                    UriSource = new Uri("ms-appx:///Assets/EmptyRecordLight.png")
                };

                EmptyRecordImage.Source = bitmapImage;
            }
        }

        private async void FillStudentDetails(string id)
        {
            Student student = null;

            await Task.Run(async () =>
            {
                try
                {
                    using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                    await connection.OpenAsync();

                    MySqlCommand command = connection.CreateCommand();
                    command.CommandText = "SELECT s.*,c.name as course_name,c.type as course_type FROM students s JOIN courses c ON s.course_id = c.id WHERE s.id=@id";
                    command.Parameters.AddWithValue("@id", id);

                    using MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync();
                    while (await reader.ReadAsync())
                    {
                        int courseNameOrdinal = reader.GetOrdinal("course_name");
                        int academicYearOrdinal = reader.GetOrdinal("academic_year");
                        int fathersNameOrdinal = reader.GetOrdinal("fathers_name");
                        int motherssNameOrdinal = reader.GetOrdinal("mothers_name");
                        int address1Ordinal = reader.GetOrdinal("address_line1");
                        int address2Ordinal = reader.GetOrdinal("address_line2");
                        int cityOrdinal = reader.GetOrdinal("city");
                        int stateOrdinal = reader.GetOrdinal("state");
                        int zipCodeOrdinal = reader.GetOrdinal("zip_code");
                        int phoneOrdinal = reader.GetOrdinal("phone");
                        int mobileOrdinal = reader.GetOrdinal("mobile");
                        int emailOrdinal = reader.GetOrdinal("email");
                        int courseIdOrdinal = reader.GetOrdinal("course_id");
                        int standardOrdinal = reader.GetOrdinal("standard");
                        int divisionOrdinal = reader.GetOrdinal("division");
                        int courseTypeOrdinal = reader.GetOrdinal("course_type");

                        student = new()
                        {
                            Id = reader.GetInt32("id"),
                            Name = reader.GetString("student_name"),
                            CourseName = reader.IsDBNull(courseNameOrdinal) ? null : reader.GetString(courseNameOrdinal),
                            AcademicYear = reader.IsDBNull(academicYearOrdinal) ? null : reader.GetString(academicYearOrdinal),
                            FathersName = reader.IsDBNull(fathersNameOrdinal) ? null : reader.GetString(fathersNameOrdinal),
                            MothersName = reader.IsDBNull(motherssNameOrdinal) ? null : reader.GetString(motherssNameOrdinal),
                            Address1 = reader.IsDBNull(address1Ordinal) ? null : reader.GetString(address1Ordinal),
                            Address2 = reader.IsDBNull(address2Ordinal) ? null : reader.GetString(address2Ordinal),
                            City = reader.IsDBNull(cityOrdinal) ? null : reader.GetString(cityOrdinal),
                            State = reader.IsDBNull(stateOrdinal) ? null : reader.GetString(stateOrdinal),
                            ZipCode = reader.IsDBNull(zipCodeOrdinal) ? null : reader.GetString(zipCodeOrdinal),
                            Phone = reader.IsDBNull(phoneOrdinal) ? null : reader.GetString(phoneOrdinal),
                            Mobile = reader.IsDBNull(mobileOrdinal) ? null : reader.GetString(mobileOrdinal),
                            Email = reader.IsDBNull(emailOrdinal) ? null : reader.GetString(emailOrdinal),
                            CourseId = reader.IsDBNull(courseIdOrdinal) ? 0 : reader.GetInt32(courseIdOrdinal),
                            CourseType = reader.IsDBNull(courseTypeOrdinal) ? 0 : reader.GetInt32(courseTypeOrdinal),
                            Standard = reader.IsDBNull(standardOrdinal) ? null : reader.GetString(standardOrdinal),
                            Division = reader.IsDBNull(divisionOrdinal) ? null : reader.GetString(divisionOrdinal),
                        };

                    }
                    await reader.CloseAsync();
                }
                catch (Exception e)
                {
                    Debug.WriteLine(e.Message);
                    throw;
                }
            }).ContinueWith(t =>
            {
                if (t.Exception != null)
                {
                    ErrorInfo.IsOpen = true;
                    ErrorInfo.Message = t.Exception.Message;
                }
                else
                {
                    ErrorInfo.IsOpen = false;

                    if (student != null)
                    {
                        studentData = student;
                        string courseType = (student.CourseType == 0) ? "Under Graduate" : "Post Graduate";
                        StudentName.Text = student.Name;
                        StudentCourse.Text = student.CourseName + " (" + courseType + "), " + student.AcademicYear + " Batch";

                        // Start Fetching student Fees Details
                        FetchCourseDetails(student);
                    }
                }

            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        private async void FetchCourseDetails(Student studentData)
        {
            Course course = null;
            await Task.Run(async () =>
            {
                try
                {
                    using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                    await connection.OpenAsync();

                    MySqlCommand command = connection.CreateCommand();
                    command.CommandText = "SELECT * FROM courses where id=@id";
                    command.Parameters.AddWithValue("@id", studentData.CourseId);

                    using MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync();
                    while (await reader.ReadAsync())
                    {
                        int semestersOrdinal = reader.GetOrdinal("semesters");
                        int TimestampOrdinal = reader.GetOrdinal("Timestamp");

                        course = new()
                        {
                            Id = studentData.CourseId,
                            Name = studentData.CourseName,
                            Semesters = reader.IsDBNull(semestersOrdinal) ? 0 : reader.GetInt32(semestersOrdinal),
                            Timestamp = reader.IsDBNull(TimestampOrdinal) ? DateTime.Now : reader.GetDateTime(TimestampOrdinal),
                        };
                    }
                    await reader.CloseAsync();
                }
                catch (Exception e)
                {
                    Debug.WriteLine(e.Message);
                    throw;
                }
            }).ContinueWith(t =>
            {
                if (t.Exception != null)
                {
                    ErrorInfo.IsOpen = true;
                    ErrorInfo.Message = t.Exception.Message;
                }
                else
                {
                    ErrorInfo.IsOpen = false;

                    if (course != null)
                    {
                        courseData = course;
                        FetchFeesStructure(studentData, course);
                    }
                }

            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        private async void FetchFeesStructure(Student student, Course course)
        {
            FeesData feesData = null;
            await Task.Run(async () =>
            {
                try
                {
                    using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                    await connection.OpenAsync();

                    MySqlCommand command = connection.CreateCommand();
                    command.CommandText = "SELECT * FROM fees_structure WHERE course_id=@course AND academic_year=@academic_year AND active=1";
                    command.Parameters.AddWithValue("@course", course.Id);
                    command.Parameters.AddWithValue("@academic_year", student.AcademicYear);
                    using MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync();

                    if(reader.HasRows)
                    {
                        while (await reader.ReadAsync())
                        {
                            int idOrdinal = reader.GetOrdinal("id");
                            int dataOrdinal = reader.GetOrdinal("data");
                            int academicYearOrdinal = reader.GetOrdinal("academic_year");
                            int courseIdOrdinal = reader.GetOrdinal("course_id");
                            int dateOrdinal = reader.GetOrdinal("date");

                            feesData = new()
                            {
                                Id = reader.IsDBNull(idOrdinal) ? 0 : reader.GetInt32(idOrdinal),
                                Json = reader.IsDBNull(dataOrdinal) ? null : reader.GetString(dataOrdinal),
                                AcademicYear = reader.IsDBNull(academicYearOrdinal) ? null : reader.GetString(academicYearOrdinal),
                                CourseId = reader.IsDBNull(courseIdOrdinal) ? 0 : reader.GetInt32(courseIdOrdinal),
                                Date = reader.IsDBNull(dateOrdinal) ? DateTime.Now : reader.GetDateTime(dateOrdinal),
                            };
                        }
                    }
                    else
                    {
                        throw new FeesStructureUnavailableException("Sorry a fees structure for current course and academic year is not active or available.");
                    }

                    await reader.CloseAsync();
                }
                catch (Exception e)
                {
                    Debug.WriteLine(e.Message);
                    throw;
                }
            }).ContinueWith(t =>
            {
                if (t.Exception != null)
                {
                    if(t.Exception.InnerException != null)
                    {
                        ErrorInfo.IsOpen = true;
                        ErrorInfo.Message = t.Exception.InnerException.Message;
                    }
                    else
                    {
                        ErrorInfo.IsOpen = true;
                        ErrorInfo.Message = t.Exception.Message;
                    }
                }
                else
                {
                    ErrorInfo.IsOpen = false;

                    if (feesData != null)
                    {
                        ErrorInfo.IsOpen = false;
                        FetchPaymentDetails(student, course, feesData);
                    }
                    else
                    {
                        ErrorInfo.IsOpen = true;
                        ErrorInfo.Message = "Sorry there is no fees structure associated with the student course and academic year";
                    }
                }

            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        private async void FetchPaymentDetails(Student student, Course course, FeesData feesData)
        {
            List<Payment> payments = new();

            await Task.Run(async () =>
            {
                try
                {
                    using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                    await connection.OpenAsync();

                    MySqlCommand command = connection.CreateCommand();
                    command.CommandText = "SELECT * FROM payments where student_id=@id";
                    command.Parameters.AddWithValue("@id", student.Id);
                    using MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync();
                    while (await reader.ReadAsync())
                    {
                        int idOrdinal = reader.GetOrdinal("id");
                        int studentIdOrdinal = reader.GetOrdinal("student_id");
                        int courseIdOrdinal = reader.GetOrdinal("course_id");
                        int amountOrdinal = reader.GetOrdinal("amount");
                        int semesterOrdinal = reader.GetOrdinal("semester");
                        int paymentMethodOrdinal = reader.GetOrdinal("payment_method");
                        int bankIdOrdinal = reader.GetOrdinal("bank_id");
                        int fineOrdinal = reader.GetOrdinal("fine");
                        int dateOrdinal = reader.GetOrdinal("date");

                        Payment payment = new()
                        {
                            Id = reader.IsDBNull(idOrdinal) ? 0 : reader.GetInt32(idOrdinal),
                            StudentId = reader.IsDBNull(studentIdOrdinal) ? 0 : reader.GetInt32(studentIdOrdinal),
                            Amount = reader.IsDBNull(amountOrdinal) ? 0 : reader.GetDouble(amountOrdinal),
                            CourseId = reader.IsDBNull(courseIdOrdinal) ? 0 : reader.GetInt32(courseIdOrdinal),
                            Semester = reader.IsDBNull(semesterOrdinal) ? 0 : reader.GetInt32(semesterOrdinal),
                            PaymentMethod = reader.IsDBNull(paymentMethodOrdinal) ? null : reader.GetString(paymentMethodOrdinal),
                            BankId = reader.IsDBNull(bankIdOrdinal) ? 0 : reader.GetInt32(bankIdOrdinal),
                            Date = reader.IsDBNull(dateOrdinal) ? DateTime.Now : reader.GetDateTime(dateOrdinal),
                            Fine = reader.IsDBNull(fineOrdinal) ? 0 : reader.GetDouble(fineOrdinal),
                        };

                        payments.Add(payment);
                    }
                    await reader.CloseAsync();
                }
                catch (Exception e)
                {
                    Debug.WriteLine(e.Message);
                    throw;
                }
            }).ContinueWith(t =>
            {
                if (t.Exception != null)
                {
                    ErrorInfo.IsOpen = true;
                    ErrorInfo.Message = t.Exception.Message;
                }
                else
                {
                    ErrorInfo.IsOpen = false;
                    RenderFeesDetails(course, feesData, payments);
                }

            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        private async void FetchBankDetails()
        {
            banks.Clear();
            await Task.Run(async () =>
            {
                try
                {
                    using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                    await connection.OpenAsync();

                    MySqlCommand command = connection.CreateCommand();
                    command.CommandText = "SELECT * FROM banks";
                    using MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync();

                    while (await reader.ReadAsync())
                    {
                        int idOrdinal = reader.GetOrdinal("id");
                        int nameOrdinal = reader.GetOrdinal("name");
                        int accountNumberIdOrdinal = reader.GetOrdinal("account_number");
                        int ifscCodeOrdinal = reader.GetOrdinal("ifsc_code");
                        int dateOrdinal = reader.GetOrdinal("date");

                        Bank bank = new()
                        {
                            Id = reader.IsDBNull(idOrdinal) ? 0 : reader.GetInt32(idOrdinal),
                            Name = reader.IsDBNull(nameOrdinal) ? null : reader.GetString(nameOrdinal),
                            AccountNumber = reader.IsDBNull(accountNumberIdOrdinal) ? null : reader.GetString(accountNumberIdOrdinal),
                            IFSCCode = reader.IsDBNull(ifscCodeOrdinal) ? null : reader.GetString(ifscCodeOrdinal),
                            Date = reader.IsDBNull(dateOrdinal) ? DateTime.Now : reader.GetDateTime(dateOrdinal),
                        };

                        banks.Add(bank);
                    }
                    await reader.CloseAsync();
                }
                catch (Exception e)
                {
                    Debug.WriteLine(e.Message);
                    throw;
                }
            }).ContinueWith(t =>
            {
                if (t.Exception != null)
                {
                    ErrorInfo.IsOpen = true;
                    ErrorInfo.Message = t.Exception.Message;
                }
                else
                {
                    ErrorInfo.IsOpen = false;
                }

            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        private static string GetSemesterFees(FeesData feesData, int semester)
        {
            double total = 0;
            Dictionary<string, object> feesStructure = JsonSerializer.Deserialize<Dictionary<string, object>>(feesData.Json);

            foreach (var row in feesStructure)
            {
                Dictionary<string, object> rowData = JsonSerializer.Deserialize<Dictionary<string, object>>(row.Value.ToString());
                foreach (var keyValuePair in rowData)
                {
                    if (!string.IsNullOrEmpty(keyValuePair.Key) && keyValuePair.Key == "fees")
                    {
                        Dictionary<string, object> fees = JsonSerializer.Deserialize<Dictionary<string, object>>(keyValuePair.Value.ToString());
                        foreach (var fee in fees)
                        {
                            if (fee.Key == $"sem{semester}")
                            {
                                total += Double.Parse(fee.Value.ToString());
                            }
                        }
                    }
                    else if (!string.IsNullOrEmpty(keyValuePair.Key) && keyValuePair.Key == "categories")
                    {
                        List<Dictionary<string, object>> categories = JsonSerializer.Deserialize<List<Dictionary<string, object>>>(keyValuePair.Value.ToString());

                        foreach (var category in categories)
                        {
                            foreach (var item in category)
                            {
                                if (!string.IsNullOrEmpty(item.Key) && item.Key == "fees")
                                {
                                    Dictionary<string, object> fees = JsonSerializer.Deserialize<Dictionary<string, object>>(item.Value.ToString());
                                    foreach (var fee in fees)
                                    {
                                        if (fee.Key == $"sem{semester}")
                                        {
                                            total += double.Parse(fee.Value.ToString());
                                        }
                                    }
                                }
                            }
                        }
                    }

                }
            }
            return total.ToString();
        }

        private static string GetFeePaymentDate(List<Payment> payments, int semester)
        {
            string date = "------";

            foreach (var payment in payments)
            {
                if (payment != null)
                {
                    if (payment.Semester == semester)
                    {
                        date = payment.Date.ToString("dd-MM-yyyy");
                    }
                }
            }

            return date;
        }

        private static string GetPaymentMethod(List<Payment> payments, int semester)
        {
            string paymentMethod = "------";

            foreach (var payment in payments)
            {
                if (payment != null)
                {
                    if (payment.Semester == semester)
                    {
                        paymentMethod = payment.PaymentMethod;
                    }
                }
            }

            return paymentMethod;
        }

        private static bool IsPaid(List<Payment> payments, int semester)
        {
            bool paid = false;

            foreach (var payment in payments)
            {
                if (payment != null)
                {
                    if (payment.Semester == semester)
                    {
                        return true;
                    }
                }
            }

            return paid;
        }

        private double GetPaidAmount(List<Payment> payments, int semester)
        {
            double totalPaid = 0;
            foreach(Payment payment in payments)
            {
                if(payment.Semester == semester)
                {
                    totalPaid += payment.Amount;
                }
            }

            return totalPaid;
        }

        private void RenderFeesDetails(Course course, FeesData feesData, List<Payment> payments)
        {
            EmptyMessage.Visibility = Visibility.Collapsed;
            FeesDetailsWrapper.Children.Clear();
            FeesDetailsWrapper.RowDefinitions.Clear();


            for (int i = 0; i < course.Semesters; i++)
            {
                FeesDetailsWrapper.RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });

                Expander expander = new()
                {
                    CornerRadius = new CornerRadius(8),
                    HorizontalAlignment = HorizontalAlignment.Stretch,
                    HorizontalContentAlignment = HorizontalAlignment.Stretch
                };

                Grid semesterFeeInfo = new()
                {
                    Padding = new Thickness(15)
                };

                semesterFeeInfo.ColumnDefinitions.Add(new ColumnDefinition() { MaxWidth = 100 });
                semesterFeeInfo.ColumnDefinitions.Add(new ColumnDefinition());
                semesterFeeInfo.ColumnDefinitions.Add(new ColumnDefinition());
                semesterFeeInfo.ColumnDefinitions.Add(new ColumnDefinition());
                semesterFeeInfo.ColumnDefinitions.Add(new ColumnDefinition());
                semesterFeeInfo.ColumnDefinitions.Add(new ColumnDefinition());
                semesterFeeInfo.ColumnDefinitions.Add(new ColumnDefinition());

                int semester = i + 1;
                string totalFees = GetSemesterFees(feesData, semester);

                double balance = double.Parse(totalFees) - GetPaidAmount(payments, semester);

                TextBlock semesterText = new()
                {
                    Text = $"Semester {semester}",
                    VerticalAlignment = VerticalAlignment.Center,
                    HorizontalAlignment = HorizontalAlignment.Left,
                };

                TextBlock amount = new()
                {
                    Text = $"₹{totalFees}",
                    VerticalAlignment = VerticalAlignment.Center,
                    HorizontalAlignment = HorizontalAlignment.Center,
                };

                //Date
                TextBlock date = new()
                {
                    Text = GetFeePaymentDate(payments, semester),
                    VerticalAlignment = VerticalAlignment.Center,
                    HorizontalAlignment = HorizontalAlignment.Center,
                };

                CalendarDatePicker datePicker = new()
                {
                    Date = DateTime.Now,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    DateFormat = "{day.integer(2)}-{month.integer(2)}-{year.full}",
                    MaxDate = DateTime.Now
                };

                if (IsPaid(payments, semester))
                {
                    if(balance!=0)
                    {
                        semesterFeeInfo.Children.Add(datePicker);
                        Grid.SetColumn(datePicker, 2);
                    }
                    else
                    {
                        semesterFeeInfo.Children.Add(date);
                        Grid.SetColumn(date, 2);
                    }
                }
                else
                {
                    semesterFeeInfo.Children.Add(datePicker);
                    Grid.SetColumn(datePicker, 2);
                }


                StatusButton status;

                if (IsPaid(payments, semester))
                {
                    if(balance==0)
                    {
                        status = new()
                        {
                            StatusText = "Paid",
                            GlyphBackground = new SolidColorBrush((Color)Application.Current.Resources["SystemAccentColor"]),
                            Glyph = "\uf13e",
                            HorizontalAlignment = HorizontalAlignment.Center,
                        };
                    }
                    else
                    {
                        status = new()
                        {
                            StatusText = "Partial",
                            GlyphBackground = new SolidColorBrush(Colors.Orange),
                            Glyph = "\ue915",
                            HorizontalAlignment = HorizontalAlignment.Center,
                        };
                    }
                }
                else
                {
                    status = new()
                    {
                        StatusText = "Not Paid",
                        GlyphBackground = new SolidColorBrush(Colors.Red),
                        Glyph = "\uf13d",
                        HorizontalAlignment = HorizontalAlignment.Center,
                    };
                }


                //Payment Method

                TextBlock paymentMethod = new()
                {
                    Text = GetPaymentMethod(payments, semester),
                    VerticalAlignment = VerticalAlignment.Center,
                    HorizontalAlignment = HorizontalAlignment.Center,
                };

                ComboBox paymentMethodComboBox = new()
                {
                    HorizontalAlignment = HorizontalAlignment.Stretch,
                    SelectedIndex = 0,
                    DisplayMemberPath = "Name",
                    MaxWidth = 180,
                };

                TextBlock fine = new()
                {
                    Text = $"₹{GetFineAmount(payments, semester)}",
                    VerticalAlignment = VerticalAlignment.Center,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    TextAlignment = TextAlignment.Center
                };

                TextBox fineTextBox = new()
                {
                    PlaceholderText = "₹0",
                    VerticalAlignment = VerticalAlignment.Center,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    IsEnabled = false
                };

                if (IsPaid(payments, semester))
                {
                    if(balance==0)
                    {
                        semesterFeeInfo.Children.Add(paymentMethod);
                        Grid.SetColumn(paymentMethod, 4);
                    }
                    else
                    {

                        //Partial payment is made disable transaction through bank

                        paymentMethodComboBox.Items.Add(new PaymentMethod()
                        {
                            Id = -1,
                            Name = "Cash",
                            Type = "Cash"
                        });

                        
                         foreach (var bank in banks)
                        {
                            PaymentMethod payment = new()
                            {
                                Id = bank.Id,
                                Name = bank.Name,
                                Type = "Bank"
                            };

                            paymentMethodComboBox.Items.Add(payment);
                        }
                       

                        semesterFeeInfo.Children.Add(paymentMethodComboBox);
                        Grid.SetColumn(paymentMethodComboBox, 4);
                    }
                }
                else
                {
                    paymentMethodComboBox.Items.Add(new PaymentMethod()
                    {
                        Id = -1,
                        Name = "Cash",
                        Type = "Cash"
                    });


                    foreach (var bank in banks)
                    {
                        PaymentMethod payment = new()
                        {
                            Id = bank.Id,
                            Name = bank.Name,
                            Type = "Bank"
                        };

                        paymentMethodComboBox.Items.Add(payment);
                    }

                    semesterFeeInfo.Children.Add(paymentMethodComboBox);
                    Grid.SetColumn(paymentMethodComboBox, 4);
                }


                if (IsPaid(payments, semester))
                {
                    if(balance==0)
                    {
                        semesterFeeInfo.Children.Add(fine);
                        Grid.SetColumn(fine, 5);
                    }
                    else
                    {
                        semesterFeeInfo.Children.Add(fineTextBox);
                        Grid.SetColumn(fineTextBox, 5);
                        fineTextBox.BeforeTextChanging += (sender, args) =>
                        {
                            if (args.NewText.Length > 0)
                            {
                                if (!int.TryParse(args.NewText, out _))
                                {
                                    args.Cancel = true;
                                }
                            }
                        };
                    }
                }
                else
                {
                    semesterFeeInfo.Children.Add(fineTextBox);
                    Grid.SetColumn(fineTextBox, 5);
                    fineTextBox.BeforeTextChanging += (sender, args) =>
                    {
                        if (args.NewText.Length > 0)
                        {
                            if (!int.TryParse(args.NewText, out _))
                            {
                                args.Cancel = true;
                            }
                        }
                    };
                }
                
                TextBox partialAmount = new()
                {
                    Header = "Partial Fees Amount",
                    PlaceholderText = "₹",
                    Width = 200,
                    HorizontalAlignment = HorizontalAlignment.Left,
                    VerticalAlignment = VerticalAlignment.Center
                };

                
                Grid balanceWrapper = new();
                balanceWrapper.RowDefinitions.Add(new RowDefinition());
                balanceWrapper.RowDefinitions.Add(new RowDefinition());

                TextBlock balanceAmountHeader = new()
                {
                    Text = "Balance Amount",
                    Width = 200,
                    HorizontalAlignment = HorizontalAlignment.Left,
                    VerticalAlignment = VerticalAlignment.Top,
                };


                TextBlock balanceAmount = new()
                {
                    Text = "₹"+ balance.ToString(),
                    Width = 200,
                    HorizontalAlignment = HorizontalAlignment.Left,
                    VerticalAlignment = VerticalAlignment.Center,
                    FontWeight = FontWeights.Medium
                };

                Grid.SetRow(balanceAmountHeader, 0);
                Grid.SetRow(balanceAmount, 1);

                Grid expanderBody = new()
                {
                    HorizontalAlignment = HorizontalAlignment.Stretch,
                };

                Grid transactionListHeader = new()
                {
                    Padding = new Thickness(15),
                    Margin = new Thickness(0, 15, 0, 0)
                };

                Grid expanderBodyPartialPayment = new()
                {
                    HorizontalAlignment = HorizontalAlignment.Stretch,
                };

                expanderBodyPartialPayment.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(300) });
                expanderBodyPartialPayment.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(300) });

                expanderBody.RowDefinitions.Add(new RowDefinition());
                expanderBody.RowDefinitions.Add(new RowDefinition());
                expanderBody.RowDefinitions.Add(new RowDefinition());

                Grid.SetColumn(amount, 0);
                Grid.SetRow(amount, 0);
                Grid.SetColumn(balanceWrapper, 1);
                Grid.SetRow(balanceWrapper, 0);


                Grid transactionList = new()
                {
                    RowSpacing = 5,
                };

                int row = 0;
                bool isTrasactionsAvailable = false;
                foreach(var payment in payments)
                {
                    if(payment.Semester == semester)
                    {
                        isTrasactionsAvailable = true;
                        transactionList.RowDefinitions.Add(new());
                        Grid rowItem = new()
                        {
                            Background = new SolidColorBrush((Color)Application.Current.Resources["CardBackgroundFillColorSecondary"]),
                            BorderThickness = new Thickness(1),
                            BorderBrush = new SolidColorBrush((Color)Application.Current.Resources["CardStrokeColorDefault"]),
                            Padding = new Thickness(15),
                            CornerRadius = new CornerRadius(8)
                        };
                        rowItem.ColumnDefinitions.Add(new()); //Semester
                        rowItem.ColumnDefinitions.Add(new()); //Date
                        rowItem.ColumnDefinitions.Add(new()); //Amount
                        rowItem.ColumnDefinitions.Add(new()); //Fine
                        rowItem.ColumnDefinitions.Add(new()); //Actions

                        TextBlock semesterTextView = new()
                        {
                            Text = "Semester " + payment.Semester.ToString(),
                            VerticalAlignment = VerticalAlignment.Center,
                        };

                        TextBlock amountTextView = new()
                        {
                            Text = "₹" + payment.Amount.ToString(),
                            VerticalAlignment = VerticalAlignment.Center,
                        };

                        TextBlock fineTextView = new()
                        {
                            Text = "₹" + payment.Fine.ToString(),
                            VerticalAlignment = VerticalAlignment.Center,
                        };


                        TextBlock dateTextView = new()
                        {
                            Text = payment.Date.Date.ToString("dd-MM-yyyy"),
                            VerticalAlignment = VerticalAlignment.Center,
                        };

                        StackPanel btnPanel = new()
                        {
                            Orientation = Orientation.Horizontal,
                            Spacing = 15
                        };


                        Button rollback = new()
                        {
                            Content = "Rollback",
                        };

                        rollback.Click += (sender, o) =>
                        {
                            RollbackTransaction(payment.Id.ToString());
                        };

                        Button viewReceipt = new()
                        {
                            Content = "View Receipt",
                            Style = (Style)Application.Current.Resources["AccentButtonStyle"]
                        };

                        viewReceipt.Click += (sender, o) =>
                        {
                            PrintReceipt(payment.Id.ToString(),sender);
                        };

                        btnPanel.Children.Add(viewReceipt);
                        btnPanel.Children.Add(rollback);


                        rowItem.Children.Add(semesterTextView);
                        rowItem.Children.Add(amountTextView);
                        rowItem.Children.Add(fineTextView);
                        rowItem.Children.Add(dateTextView);
                        rowItem.Children.Add(btnPanel);

                        Grid.SetColumn(semesterTextView, 0);
                        Grid.SetColumn(amountTextView, 1);
                        Grid.SetColumn(fineTextView, 2);
                        Grid.SetColumn(dateTextView, 3);
                        Grid.SetColumn(btnPanel, 4);
                        Grid.SetRow(rowItem, row);

                        transactionList.Children.Add(rowItem);
                        row++;
                    }
                }

                if(isTrasactionsAvailable)
                {
                    transactionListHeader.ColumnDefinitions.Add(new()); //Semester
                    transactionListHeader.ColumnDefinitions.Add(new()); //Date
                    transactionListHeader.ColumnDefinitions.Add(new()); //Amount
                    transactionListHeader.ColumnDefinitions.Add(new()); //Fine
                    transactionListHeader.ColumnDefinitions.Add(new()); //Actions

                    TextBlock labelSemester = new()
                    {
                        Text = "Semester",
                        FontWeight = FontWeights.Medium
                    };

                    TextBlock labelDate = new()
                    {
                        Text = "Date",
                        FontWeight = FontWeights.Medium
                    };

                    TextBlock labelAmount = new()
                    {
                        Text = "Amount",
                        FontWeight = FontWeights.Medium
                    };

                    TextBlock labelFine = new()
                    {
                        Text = "Fine",
                        FontWeight = FontWeights.Medium
                    };

                    TextBlock labelActions = new()
                    {
                        Text = "Actions",
                        FontWeight = FontWeights.Medium
                    };

                    Grid.SetColumn(labelSemester, 0);
                    Grid.SetColumn(labelAmount, 1);
                    Grid.SetColumn(labelFine, 2);
                    Grid.SetColumn(labelDate, 3);
                    Grid.SetColumn(labelActions, 4);

                    transactionListHeader.Children.Add(labelSemester);
                    transactionListHeader.Children.Add(labelDate);
                    transactionListHeader.Children.Add(labelFine);
                    transactionListHeader.Children.Add(labelAmount);
                    transactionListHeader.Children.Add(labelActions);

                    expanderBody.Children.Add(transactionListHeader);
                }


                balanceWrapper.Children.Add(balanceAmountHeader);
                balanceWrapper.Children.Add(balanceAmount);
                expanderBodyPartialPayment.Children.Add(balanceWrapper);
                expanderBodyPartialPayment.Children.Add(partialAmount);

                expanderBody.Children.Add(expanderBodyPartialPayment);
                expanderBody.Children.Add(transactionList);

                Grid.SetRow(expanderBodyPartialPayment, 0);
                Grid.SetRow(transactionListHeader, 1);
                Grid.SetRow(transactionList,2);

                Button actionButton;
                bool isPaid = IsPaid(payments, semester);

                if (isPaid)
                {
                    if(balance!=0)
                    {
                        actionButton = new()
                        {
                            HorizontalAlignment = HorizontalAlignment.Stretch,
                            Content = "Pay Now",
                            MaxWidth = 120,
                            IsEnabled = false
                        };

                        actionButton.Click += (sender, e) =>
                        {
                            if (datePicker.Date != null)
                            {
                                ErrorInfo.IsOpen = false;
                                Debug.WriteLine(fineTextBox.Text.ToString());
                                double fineAmount = (string.IsNullOrEmpty(fineTextBox.Text.ToString()) ? 0 : double.Parse(fineTextBox.Text.ToString()));

                                PaymentMethod paymentSource = paymentMethodComboBox.SelectedItem as PaymentMethod;

                                if (partialAmount.Text != string.Empty && paymentSource.Type != "Bank")
                                {
                                    CollectFees(datePicker.Date.Value.DateTime, paymentMethodComboBox.SelectedItem as PaymentMethod, semester, double.Parse(partialAmount.Text), fineAmount, true);
                                }
                                else if (partialAmount.Text != string.Empty && paymentSource.Type == "Bank")
                                {
                                    CollectFees(datePicker.Date.Value.DateTime, paymentMethodComboBox.SelectedItem as PaymentMethod, semester, double.Parse(partialAmount.Text), fineAmount, true);
                                }
                                else
                                {
                                    CollectFees(datePicker.Date.Value.DateTime, paymentMethodComboBox.SelectedItem as PaymentMethod, semester, double.Parse(totalFees), fineAmount);
                                }
                            }
                            else
                            {
                                ErrorInfo.IsOpen = true;
                                ErrorInfo.Message = "Please Select a valid date";
                            }
                        };
                    }
                    else
                    {
                        actionButton = new()
                        {
                            Content = "View Transactions",
                            IsEnabled = true,
                            HorizontalAlignment = HorizontalAlignment.Center
                        };

                        actionButton.Click += (s, e) =>
                        {
                            expander.IsExpanded = true;
                        };
                    }
                }
                else
                {
                    actionButton = new()
                    {
                        HorizontalAlignment = HorizontalAlignment.Stretch,
                        Content = "Pay Now",
                        MaxWidth = 120
                    };

                    actionButton.Click += (sender, e) =>
                    {
                        if (datePicker.Date != null)
                        {
                            ErrorInfo.IsOpen = false;
                            Debug.WriteLine(fineTextBox.Text.ToString());
                            double fineAmount = (string.IsNullOrEmpty(fineTextBox.Text.ToString()) ? 0 : double.Parse(fineTextBox.Text.ToString()));

                            PaymentMethod paymentSource = paymentMethodComboBox.SelectedItem as PaymentMethod;

                            if (partialAmount.Text!=string.Empty && paymentSource.Type != "Bank")
                            {
                                CollectFees(datePicker.Date.Value.DateTime, paymentMethodComboBox.SelectedItem as PaymentMethod, semester, double.Parse(partialAmount.Text), fineAmount,true);
                            }
                            else
                            {
                                CollectFees(datePicker.Date.Value.DateTime, paymentMethodComboBox.SelectedItem as PaymentMethod, semester, double.Parse(totalFees), fineAmount);
                            }
                        }
                        else
                        {
                            ErrorInfo.IsOpen = true;
                            ErrorInfo.Message = "Please Select a valid date";
                        }
                    };
                }

                partialAmount.BeforeTextChanging += (sender, args) =>
                {
                    if (args.NewText.Length > 0)
                    {
                        if (!int.TryParse(args.NewText, out _))
                        {
                            args.Cancel = true;
                        }
                        else
                        {
                            if (double.Parse(args.NewText) > balance || args.NewText == string.Empty)
                            {
                                actionButton.IsEnabled = false;
                            }
                            else
                            {
                                actionButton.IsEnabled = true;
                            }
                        }
                    }
                };

                semesterFeeInfo.Children.Add(semesterText);
                semesterFeeInfo.Children.Add(amount);
                semesterFeeInfo.Children.Add(status);
                semesterFeeInfo.Children.Add(actionButton);

                Grid.SetColumn(semesterText, 0);
                Grid.SetColumn(amount, 1);
                Grid.SetColumn(status, 3);
                Grid.SetColumn(actionButton, 6);

                expander.Header = semesterFeeInfo;

                if (isPaid)
                {
                    if (balance == 0)
                    {
                        expanderBodyPartialPayment.Visibility = Visibility.Collapsed;
                        transactionListHeader.Margin = new Thickness(0);
                        expander.Content = expanderBody;
                    }
                    else
                    {
                        expander.Content = expanderBody;
                    }
                }
                else
                {
                    expander.Content = expanderBody;
                }
                paymentMethodComboBox.SelectionChanged += (s, e) =>
                {
                    ComboBox paymentMethodChooser = s as ComboBox;
                    if (paymentMethodChooser.SelectedItem is PaymentMethod paymentMethod)
                    {
                        if (paymentMethod.Id == -1)
                        {
                            fineTextBox.IsEnabled = false;
                            partialAmount.IsEnabled = true;
                        }
                        else
                        {
                            fineTextBox.IsEnabled = true;
                            partialAmount.IsEnabled = false;

                        }
                    }
                };

                FeesDetailsWrapper.Children.Add(expander);
                Grid.SetRow(expander, i);
            }

            FeesDetialsContainer.Visibility = Visibility.Visible;
        }

        private async void CollectFees(DateTime date, PaymentMethod paymentMethod, int semester, double amount,double fine,bool partial=false)
        {
            searchProgress.Visibility = Visibility.Visible;
            int receiptId = 0;
            int studentId = studentData.Id;
            int courseId = courseData.Id;
            int bank = paymentMethod.Id;
            DateTime paymentDate = date;

            string outputPath = string.Empty;

            ModifyButtonState(FeesDetailsWrapper, false);

            Receipt receipt = new();

            await Task.Run(async () =>
            {
                try
                {
                    using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                    await connection.OpenAsync();

                    MySqlTransaction transaction = await connection.BeginTransactionAsync();

                    try
                    {
                        MySqlCommand command = connection.CreateCommand();
                        command.CommandText = "INSERT INTO payments(`student_id`,`course_id`,`amount`,`semester`,`payment_method`,`partial`,`bank_id`,`date`,`fine`) VALUES(@studentId,@courseId,@amount,@semester,@paymentMethod,@partial,@bankId,@date,@fine);";
                        command.Parameters.AddWithValue("@studentId", studentId);
                        command.Parameters.AddWithValue("@courseId", courseId);
                        command.Parameters.AddWithValue("@amount", amount);
                        command.Parameters.AddWithValue("@semester", semester);
                        command.Parameters.AddWithValue("@paymentMethod", paymentMethod.Type);
                        command.Parameters.AddWithValue("@bankId", bank);
                        command.Parameters.AddWithValue("@date", paymentDate);
                        command.Parameters.AddWithValue("@fine", fine);
                        command.Parameters.AddWithValue("@partial", partial);
                        await command.ExecuteNonQueryAsync();

                        command.CommandText = "SELECT LAST_INSERT_ID();";
                        int paymentId = Convert.ToInt32(await command.ExecuteScalarAsync());

                        command.CommandText = "INSERT INTO receipts(`student_id`,`course_id`,`semester`,`payment_method`,`bank_id`,`payment_id`,`date`) VALUES(@studentId,@courseId,@semester,@paymentMethod,@bankId,@paymentId,@date)";
                        command.Parameters.Clear();
                        command.Parameters.AddWithValue("@studentId", studentId);
                        command.Parameters.AddWithValue("@courseId", courseId);
                        command.Parameters.AddWithValue("@semester", semester);
                        command.Parameters.AddWithValue("@paymentMethod", paymentMethod.Type);
                        command.Parameters.AddWithValue("@bankId", bank);
                        command.Parameters.AddWithValue("@paymentId", paymentId);
                        command.Parameters.AddWithValue("@date", paymentDate);
                        await command.ExecuteNonQueryAsync();

                        command.CommandText = "SELECT LAST_INSERT_ID();";
                        receiptId = Convert.ToInt32(await command.ExecuteScalarAsync());

                        command.CommandText = "SELECT r.*,b.name as bank_name FROM receipts r LEFT JOIN banks b ON r.bank_id = b.id WHERE r.id =@receiptId";
                        command.Parameters.AddWithValue("@receiptId", receiptId);

                        using MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync();

                        while (await reader.ReadAsync())
                        {
                            int dateOrdinal = reader.GetOrdinal("date");
                            int bankOrdinal = reader.GetOrdinal("bank_name");

                            receipt.Id = receiptId;
                            receipt.Date = reader.IsDBNull(dateOrdinal) ? DateTime.Now : reader.GetDateTime(dateOrdinal);
                            receipt.Name = studentData.Name;
                            receipt.Course = courseData.Name;
                            receipt.PaymentMethod = paymentMethod.Type;
                            receipt.Bank = reader.IsDBNull(bankOrdinal) ? "" : reader.GetString(bankOrdinal);
                            receipt.Amount = (fine==0)? amount:fine+amount;
                            receipt.Student = studentData.Id.ToString();

                            if(fine != 0)
                            {
                                receipt.Towards = "Semester " + semester + " Fees Including Fine";
                            }
                            else
                            {
                                receipt.Towards = "Semester " + semester + " Fees";
                            }
                        }

                        await reader.CloseAsync();
                        transaction.Commit();


                        //Genereate Receipt

                        //string pdfFilePath = Path.Combine(Package.Current.InstalledLocation.Path, "Receipts");
                        string pdfFilePath = Path.Combine(@"C:\", "Receipts");

                        if (Directory.Exists(pdfFilePath))
                        {
                            pdfFilePath = $"{pdfFilePath}\\ {receipt.Id} - Fees Receipt - {receipt.Name.TrimEnd()}.pdf";
                            Debug.WriteLine(pdfFilePath);

                            ReceiptGenerator generator = new(receipt, pdfFilePath);
                            await generator.GenerateReceipt();
                            outputPath = generator.GetPath();
                        }
                        else
                        {
                            try
                            {
                                Directory.CreateDirectory(pdfFilePath);
                                pdfFilePath = $"{pdfFilePath}\\ {receipt.Id} - Fees Receipt - {receipt.Name.TrimEnd()}.pdf";
                                Debug.WriteLine(pdfFilePath);

                                ReceiptGenerator generator = new(receipt, pdfFilePath);
                                await generator.GenerateReceipt();
                                outputPath = generator.GetPath();
                            }
                            catch (Exception ex)
                            {
                                Debug.WriteLine(ex.InnerException.Message);
                                throw;
                            }
                        }

                        //Print Document
                        PrintRouter printRouter = new();
                        await printRouter.SendForPrinting(outputPath);


                    }
                    catch (Exception e)
                    {
                        transaction.Rollback();
                        Debug.WriteLine(e.Message);
                        throw;
                    }

                }
                catch (Exception e)
                {
                    Debug.WriteLine(e.Message);
                    throw;
                }
            }).ContinueWith(t =>
            {
                searchProgress.Visibility = Visibility.Collapsed;
                ModifyButtonState(FeesDetailsWrapper, true);

                if (t.Exception != null)
                {
                    ErrorInfo.IsOpen = true;
                    ErrorInfo.Message = t.Exception.Message;
                }
                else
                {
                    ErrorInfo.IsOpen = false;

                    FeesDetailsWrapper.Children.Clear();
                    FillStudentDetails(studentId.ToString());
                }

            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        public void ModifyButtonState(DependencyObject parent, bool enabled)
        {
            int childCount = VisualTreeHelper.GetChildrenCount(parent);
            for (int i = 0; i < childCount; i++)
            {
                var child = VisualTreeHelper.GetChild(parent, i);

                if (child is Button button)
                {
                    button.IsEnabled = enabled;
                }

                ModifyButtonState(child, enabled);
            }
        }

        private string GetFineAmount(List<Payment> payments,int semester)
        {
            string fineAmount = "------";

            foreach (var payment in payments)
            {
                if (payment != null)
                {
                    if (payment.Semester == semester)
                    {
                        fineAmount = payment.Fine.ToString();
                    }
                }
            }

            return fineAmount;
        }

        private async void ValidateStudentId()
        {
            string studentId = searchBox.Text;
            if (string.IsNullOrEmpty(studentId))
            {
                ErrorInfo.IsOpen = true;
                ErrorInfo.Message = "Please enter a valid Student ID to continue";
            }
            else
            {
                searchProgress.Visibility = Visibility.Visible;
                ErrorInfo.IsOpen = false;
                await Task.Run(async () =>
                {
                    try
                    {
                        using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                        await connection.OpenAsync();

                        MySqlCommand command = connection.CreateCommand();
                        command.CommandText = "SELECT COUNT(*) from students where id=@id";
                        command.Parameters.AddWithValue("@id", studentId);

                        int count = Convert.ToInt32(await command.ExecuteScalarAsync());
                        if (!(count > 0))
                        {
                            throw new UnknownStudentException($"There is no record associated with Student ID '{studentId}'. Please check the student ID and try again");
                        }
                    }
                    catch (Exception)
                    {
                        throw;
                    }
                }).ContinueWith(t =>
                {
                    searchProgress.Visibility = Visibility.Collapsed;
                    if (t.Exception != null)
                    {
                        if (t.Exception?.InnerException is UnknownStudentException)
                        {
                            ErrorInfo.IsOpen = true;
                            ErrorInfo.Message = t.Exception.InnerException.Message;
                        }
                        else
                        {
                            ErrorInfo.IsOpen = true;
                            ErrorInfo.Message = t.Exception.Message;
                        }
                    }
                    else
                    {
                        ErrorInfo.IsOpen = false;
                        studentId = searchBox.Text;
                        FillStudentDetails(studentId);
                        FetchBankDetails();
                    }

                }, TaskScheduler.FromCurrentSynchronizationContext());
            }
        }

        private void GetDetailsClicked(object sender, RoutedEventArgs e)
        {
            ValidateStudentId();
        }

        private void SearchBoxTextChanging(TextBox sender, TextBoxBeforeTextChangingEventArgs args)
        {
            if (args.NewText.Length > 0)
            {
                if (!int.TryParse(args.NewText, out _))
                {
                    args.Cancel = true;
                }
            }
        }

        private void SearchBoxKeyDown(object sender, Microsoft.UI.Xaml.Input.KeyRoutedEventArgs e)
        {
            if (e.Key == Windows.System.VirtualKey.Enter)
            {
                ValidateStudentId();
            }
        }

        private async void PrintReceipt(string paymentId,object sender)
        {
            searchProgress.Visibility = Visibility.Visible;
            Button senderBtn = (Button)sender;
            senderBtn.IsEnabled = false;

            string outputPath = string.Empty;

            await Task.Run(async () =>
            {
                Receipt receipt = new();
                double fine = 0;
                double amount = 0;
                string semester = "";

                try
                {
                    using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                    await connection.OpenAsync();

                    MySqlCommand command = connection.CreateCommand();

                    command.CommandText = "SELECT r.*,s.student_name as student_name,c.name as course_name,b.name as bank_name,p.amount, p.fine as fine from receipts r LEFT JOIN students s ON s.id = r.student_id LEFT JOIN courses c ON c.id = r.course_id LEFT JOIN banks b ON b.id = r.bank_id LEFT JOIN payments p ON p.id=r.payment_id WHERE payment_id=@id";
                    command.Parameters.AddWithValue("@id", paymentId);

                    using MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync();

                    while (await reader.ReadAsync())
                    {
                        int dateOrdinal = reader.GetOrdinal("date");
                        int studentNameOrdinal = reader.GetOrdinal("student_name");
                        int courseNameOrdinal = reader.GetOrdinal("course_name");
                        int paymentMethodOrdinal = reader.GetOrdinal("payment_method");
                        int bankOrdinal = reader.GetOrdinal("bank_name");
                        int amountOrdinal = reader.GetOrdinal("amount");
                        int semesterOrdinal = reader.GetOrdinal("semester");
                        int studentIdOrdinal = reader.GetOrdinal("student_id");
                        int fineOrdinal = reader.GetOrdinal("fine");

                        fine = reader.IsDBNull(fineOrdinal) ? 0 : reader.GetDouble(fineOrdinal);
                        amount = reader.IsDBNull(amountOrdinal) ? 0 : reader.GetDouble(amountOrdinal);
                        semester = reader.IsDBNull(semesterOrdinal) ? "" : reader.GetString(semesterOrdinal);

                        receipt.Id = reader.GetInt32("id");
                        receipt.Date = reader.IsDBNull(dateOrdinal) ? DateTime.Now : reader.GetDateTime(dateOrdinal);
                        receipt.Name = reader.IsDBNull(studentNameOrdinal) ? "" : reader.GetString(studentNameOrdinal);
                        receipt.Course = reader.IsDBNull(courseNameOrdinal) ? "" : reader.GetString(courseNameOrdinal);
                        receipt.PaymentMethod = reader.IsDBNull(paymentMethodOrdinal) ? "" : reader.GetString(paymentMethodOrdinal);
                        receipt.Bank = reader.IsDBNull(bankOrdinal) ? "" : reader.GetString(bankOrdinal);
                        receipt.Amount = (fine == 0) ? amount : fine + amount;
                        receipt.Student = reader.IsDBNull(studentIdOrdinal) ? "" : reader.GetString(studentIdOrdinal);
                        if (fine != 0)
                        {
                            receipt.Towards = "Semester " + semester + " Fees Including Fine";
                        }
                        else
                        {
                            receipt.Towards = "Semester " + semester + " Fees";
                        }
                    }

                    string pdfFilePath = Path.Combine(@"C:\", "Receipts", receipt.Id + " - Fees Receipt - " + receipt.Name.TrimEnd() + ".pdf");
                    ReceiptGenerator generator = new(receipt, pdfFilePath);
                    await generator.GenerateReceipt();
                    outputPath = generator.GetPath();

                    PrintRouter printRouter = new();
                    await printRouter.SendForPrinting(outputPath);

                }
                catch (Exception e)
                {
                    Debug.WriteLine(e.Message);
                    throw;
                }
            }).ContinueWith(t =>
            {
                Button senderBtn = (Button)sender;
                searchProgress.Visibility = Visibility.Collapsed;
                senderBtn.IsEnabled = true;

                if (t.Exception != null)
                {
                    ErrorInfo.IsOpen = true;
                    ErrorInfo.Message = t.Exception.Message;
                }
                else
                {
                    ErrorInfo.IsOpen = false;
                }
            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

       

        private async void RollbackTransaction(string paymentId)
        {
            await Task.Run(async () =>
            {
                try
                {
                    using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                    await connection.OpenAsync();

                    using (MySqlTransaction transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            using (MySqlCommand command = connection.CreateCommand())
                            {
                                command.Transaction = transaction;
                                command.CommandText = "DELETE FROM payments WHERE id = @paymentId";
                                command.Parameters.AddWithValue("@paymentId", paymentId);
                                command.ExecuteNonQuery();
                            }

                            using (MySqlCommand command = connection.CreateCommand())
                            {
                                command.Transaction = transaction;
                                command.CommandText = "DELETE FROM receipts WHERE payment_id = @paymentId";
                                command.Parameters.AddWithValue("@paymentId", paymentId);
                                command.ExecuteNonQuery();
                            }

                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            Debug.Write(ex.ToString());
                            transaction.Rollback();
                            throw;
                        }
                    }

                }
                catch (Exception e)
                {
                    Debug.WriteLine(e.Message);
                    throw;
                }
            }).ContinueWith(t =>
            {
                if (t.Exception != null)
                {
                    ErrorInfo.IsOpen = true;
                    ErrorInfo.Message = t.Exception.Message;
                }
                else
                {
                    ErrorInfo.IsOpen = false;
                    ValidateStudentId();
                }
            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

    }
}
