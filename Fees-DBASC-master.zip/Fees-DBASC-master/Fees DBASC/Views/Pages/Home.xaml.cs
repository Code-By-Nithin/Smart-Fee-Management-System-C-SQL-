using Fees_DBASC.Core.Routing;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;

namespace Fees_DBASC.Views.Pages
{
    public sealed partial class Home : Page
    {
        public Home()
        {
            this.InitializeComponent();
        }

        private void OpenCollectFees(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(this, new FeePayment());
        }

        private void OpenGenerateReport(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(this, new GenerateReport());
        }

        private void OpenUploadStudentDetails(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(this, new UploadStudentDetails());
        }

        private void OpenUploadFeesStructure(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(this, new UploadFeesStructure());
        }
    }
}
