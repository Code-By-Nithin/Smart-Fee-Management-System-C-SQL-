using Fees_DBASC.Core.Database;
using Fees_DBASC.Core.Exceptions;
using Fees_DBASC.Data.Models;
using Microsoft.UI.Composition.Interactions;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Controls.Primitives;
using Microsoft.UI.Xaml.Data;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Navigation;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text.Json;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.Foundation.Collections;

namespace Fees_DBASC.Views.Pages
{
    public sealed partial class PaymentStatistics : Page
    {
        List<Course> courses;
        List<string> academicYears;
        List<string> semesters;
        List<Student> students;
        List<Payment> payments;
        List<TransactionModel> transactionModels;

        public PaymentStatistics()
        {
            this.InitializeComponent();

            courses = new List<Course>();
            academicYears = new List<string>();
            semesters = new List<string>();
            students = new List<Student>();
        }

        private async void LoadCourseDetails(Course course)
        {
            await Task.Run(async () =>
            {
                try
                {
                    using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                    await connection.OpenAsync();

                    MySqlCommand command = connection.CreateCommand();
                    command.CommandText = "SELECT * FROM courses";

                    using MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync();
                    while (await reader.ReadAsync())
                    {
                        int idOrdinal = reader.GetOrdinal("id");
                        int nameOrdinal = reader.GetOrdinal("name");
                        int semestersOrdinal = reader.GetOrdinal("semesters");
                        int timestampOrdinal = reader.GetOrdinal("timestamp");
                        int typeOrdinal = reader.GetOrdinal("type");

                        Course course = new()
                        {
                            Id = reader.IsDBNull(idOrdinal) ? -1 : reader.GetInt32(idOrdinal),
                            Name = reader.IsDBNull(nameOrdinal) ? null : reader.GetString(nameOrdinal),
                            Semesters = reader.IsDBNull(semestersOrdinal) ? 0 : reader.GetInt32(semestersOrdinal),
                            Timestamp = reader.IsDBNull(timestampOrdinal) ? DateTime.Now : reader.GetDateTime(timestampOrdinal),
                            Type = reader.IsDBNull(typeOrdinal) ? -1 : reader.GetInt32(typeOrdinal),
                        };

                        courses.Add(course);
                    }
                    await reader.CloseAsync();
                }
                catch (Exception e)
                {
                    Debug.WriteLine(e.Message);
                    throw;
                }
            }).ContinueWith(t =>
            {
                ProgressBar.Visibility = Visibility.Collapsed;
                CourseList.IsEnabled = true;

                if (t.Exception != null)
                {
                    ErrorInfoBar.IsOpen = true;
                    ErrorInfoBar.Message = t.Exception.Message;
                }
                else
                {
                    ErrorInfoBar.IsOpen = false;
                    if (courses.Count > 0)
                    {
                        CourseList.ItemsSource = courses;
                        CourseList.SelectedIndex = 0;
                        LoadAcademicYears(course);
                    }
                }

            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        private async void LoadAcademicYears(Course course)
        {
            ProgressBar.Visibility = Visibility.Visible;
            AcademicYearList.IsEnabled = false;
            CourseList.IsEnabled = false;
            GetDetailsBtn.IsEnabled = false;

            await Task.Run(async () =>
            {
                try
                {
                    using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                    await connection.OpenAsync();

                    MySqlCommand command = connection.CreateCommand();
                    command.CommandText = "SELECT DISTINCT academic_year FROM students WHERE course_id=@id";
                    command.Parameters.AddWithValue("id", course.Id);

                    using MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync();

                    academicYears.Clear();
                    while (await reader.ReadAsync())
                    {
                        int academicYearOrdinal = reader.GetOrdinal("academic_year");
                        academicYears.Add(reader.IsDBNull(academicYearOrdinal) ? null : reader.GetString(academicYearOrdinal));
                    }
                    await reader.CloseAsync();
                }
                catch (Exception e)
                {
                    Debug.WriteLine(e.Message);
                    throw;
                }
            }).ContinueWith(t =>
            {
                ProgressBar.Visibility = Visibility.Collapsed;
                CourseList.IsEnabled = true;

                if (t.Exception != null)
                {
                    ErrorInfoBar.IsOpen = true;
                    ErrorInfoBar.Message = t.Exception.Message;
                }
                else
                {
                    ErrorInfoBar.IsOpen = false;
                    if (academicYears.Count > 0)
                    {
                        ErrorInfoBar.IsOpen = false;
                        AcademicYearList.Items.Clear();
                        foreach (var item in academicYears)
                        {
                            AcademicYearList.Items.Add(item);
                        }

                        AcademicYearList.IsEnabled = true;
                        GetDetailsBtn.IsEnabled = true;
                        AcademicYearList.SelectedIndex = 0;

                        LoadSemesters(course);
                    }
                    else
                    {
                        AcademicYearList.IsEnabled = false;
                        ErrorInfoBar.IsOpen = true;
                        ErrorInfoBar.Message = "There is no students added to this course, please select another courese and try again";
                    }
                }

            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        private async void LoadSemesters(Course course)
        {
            ProgressBar.Visibility = Visibility.Visible;
            AcademicYearList.IsEnabled = false;
            CourseList.IsEnabled = false;
            SemesterList.IsEnabled = false;

            await Task.Run(async () =>
            {
                try
                {
                    using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                    await connection.OpenAsync();

                    MySqlCommand command = connection.CreateCommand();
                    command.CommandText = "SELECT semesters FROM courses WHERE id=@id";
                    command.Parameters.AddWithValue("id", course.Id);

                    using MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync();

                    semesters.Clear();
                    while (await reader.ReadAsync())
                    {
                        int semestersOrdinal = reader.GetOrdinal("semesters");
                        var semesterCount = reader.IsDBNull(semestersOrdinal) ? null : reader.GetString(semestersOrdinal);
                        for (var i = 1; i <= int.Parse(semesterCount); i++)
                        {
                            semesters.Add(i.ToString());
                        }
                    }
                    await reader.CloseAsync();
                }
                catch (Exception e)
                {
                    Debug.WriteLine(e.Message);
                    throw;
                }
            }).ContinueWith(t =>
            {
                ProgressBar.Visibility = Visibility.Collapsed;
                SemesterList.IsEnabled = true;

                if (t.Exception != null)
                {
                    ErrorInfoBar.IsOpen = true;
                    ErrorInfoBar.Message = t.Exception.Message;
                }
                else
                {
                    ErrorInfoBar.IsOpen = false;
                    if (semesters.Count > 0)
                    {
                        ErrorInfoBar.IsOpen = false;
                        SemesterList.Items.Clear();
                        foreach (var item in semesters)
                        {
                            SemesterList.Items.Add(item);
                        }

                        SemesterList.SelectedIndex = 0;
                        AcademicYearList.IsEnabled = true;
                        CourseList.IsEnabled = true;
                        SemesterList.IsEnabled = true;
                    }
                    else
                    {
                        SemesterList.IsEnabled = false;
                        ErrorInfoBar.IsOpen = true;
                        ErrorInfoBar.Message = "There is no semesters specified for this course";
                    }
                }

            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        private void CourseListSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var course = CourseList.SelectedItem as Course;
            LoadAcademicYears(course);
        }

        private void PageLoaded(object sender, RoutedEventArgs e)
        {
            var course = CourseList.SelectedItem as Course;
            LoadCourseDetails(course);
        }

        private async void FetchStudentDetails(Course course, int academicYear)
        {
            students.Clear();
            await Task.Run(async () =>
            {
                try
                {
                    using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                    await connection.OpenAsync();

                    MySqlCommand command = connection.CreateCommand();
                    command.CommandText = "SELECT s.*,c.semesters FROM stduents s JOIN courses c ON s.course_id = c.id WHERE s.course_id=@course AND s.academic_year=@academic_year";
                    command.Parameters.AddWithValue("id", course.Id);
                    command.Parameters.AddWithValue("academic_year", academicYear);

                    using MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync();
                    while (await reader.ReadAsync())
                    {
                        int courseNameOrdinal = reader.GetOrdinal("course_name");
                        int academicYearOrdinal = reader.GetOrdinal("academic_year");
                        int fathersNameOrdinal = reader.GetOrdinal("fathers_name");
                        int motherssNameOrdinal = reader.GetOrdinal("mothers_name");
                        int address1Ordinal = reader.GetOrdinal("address_line1");
                        int address2Ordinal = reader.GetOrdinal("address_line2");
                        int cityOrdinal = reader.GetOrdinal("city");
                        int stateOrdinal = reader.GetOrdinal("state");
                        int zipCodeOrdinal = reader.GetOrdinal("zip_code");
                        int phoneOrdinal = reader.GetOrdinal("phone");
                        int mobileOrdinal = reader.GetOrdinal("mobile");
                        int emailOrdinal = reader.GetOrdinal("email");
                        int courseIdOrdinal = reader.GetOrdinal("course_id");
                        int standardOrdinal = reader.GetOrdinal("standard");
                        int divisionOrdinal = reader.GetOrdinal("division");
                        int courseTypeOrdinal = reader.GetOrdinal("course_type");
                        int semestersOrdinal = reader.GetOrdinal("semesters");

                        Student student = new()
                        {
                            Id = reader.GetInt32("id"),
                            Name = reader.GetString("student_name"),
                            CourseName = reader.IsDBNull(courseNameOrdinal) ? null : reader.GetString(courseNameOrdinal),
                            AcademicYear = reader.IsDBNull(academicYearOrdinal) ? null : reader.GetString(academicYearOrdinal),
                            FathersName = reader.IsDBNull(fathersNameOrdinal) ? null : reader.GetString(fathersNameOrdinal),
                            MothersName = reader.IsDBNull(motherssNameOrdinal) ? null : reader.GetString(motherssNameOrdinal),
                            Address1 = reader.IsDBNull(address1Ordinal) ? null : reader.GetString(address1Ordinal),
                            Address2 = reader.IsDBNull(address2Ordinal) ? null : reader.GetString(address2Ordinal),
                            City = reader.IsDBNull(cityOrdinal) ? null : reader.GetString(cityOrdinal),
                            State = reader.IsDBNull(stateOrdinal) ? null : reader.GetString(stateOrdinal),
                            ZipCode = reader.IsDBNull(zipCodeOrdinal) ? null : reader.GetString(zipCodeOrdinal),
                            Phone = reader.IsDBNull(phoneOrdinal) ? null : reader.GetString(phoneOrdinal),
                            Mobile = reader.IsDBNull(mobileOrdinal) ? null : reader.GetString(mobileOrdinal),
                            Email = reader.IsDBNull(emailOrdinal) ? null : reader.GetString(emailOrdinal),
                            CourseId = reader.IsDBNull(courseIdOrdinal) ? 0 : reader.GetInt32(courseIdOrdinal),
                            CourseType = reader.IsDBNull(courseTypeOrdinal) ? 0 : reader.GetInt32(courseTypeOrdinal),
                            Standard = reader.IsDBNull(standardOrdinal) ? null : reader.GetString(standardOrdinal),
                            Division = reader.IsDBNull(divisionOrdinal) ? null : reader.GetString(divisionOrdinal),
                            Semesters = reader.IsDBNull(semestersOrdinal) ? 0 : reader.GetInt32(semestersOrdinal),
                        };

                        students.Add(student);

                    }
                    await reader.CloseAsync();
                }
                catch (Exception e)
                {
                    Debug.WriteLine(e.Message);
                    throw;
                }
            }).ContinueWith(t =>
            {
                ProgressBar.Visibility = Visibility.Collapsed;
                CourseList.IsEnabled = true;

                if (t.Exception != null)
                {
                    ErrorInfoBar.IsOpen = true;
                    ErrorInfoBar.Message = t.Exception.Message;
                }
                else
                {
                    ErrorInfoBar.IsOpen = false;
                    FetchTransactions(course, academicYear);
                }

            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        private async void FetchTransactions(Course course, int academicYear)
        {
            payments.Clear();
            await Task.Run(async () =>
            {
                try
                {
                    using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                    await connection.OpenAsync();

                    MySqlCommand command = connection.CreateCommand();
                    command.CommandText = "SELECT p.* from payments where course_id=@id";
                    command.Parameters.AddWithValue("id", course.Id);

                    using MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync();
                    while (await reader.ReadAsync())
                    {
                        int idOrdinal = reader.GetOrdinal("id");
                        int studentIdOrdinal = reader.GetOrdinal("student_id");
                        int courseIdOrdinal = reader.GetOrdinal("course_id");
                        int amountOrdinal = reader.GetOrdinal("amount");
                        int semesterOrdinal = reader.GetOrdinal("semester");
                        int paymentMethodOrdinal = reader.GetOrdinal("payment_method");
                        int bankIdOrdinal = reader.GetOrdinal("bank_id");
                        int fineOrdinal = reader.GetOrdinal("fine");
                        int dateOrdinal = reader.GetOrdinal("date");

                        Payment payment = new()
                        {
                            Id = reader.IsDBNull(idOrdinal) ? 0 : reader.GetInt32(idOrdinal),
                            StudentId = reader.IsDBNull(studentIdOrdinal) ? 0 : reader.GetInt32(studentIdOrdinal),
                            Amount = reader.IsDBNull(amountOrdinal) ? 0 : reader.GetDouble(amountOrdinal),
                            CourseId = reader.IsDBNull(courseIdOrdinal) ? 0 : reader.GetInt32(courseIdOrdinal),
                            Semester = reader.IsDBNull(semesterOrdinal) ? 0 : reader.GetInt32(semesterOrdinal),
                            PaymentMethod = reader.IsDBNull(paymentMethodOrdinal) ? null : reader.GetString(paymentMethodOrdinal),
                            BankId = reader.IsDBNull(bankIdOrdinal) ? 0 : reader.GetInt32(bankIdOrdinal),
                            Date = reader.IsDBNull(dateOrdinal) ? DateTime.Now : reader.GetDateTime(dateOrdinal),
                            Fine = reader.IsDBNull(fineOrdinal) ? 0 : reader.GetDouble(fineOrdinal),
                        };

                        payments.Add(payment);
                    }
                    await reader.CloseAsync();
                }
                catch (Exception e)
                {
                    Debug.WriteLine(e.Message);
                    throw;
                }
            }).ContinueWith(t =>
            {
                ProgressBar.Visibility = Visibility.Collapsed;
                CourseList.IsEnabled = true;

                if (t.Exception != null)
                {
                    ErrorInfoBar.IsOpen = true;
                    ErrorInfoBar.Message = t.Exception.Message;
                }
                else
                {
                    ErrorInfoBar.IsOpen = false;
                    
                    LoadFeeDetails(course, academicYear.ToString());
                    GetTransactionModels(course);
                }

            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        private void GetTransactionModels(Course course)
        {
            transactionModels.Clear();
            foreach (var student in students)
            {
                TransactionModel model = new()
                {
                    StudentId = student.Id,
                    StudentName = student.Name,
                    CourseId = student.CourseId,
                    CourseName = student.CourseName,
                    Semesters = student.Semesters,
                };

                foreach(var payment in payments)
                {
                    if(payment.StudentId ==  student.Id)
                    {
                        model.Transactions.Add(payment);
                    }
                }

                transactionModels.Add(model);
            }

            GetTransactionStatistics(course);
        }

        private void GetTransactionStatistics(Course course)
        {
            foreach(var model in transactionModels)
            {
                TransactionStatistics statistics = new()
                {
                    TransactionModel = model
                };

                for(var i=0;i<=model.Semesters;i++)
                {

                }
                
            }
        }

        private async void LoadFeeDetails(Course course, string academicYear)
        {
            FeesData feesData = null;
            await Task.Run(async () =>
            {
                try
                {
                    using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                    await connection.OpenAsync();

                    MySqlCommand command = connection.CreateCommand();
                    command.CommandText = "SELECT * FROM fees_structure WHERE course_id=@course AND academic_year=@academic_year AND active=1";
                    command.Parameters.AddWithValue("@course", course.Id);
                    command.Parameters.AddWithValue("@academic_year", academicYear);
                    using MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync();

                    if (reader.HasRows)
                    {
                        while (await reader.ReadAsync())
                        {
                            int idOrdinal = reader.GetOrdinal("id");
                            int dataOrdinal = reader.GetOrdinal("data");
                            int academicYearOrdinal = reader.GetOrdinal("academic_year");
                            int courseIdOrdinal = reader.GetOrdinal("course_id");
                            int dateOrdinal = reader.GetOrdinal("date");

                            feesData = new()
                            {
                                Id = reader.IsDBNull(idOrdinal) ? 0 : reader.GetInt32(idOrdinal),
                                Json = reader.IsDBNull(dataOrdinal) ? null : reader.GetString(dataOrdinal),
                                AcademicYear = reader.IsDBNull(academicYearOrdinal) ? null : reader.GetString(academicYearOrdinal),
                                CourseId = reader.IsDBNull(courseIdOrdinal) ? 0 : reader.GetInt32(courseIdOrdinal),
                                Date = reader.IsDBNull(dateOrdinal) ? DateTime.Now : reader.GetDateTime(dateOrdinal),
                            };
                        }
                    }
                    else
                    {
                        throw new FeesStructureUnavailableException("Sorry a fees structure for current course and academic year is not active or available.");
                    }

                    await reader.CloseAsync();
                }
                catch (Exception e)
                {
                    Debug.WriteLine(e.Message);
                    throw;
                }
            }).ContinueWith(t =>
            {
                if (t.Exception != null)
                {
                    if (t.Exception.InnerException != null)
                    {
                        ErrorInfoBar.IsOpen = true;
                        ErrorInfoBar.Message = t.Exception.InnerException.Message;
                    }
                    else
                    {
                        ErrorInfoBar.IsOpen = true;
                        ErrorInfoBar.Message = t.Exception.Message;
                    }
                }
                else
                {
                    ErrorInfoBar.IsOpen = false;

                    if (feesData != null)
                    {
                        ErrorInfoBar.IsOpen = false;
                    }
                    else
                    {
                        ErrorInfoBar.IsOpen = true;
                        ErrorInfoBar.Message = "Sorry there is no fees structure associated with the student course and academic year";
                    }
                }

            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        private double GetPaidFees(List<Payment> transactions, int semester, int studentId)
        {
            double total = 0;
            foreach (Payment payment in transactions)
            {
                if (payment.Semester == semester && payment.StudentId == studentId)
                {
                    total += payment.Amount;
                }
            }

            return total;
        }

        private static string GetSemesterFees(FeesData feesData, int semester)
        {
            double total = 0;
            Dictionary<string, object> feesStructure = JsonSerializer.Deserialize<Dictionary<string, object>>(feesData.Json);

            foreach (var row in feesStructure)
            {
                Dictionary<string, object> rowData = JsonSerializer.Deserialize<Dictionary<string, object>>(row.Value.ToString());
                foreach (var keyValuePair in rowData)
                {
                    if (!string.IsNullOrEmpty(keyValuePair.Key) && keyValuePair.Key == "fees")
                    {
                        Dictionary<string, object> fees = JsonSerializer.Deserialize<Dictionary<string, object>>(keyValuePair.Value.ToString());
                        foreach (var fee in fees)
                        {
                            if (fee.Key == $"sem{semester}")
                            {
                                total += Double.Parse(fee.Value.ToString());
                            }
                        }
                    }
                    else if (!string.IsNullOrEmpty(keyValuePair.Key) && keyValuePair.Key == "categories")
                    {
                        List<Dictionary<string, object>> categories = JsonSerializer.Deserialize<List<Dictionary<string, object>>>(keyValuePair.Value.ToString());

                        foreach (var category in categories)
                        {
                            foreach (var item in category)
                            {
                                if (!string.IsNullOrEmpty(item.Key) && item.Key == "fees")
                                {
                                    Dictionary<string, object> fees = JsonSerializer.Deserialize<Dictionary<string, object>>(item.Value.ToString());
                                    foreach (var fee in fees)
                                    {
                                        if (fee.Key == $"sem{semester}")
                                        {
                                            total += double.Parse(fee.Value.ToString());
                                        }
                                    }
                                }
                            }
                        }
                    }

                }
            }
            return total.ToString();
        }

        private void GetDetailsBtn_Click(object sender, RoutedEventArgs e)
        {
            var course = CourseList.SelectedItem as Course;
            FetchStudentDetails(course, int.Parse(AcademicYearList.SelectedValue.ToString()));
        }
    }
}
