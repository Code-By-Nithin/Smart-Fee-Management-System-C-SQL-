using CommunityToolkit.WinUI;
using Fees_DBASC.Core.Authentication;
using Fees_DBASC.Core.Database;
using Fees_DBASC.Data.Models;
using Fees_DBASC.Data.Sources;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Input;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace Fees_DBASC.Views.Pages
{
    public sealed partial class Courses : Page
    {
        private IncrementalLoadingCollection<CourseDataSource, Course> collection;
        private CourseDataSource courseDataSource;

        public Courses()
        {
            this.InitializeComponent();
        }

        private async void PageLoaded(object sender, RoutedEventArgs e)
        {
            HandleUserRoleType();
            await Task.Run(() =>
            {
                courseDataSource = new CourseDataSource();
                collection = new IncrementalLoadingCollection<CourseDataSource, Course>(courseDataSource, 20, null, null, null);
                collection.OnStartLoading += CollectionLoading;
                collection.OnEndLoading += CollectionLoaded;
                collection.OnError += OnError;
            });

            CourseList.ItemsSource = collection;
            await CourseList.LoadMoreItemsAsync();
        }

        private void OnError(Exception e)
        {
            if (collection.Count > 0)
            {
                ListErrorMessage.Visibility = Visibility.Collapsed;
                ErrorInfoBar.Message = e.Message;
                ErrorInfoBar.IsOpen = true;
            }
            else
            {
                ListErrorMessage.Visibility = Visibility.Visible;
                ErrorMessage.Text = e.Message;
            }
        }

        private void CollectionLoading()
        {
            ProgressBar.IsIndeterminate = true;
            ProgressBar.Visibility = Visibility.Visible;
        }

        private void CollectionLoaded()
        {
            Task.Delay(800).ContinueWith(t =>
            {
                ProgressBar.Visibility = Visibility.Collapsed;
                ProgressBar.IsIndeterminate = false;
            }, TaskScheduler.FromCurrentSynchronizationContext());

            if (SelectAllCheckbox.IsChecked == true)
            {
                CourseList.SelectAll();
            }

            if (collection.Count <= 0 && ListErrorMessage.Visibility == Visibility.Collapsed)
            {
                EmptyListMessage.Visibility = Visibility.Visible;
            }
            else
            {
                EmptyListMessage.Visibility = Visibility.Collapsed;
            }
        }

        private void SelectAll(object sender, RoutedEventArgs e)
        {
            CourseList.SelectAll();
        }

        private void UnSelectAll(object sender, RoutedEventArgs e)
        {
            CourseList.SelectedItems.Clear();
        }

        private void CourseListSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CourseList.SelectedItems.Count <= 0)
            {
                SelectAllCheckbox.IsChecked = false;
            }
            else if (collection.Count == CourseList.SelectedItems.Count)
            {
                SelectAllCheckbox.IsChecked = true;
            }
            else if (collection.Count > CourseList.SelectedItems.Count)
            {
                SelectAllCheckbox.IsChecked = null;
            }
        }

        private void CourseListRightTapped(object sender, RightTappedRoutedEventArgs e)
        {
            if (GlobalUserRole.Role != 0)
            {
                ListView listView = (ListView)sender;
                Delete.IsEnabled = listView.SelectedItems.Count > 0;
                Edit.IsEnabled = listView.SelectedItems.Count == 1;
                ContextMenu.ShowAt(listView, e.GetPosition(listView));
            }
        }

        private async void DeleteCourses(bool deleteAll)
        {
            var coursesToRemove = CourseList.SelectedItems.Cast<Course>().Join(collection, c => c.Id, ci => ci.Id, (c, ci) => ci).ToList();
            string idList = string.Join(",", coursesToRemove.Select(x => x.Id));

            await Task.Run(async () =>
            {
                using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                await connection.OpenAsync();

                MySqlCommand command = connection.CreateCommand();
                MySqlTransaction transaction = connection.BeginTransaction();
                command.Connection = connection;
                command.Transaction = transaction;

                // Add additional remove options here
                try
                {
                    if (deleteAll)
                    {
                        command.CommandText = "TRUNCATE TABLE courses;";
                        await command.ExecuteNonQueryAsync();
                        command.CommandText = "TRUNCATE TABLE students;";
                        await command.ExecuteNonQueryAsync();
                    }
                    else
                    {
                        command.CommandText = $"DELETE FROM courses WHERE id in({idList});";
                        await command.ExecuteNonQueryAsync();
                        command.CommandText = $"DELETE FROM students WHERE course_id in({idList});";
                        await command.ExecuteNonQueryAsync();
                    }

                    await transaction.CommitAsync();
                }
                catch (Exception)
                {
                    transaction.Rollback();
                    throw;
                }
            }).ContinueWith(t =>
            {
                if (t.Exception != null)
                {
                    InfoBar.IsOpen = false;
                    ErrorInfoBar.IsOpen = true;
                    ErrorInfoBar.Message = t.Exception.Message;
                }
                else
                {
                    int selectedItemsCount = CourseList.SelectedItems.Count;
                    coursesToRemove.ForEach(c => collection.Remove(c));
                    CourseList.UpdateLayout();

                    ErrorInfoBar.IsOpen = false;
                    InfoBar.IsOpen = true;
                    InfoBar.Title = "Delete Course";

                    if (selectedItemsCount > 1)
                    {
                        InfoBar.Message = $"{selectedItemsCount} Courses has been removed.";
                    }
                    else
                    {
                        InfoBar.Message = $"{selectedItemsCount} Course has been removed.";
                    }

                    if (collection.Count <= 0)
                    {
                        EmptyListMessage.Visibility = Visibility.Visible;
                    }
                    else
                    {
                        EmptyListMessage.Visibility = Visibility.Collapsed;
                    }
                }
            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        private async void EditCourse(object sender, RoutedEventArgs e)
        {
            string courseType = "Other";
            AddCourseErrorInfo.IsOpen = false;
            
            Course course = CourseList.SelectedItem as Course;
            switch (course.Type)
            {
                case 0:
                    courseType = "Under Graduate";
                    break;
                case 1:
                    courseType = "Post Graduate";
                    break;
                case 2:
                    courseType = "Other";
                    break;
            }

            CourseName.Text = course.Name;
            CourseSemesters.SelectedItem = course.Semesters.ToString();
            CourseType.SelectedItem =courseType;
            AddCourseDialog.Tag = "edit";
            await AddCourseDialog.ShowAsync();
        }

        private async void DeleteCourse(object sender, RoutedEventArgs e)
        {
            var result = await DeleteConfirmDialog.ShowAsync();
            if (result == ContentDialogResult.Primary)
            {
                if (SelectAllCheckbox.IsChecked == true)
                {
                    DeleteCourses(true);
                }
                else
                {
                    DeleteCourses(false);
                }
            }
        }

        private async void AddOrEditCourse(bool edit)
        {
            Course course = (edit) ? CourseList.SelectedItem as Course : null;
            int id = (course != null) ? course.Id : 0;

            string courseName = CourseName.Text;
            string semesters = CourseSemesters.SelectedItem.ToString();
            int courseType = 2;

            switch(CourseType.SelectedItem.ToString())
            {
                case "Under Graduate":
                    courseType = 0;
                    break;
                case "Post Graduate":
                    courseType = 1;
                    break;
                case "Other":
                    courseType = 2;
                    break;
            }

            await Task.Run(async () =>
            {
                using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                await connection.OpenAsync();

                MySqlCommand command = connection.CreateCommand();

                if (edit)
                {
                    command.CommandText = $"UPDATE courses SET name=@name,semesters=@semesters,type=@type WHERE id=@id;";
                    command.Parameters.AddWithValue("@id", id);
                    command.Parameters.AddWithValue("@name", courseName);
                    command.Parameters.AddWithValue("@semesters", semesters);
                    command.Parameters.AddWithValue("@type", courseType);
                }
                else
                {
                    command.CommandText = $"INSERT INTO courses (name,semesters,type) VALUES(@name,@semesters,@type);";
                    command.Parameters.AddWithValue("@name", courseName);
                    command.Parameters.AddWithValue("@semesters", semesters);
                    command.Parameters.AddWithValue("@type", courseType);
                }

                await command.ExecuteNonQueryAsync();
            }).ContinueWith(async t =>
            {
                if (t.Exception != null)
                {
                    InfoBar.IsOpen = false;
                    ErrorInfoBar.IsOpen = true;
                    ErrorInfoBar.Message = t.Exception.Message;
                }
                else
                {
                    if (edit)
                    {
                        InfoBar.Message = $"Course Updated Successfully";
                    }
                    else
                    {
                        InfoBar.Message = $"Course Added Successfully";
                    }

                    courseDataSource.EmptyCollection();
                    await collection.RefreshAsync();
                    InfoBar.IsOpen = true;
                }

                foreach (var c in collection)
                {
                    Debug.WriteLine(c.Name);
                }
            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        private async void AddCourseClicked(object sender, RoutedEventArgs e)
        {
            AddCourseErrorInfo.IsOpen = false;
            CourseName.Text = null;
            CourseSemesters.SelectedItem = null;
            CourseType.SelectedItem = null;
            AddCourseDialog.Tag = "add";
            await AddCourseDialog.ShowAsync();
        }

        private void AddCourse(ContentDialog sender, ContentDialogButtonClickEventArgs args)
        {
            List<string> errors = new();

            if (string.IsNullOrEmpty(CourseName.Text)) errors.Add("course name");
            if (CourseSemesters.SelectedItem == null) errors.Add("semesters");
            if (CourseType.SelectedItem == null) errors.Add("course type");

            if (errors.Any())
            {
                args.Cancel = true;
                AddCourseErrorInfo.Message = $"Please fill out the {string.Join(" and ", errors)}.";
                AddCourseErrorInfo.IsOpen = true;
            }
            else
            {
                args.Cancel = false;

                if (AddCourseDialog.Tag.ToString() == "edit")
                {
                    AddOrEditCourse(true);
                }
                else
                {
                    AddOrEditCourse(false);
                }
            }
        }

        private void HandleUserRoleType()
        {
            if (GlobalUserRole.Role == 0)
            {
                AddCourseButton.Visibility = Visibility.Collapsed;
                Edit.Visibility = Visibility.Collapsed;
                Delete.Visibility = Visibility.Collapsed;
            }
        }
    }
}
