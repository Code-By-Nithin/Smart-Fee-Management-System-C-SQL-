using Fees_DBASC.Core.Database;
using Fees_DBASC.Core.Routing;
using Fees_DBASC.Data.Models;
using Fees_DBASC.Data.Parsers;
using Fees_DBASC.Interfaces;
using Microsoft.UI;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;
using Windows.ApplicationModel.DataTransfer;
using Windows.Storage;
using Windows.Storage.Pickers;
using Windows.UI.ViewManagement;
using WinRT;
using static Fees_DBASC.Core.Interop.NativeMethods;


namespace Fees_DBASC.Views.Pages
{
    public sealed partial class FeesStructureUploader : Page
    {
        private StorageFile csvFile;

        public FeesStructureUploader()
        {
            this.InitializeComponent();
        }

        private static async Task<string> GetFileSizeAsync(StorageFile file)
        {
            var sizeInBytes = (await file.GetBasicPropertiesAsync()).Size;
            string[] sizes = { "B", "KB", "MB", "GB", "TB" };
            int order = 0;
            while (sizeInBytes >= 1024 && order < sizes.Length - 1)
            {
                sizeInBytes /= 1024;
                order++;
            }
            string fileSize = $"{sizeInBytes:0.##} {sizes[order]}";
            return fileSize;
        }

        private async void HandleBrowseFile(object sender, RoutedEventArgs e)
        {
            ((Button)sender).IsEnabled = false;
            FileOpenPicker csvPicker = new()
            {
                ViewMode = PickerViewMode.Thumbnail,
                SuggestedStartLocation = PickerLocationId.DocumentsLibrary
            };

            csvPicker.FileTypeFilter.Add(".csv");
            csvPicker.As<IInitializeWithWindow>().Initialize(GetActiveWindow());

            csvFile = await csvPicker.PickSingleFileAsync().AsTask().ConfigureAwait(true);
            if (csvFile != null)
            {
                if (csvFile.FileType == ".csv")
                {
                    FilesCount.Text = "1 File selected";
                    FileName.Text = csvFile.Name;
                    FileDetails.Visibility = Visibility.Visible;
                    FileSize.Text = await GetFileSizeAsync(csvFile).ConfigureAwait(true);
                }
                else
                {
                    uploadError.Severity = InfoBarSeverity.Error;
                    uploadError.Message = $"Sorry only .CSV files are accepted.";
                    uploadError.IsOpen = true;
                }
            }
            else
            {
                FileDetails.Visibility = Visibility.Collapsed;
                FilesCount.Text = "No file has been selected yet";
                uploadError.Severity = InfoBarSeverity.Informational;
                uploadError.Message = $"Operation cancelled by user.";
                uploadError.IsOpen = true;
            }
            ((Button)sender).IsEnabled = true;
        }

        private void HandleFileDragOver(object sender, DragEventArgs e)
        {
            e.AcceptedOperation = DataPackageOperation.Copy;
        }

        private async void HandleFileDropped(object sender, DragEventArgs e)
        {
            uploadError.IsOpen = false;
            uploadError.Severity = InfoBarSeverity.Error;
            if (e.DataView.Contains(StandardDataFormats.StorageItems))
            {
                var items = await e.DataView.GetStorageItemsAsync();
                if (items.Count <= 1)
                {
                    if (items[0] is StorageFile)
                    {
                        csvFile = items[0] as StorageFile;

                        if (csvFile != null)
                        {
                            if (csvFile.FileType == ".csv")
                            {
                                FilesCount.Text = "1 File selected";
                                FileName.Text = csvFile.Name;
                                FileSize.Text = await GetFileSizeAsync(csvFile).ConfigureAwait(true);

                                FileDetails.Visibility = Visibility.Visible;
                            }
                            else
                            {
                                uploadError.Severity = InfoBarSeverity.Error;
                                uploadError.Message = $"Sorry only .CSV files are accepted.";
                                uploadError.IsOpen = true;
                            }
                        }
                    }
                }
                else
                {
                    uploadError.Message = $"Sorry, only 1 file can be upload at a time";
                    uploadError.IsOpen = true;
                }
            }
        }

        private void HandleRemoveSelectedFile(object sender, RoutedEventArgs e)
        {
            csvFile = null;
            FileDetails.Visibility = Visibility.Collapsed;
            FilesCount.Text = "No file has been selected yet";
        }

        private void HandleFileSubmitted(object sender, RoutedEventArgs e)
        {
            if (csvFile != null)
            {
                FilePicker.Visibility = Visibility.Collapsed;
                FileValidator.Visibility = Visibility.Visible;
                ValidateFile();
            }
            else
            {
                uploadError.Severity = InfoBarSeverity.Error;
                uploadError.Message = "Please select at least 1 file to continue";
                uploadError.IsOpen = true;
            }
        }

        private void HandleGoBack(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(this, new UploadFeesStructure());
        }

        private void SetValidationStatus(bool failed)
        {

            if (failed)
            {
                ValidationStatusBackground.Fill = new SolidColorBrush(Colors.Red);
                ValidationStatusIcon.Glyph = "\uf13d";
                ValidationStatusIcon.Margin = new Thickness(0);
            }
            else
            {
                UISettings uiSettings = new();
                ValidationStatusBackground.Fill = new SolidColorBrush(uiSettings.GetColorValue(UIColorType.Accent));
                ValidationStatusIcon.Glyph = "\uf13e";
                ValidationStatusIcon.Margin = new Thickness(1);
            }

            ValidationProgress.Visibility = Visibility.Collapsed;
            ValidationStatus.Visibility = Visibility.Visible;
        }

        private void SetUploadStatus(bool failed)
        {

            if (failed)
            {
                UploadStatusBackground.Fill = new SolidColorBrush(Colors.Red);
                UploadStatusIcon.Glyph = "\uf13d";
                ValidationStatusIcon.Margin = new Thickness(0);
            }
            else
            {
                UISettings uiSettings = new();
                UploadStatusBackground.Fill = new SolidColorBrush(uiSettings.GetColorValue(UIColorType.Accent));
                UploadStatusIcon.Glyph = "\uf13e";
                ValidationStatusIcon.Margin = new Thickness(1);
            }

            UploadProgress.Visibility = Visibility.Collapsed;
            UploadStatus.Visibility = Visibility.Visible;
        }

        private async void ValidateFile()
        {
            FeesStructureParser feesStructureParser = new(csvFile);
            List<FeesData> courseData = null;

            await Task.Run(async () =>
            {
                var feesData = feesStructureParser.GetFeesStructureList();
                courseData = await feesStructureParser.FillCourseData(feesData);

            }).ContinueWith(t =>
            {
                if (t.Exception != null)
                {
                    DataUploadInfoBar.Severity = InfoBarSeverity.Error;
                    DataUploadInfoBar.Message = t.Exception.Message;
                    DataUploadInfoBar.IsOpen = true;
                    ErrorCta.Visibility = Visibility.Visible;
                    Debug.WriteLine(t.Exception.Message);
                    SetValidationStatus(true);
                    SetUploadStatus(true);
                }
                else
                {

                    if (courseData != null)
                    {
                        UploadFeesStructureAsync(courseData);
                    }

                    SetValidationStatus(false);
                }
            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        private async void UploadFeesStructureAsync(List<FeesData> data)
        {
            await Task.Run(async () =>
            {
                using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                await connection.OpenAsync();

                MySqlCommand command = connection.CreateCommand();
                MySqlTransaction transaction = connection.BeginTransaction();
                command.Connection = connection;
                command.Transaction = transaction;

                try
                {
                    foreach (FeesData feesData in data)
                    {
                        command.CommandText = "INSERT INTO fees_structure(course_id,academic_year,active,data) VALUES(@course_id,@academic_year,@active,@data) ON DUPLICATE KEY UPDATE course_id=VALUES(course_id),academic_year=VALUES(academic_year),active=VALUES(active),data=VALUES(data);";
                        command.Parameters.Clear();
                        command.Parameters.AddWithValue("@course_id", feesData.CourseId);
                        command.Parameters.AddWithValue("@academic_year", feesData.AcademicYear);
                        command.Parameters.AddWithValue("@active", feesData.Active);
                        command.Parameters.AddWithValue("@data", feesData.Json);
                        command.ExecuteNonQuery();
                    }
                }
                catch (Exception e)
                {
                    Debug.WriteLine(e.Message);
                    transaction.Rollback();
                    throw;
                }
            }).ContinueWith(t =>
            {
                if (t.Exception != null)
                {
                    DataUploadInfoBar.Severity = InfoBarSeverity.Error;
                    DataUploadInfoBar.Message = t.Exception.Message;
                    DataUploadInfoBar.IsOpen = true;
                    ErrorCta.Visibility = Visibility.Visible;
                    Debug.WriteLine(t.Exception.Message);
                    SetUploadStatus(true);
                }
                else
                {
                    ErrorCta.Visibility = Visibility.Collapsed;
                    SuccessCta.Visibility = Visibility.Visible;
                    DataUploadInfoBar.Severity = InfoBarSeverity.Success;
                    DataUploadInfoBar.Message = "Fees Structure Uploaded Successfully";
                    DataUploadInfoBar.IsOpen = true;
                    SetUploadStatus(false);
                }
            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        private void HandleViewFeesStructures(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(this, new FeesStructures());
        }

        private void FinishClicked(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(this, new FeesStructureUploader());
        }
    }
}
