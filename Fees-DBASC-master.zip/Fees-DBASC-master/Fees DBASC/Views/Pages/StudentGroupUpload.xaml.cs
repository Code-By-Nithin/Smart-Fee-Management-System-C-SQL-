using CsvHelper;
using Fees_DBASC.Core.Database;
using Fees_DBASC.Core.Exceptions;
using Fees_DBASC.Core.Routing;
using Fees_DBASC.Data.Comparators;
using Fees_DBASC.Data.Mappers;
using Fees_DBASC.Data.Models;
using Fees_DBASC.Interfaces;
using Microsoft.UI;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Windows.ApplicationModel.DataTransfer;
using Windows.Storage;
using Windows.Storage.Pickers;
using Windows.UI.StartScreen;
using Windows.UI.ViewManagement;
using WinRT;
using static Fees_DBASC.Core.Interop.NativeMethods;

namespace Fees_DBASC.Views.Pages
{
    public sealed partial class StudentGroupUpload : Page
    {
        private StorageFile csvFile;

        public StudentGroupUpload()
        {
            this.InitializeComponent();
        }

        private void HandleFileDragOver(object sender, DragEventArgs e)
        {
            e.AcceptedOperation = DataPackageOperation.Copy;
        }

        private void HandleGoBack(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(this, new UploadStudentDetails());
        }

        private static async Task<string> GetFileSizeAsync(StorageFile file)
        {
            var sizeInBytes = (await file.GetBasicPropertiesAsync()).Size;
            string[] sizes = { "B", "KB", "MB", "GB", "TB" };
            int order = 0;
            while (sizeInBytes >= 1024 && order < sizes.Length - 1)
            {
                sizeInBytes /= 1024;
                order++;
            }
            string fileSize = $"{sizeInBytes:0.##} {sizes[order]}";
            return fileSize;
        }

        private async void HandleFileDropped(object sender, DragEventArgs e)
        {
            uploadError.IsOpen = false;
            uploadError.Severity = InfoBarSeverity.Error;
            if (e.DataView.Contains(StandardDataFormats.StorageItems))
            {
                var items = await e.DataView.GetStorageItemsAsync();
                if (items.Count <= 1)
                {
                    if (items[0] is StorageFile)
                    {
                        csvFile = items[0] as StorageFile;

                        if (csvFile != null)
                        {
                            if (csvFile.FileType == ".csv")
                            {
                                FilesCount.Text = "1 File selected";
                                FileName.Text = csvFile.Name;
                                FileSize.Text = await GetFileSizeAsync(csvFile);
                                FileDetails.Visibility = Visibility.Visible;
                            }
                            else
                            {
                                uploadError.Severity = InfoBarSeverity.Error;
                                uploadError.Message = $"Sorry only .CSV files are accepted.";
                                uploadError.IsOpen = true;
                            }
                        }
                    }
                }
                else
                {
                    uploadError.Message = $"Sorry, only 1 file can be upload at a time";
                    uploadError.IsOpen = true;
                }
            }
        }

        private async void HandleBrowseFile(object sender, RoutedEventArgs e)
        {
            ((Button)sender).IsEnabled = false;

            FileOpenPicker csvPicker = new FileOpenPicker()
            {
                ViewMode = PickerViewMode.Thumbnail,
                SuggestedStartLocation = PickerLocationId.DocumentsLibrary
            };

            csvPicker.FileTypeFilter.Add(".csv");
            csvPicker.As<IInitializeWithWindow>().Initialize(GetActiveWindow());

            csvFile = await csvPicker.PickSingleFileAsync().AsTask().ConfigureAwait(true);

            if (csvFile != null)
            {
                if (csvFile.FileType == ".csv")
                {
                    FilesCount.Text = "1 File selected";
                    FileName.Text = csvFile.Name;
                    FileDetails.Visibility = Visibility.Visible;
                    FileSize.Text = await GetFileSizeAsync(csvFile).ConfigureAwait(true);
                }
                else
                {
                    uploadError.Severity = InfoBarSeverity.Error;
                    uploadError.Message = $"Sorry only .CSV files are accepted.";
                    uploadError.IsOpen = true;
                }
            }
            else
            {
                FileDetails.Visibility = Visibility.Collapsed;
                FilesCount.Text = "No file has been selected yet";
                uploadError.Severity = InfoBarSeverity.Informational;
                uploadError.Message = $"Operation cancelled by user.";
                uploadError.IsOpen = true;
            }

            ((Button)sender).IsEnabled = true;
        }

        private void HandleRemoveSelectedFile(object sender, RoutedEventArgs e)
        {
            csvFile = null;
            FileDetails.Visibility = Visibility.Collapsed;
            FilesCount.Text = "No file has been selected yet";
        }

        private void HandleFileSubmitted(object sender, RoutedEventArgs e)
        {
            if(csvFile != null)
            {
                FilePicker.Visibility = Visibility.Collapsed;
                FileValidator.Visibility = Visibility.Visible;
                ValidateFile();
            }
            else
            {
                uploadError.Severity = InfoBarSeverity.Error;
                uploadError.Message = "Please select at least 1 file to continue";
                uploadError.IsOpen = true;
            }
        }

        private void SetValidationStatus(bool failed)
        {

            if (failed)
            {
                ValidationStatusBackground.Fill = new SolidColorBrush(Colors.Red);
                ValidationStatusIcon.Glyph = "\uf13d";
                ValidationStatusIcon.Margin = new Thickness(0);
            }
            else
            {
                UISettings uiSettings = new();
                ValidationStatusBackground.Fill = new SolidColorBrush(uiSettings.GetColorValue(UIColorType.Accent));
                ValidationStatusIcon.Glyph = "\uf13e";
                ValidationStatusIcon.Margin = new Thickness(1);
            }

            ValidationProgress.Visibility = Visibility.Collapsed;
            ValidationStatus.Visibility = Visibility.Visible;
        }

        private void SetUploadStatus(bool failed)
        {

            if (failed)
            {
                UploadStatusBackground.Fill = new SolidColorBrush(Colors.Red);
                UploadStatusIcon.Glyph = "\uf13d";
                ValidationStatusIcon.Margin = new Thickness(0);
            }
            else
            {
                UISettings uiSettings = new();
                UploadStatusBackground.Fill = new SolidColorBrush(uiSettings.GetColorValue(UIColorType.Accent));
                UploadStatusIcon.Glyph = "\uf13e";
                ValidationStatusIcon.Margin = new Thickness(1);
            }

            UploadProgress.Visibility = Visibility.Collapsed;
            UploadStatus.Visibility = Visibility.Visible;
        }

        private async void UploadStudentDetailsAsync(List<Student> students)
        {
            await Task.Run(async () =>
            {
                List<Course> courseList = new();

                using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                await connection.OpenAsync();

                MySqlCommand courseFetchCommand = connection.CreateCommand();
                courseFetchCommand.CommandText = "SELECT * FROM courses";
                using MySqlDataReader reader = (MySqlDataReader)await courseFetchCommand.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    Course course = new()
                    {
                        Id = reader.GetInt32("id"),
                        Name = reader.GetString("name"),
                        Semesters = reader.GetInt32("semesters"),
                        Timestamp = DateTime.Parse(reader.GetString("timestamp"))
                    };
                    courseList.Add(course);
                }

                reader.Close();
                courseFetchCommand.Dispose();

                MySqlCommand command = connection.CreateCommand();
                MySqlTransaction transaction = connection.BeginTransaction();
                command.Connection = connection;
                command.Transaction = transaction;

                try
                {
                    foreach (Student student in students)
                    {
                        Course studentCourse = new()
                        {
                            Proximity = 0
                        };

                        foreach (Course course in courseList)
                        {
                            string courseName = (student.Standard==student.Division)?student.Standard: student.Standard + " " + student.Division;
                            double proximity = JaroWinklerDistance.Proximity(Regex.Replace(courseName, @"[^0-9a-zA-Z]+", ""), Regex.Replace(course.Name, @"[^0-9a-zA-Z]+", ""));
                            course.Proximity = proximity;

                            if (proximity == 1)
                            {
                                studentCourse = course;
                                student.CourseId = studentCourse.Id;
                            }
                        }

                        if(student.CourseId== 0)
                        {
                            string courseName = (student.Standard == student.Division) ? student.Standard : student.Standard + " " + student.Division;
                            throw new CourseProximityException($"A course named '{courseName}' doesn't exist, please add the course to continue");
                        }

                        string academicYear = student.AcademicYear.Split(" - ")[0];
                        if(string.IsNullOrEmpty(academicYear))
                        {
                            academicYear = student.AcademicYear.Split("-")[0];
                        }
                        command.CommandText = "INSERT INTO students(id,school_code,student_name,academic_year,fathers_name,mothers_name,address_line1,address_line2,city,state,zip_code,phone,mobile,email,course_id,standard,division) VALUES(@id,@school_code,@name,@academic_year,@fathers_name,@mothers_name,@address_line1,@address_line2,@city,@state,@zip_code,@phone,@mobile,@email,@course_id,@standard,@division) ON DUPLICATE KEY UPDATE school_code=VALUES(school_code),student_name=VALUES(student_name),academic_year=VALUES(academic_year),fathers_name=VALUES(fathers_name),mothers_name=VALUES(mothers_name),address_line1=VALUES(address_line1),address_line2=VALUES(address_line2),city=VALUES(city),state=VALUES(state),zip_code=VALUES(zip_code),phone=VALUES(phone),mobile=VALUES(mobile),email=VALUES(email),course_id=VALUES(course_id),standard=VALUES(standard),division=VALUES(division);";
                        command.Parameters.Clear();
                        command.Parameters.AddWithValue("@id", student.Id);
                        command.Parameters.AddWithValue("@school_code", student.SchoolCode);
                        command.Parameters.AddWithValue("@name", student.Name);
                        command.Parameters.AddWithValue("@academic_year", academicYear);
                        command.Parameters.AddWithValue("@fathers_name", student.FathersName);
                        command.Parameters.AddWithValue("@mothers_name", student.MothersName);
                        command.Parameters.AddWithValue("@address_line1", student.Address1);
                        command.Parameters.AddWithValue("@address_line2", student.Address2);
                        command.Parameters.AddWithValue("@city", student.City);
                        command.Parameters.AddWithValue("@state", student.State);
                        command.Parameters.AddWithValue("@zip_code", student.ZipCode);
                        command.Parameters.AddWithValue("@phone", student.Phone);
                        command.Parameters.AddWithValue("@mobile", student.Mobile);
                        command.Parameters.AddWithValue("@email", student.Email);
                        command.Parameters.AddWithValue("@course_id", student.CourseId);
                        command.Parameters.AddWithValue("@standard", student.Standard);
                        command.Parameters.AddWithValue("@division", student.Division);
                        command.ExecuteNonQuery();
                    }

                    transaction.Commit();
                }
                catch (Exception)
                {
                    transaction.Rollback();
                    throw;
                }

            }).ContinueWith(t =>
            {
                if (t.Exception != null)
                {
                    DataUploadInfoBar.Severity = InfoBarSeverity.Error;
                    DataUploadInfoBar.Message = t.Exception.Message;
                    DataUploadInfoBar.IsOpen = true;
                    ErrorCta.Visibility = Visibility.Visible;
                    SetUploadStatus(true);
                }
                else
                {
                    ErrorCta.Visibility = Visibility.Collapsed;
                    SuccessCta.Visibility = Visibility.Visible;
                    DataUploadInfoBar.Severity = InfoBarSeverity.Success;
                    DataUploadInfoBar.Message = "Student Data Uploaded Successfully";
                    DataUploadInfoBar.IsOpen = true;
                    SetUploadStatus(false);
                }
            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        private void ValidateFile()
        {

            SetValidationStatus(false);
            SetUploadStatus(false);

            List<Student> students;

            if (csvFile != null)
            {
                try
                {
                    using var reader = new StreamReader(csvFile.Path);
                    using var csv = new CsvReader(reader, CultureInfo.InvariantCulture);

                    csv.Context.RegisterClassMap<StudentDataMapper>();
                    csv.Context.Configuration.IgnoreBlankLines = true;
                    students = csv.GetRecords<Student>().ToList();

                    if (students.GroupBy(obj => obj.Id).Any(group => group.Count() > 1))
                    {
                        SetValidationStatus(true);
                        SetUploadStatus(true);
                        ErrorCta.Visibility = Visibility.Visible;
                        DataUploadInfoBar.Severity = InfoBarSeverity.Error;
                        DataUploadInfoBar.Message = "Upload Failed since there are more than one student having the same student id in the file.";
                        DataUploadInfoBar.IsOpen = true;
                    }
                    else
                    {
                        students.ForEach(student =>
                        {
                            student.SchoolCode = string.IsNullOrWhiteSpace(student.SchoolCode) ? null : student.SchoolCode;
                            student.Name = string.IsNullOrWhiteSpace(student.Name) ? null : student.Name;
                            student.AcademicYear = string.IsNullOrWhiteSpace(student.AcademicYear) ? null : student.AcademicYear.TrimEnd();
                            student.Standard = string.IsNullOrWhiteSpace(student.Standard) ? null : student.Standard;
                            student.Division = string.IsNullOrWhiteSpace(student.Division) ? null : student.Division;
                            student.FathersName = string.IsNullOrWhiteSpace(student.FathersName) ? null : student.FathersName;
                            student.MothersName = string.IsNullOrWhiteSpace(student.MothersName) ? null : student.MothersName;
                            student.Address1 = string.IsNullOrWhiteSpace(student.Address1) ? null : student.Address1;
                            student.Address2 = string.IsNullOrWhiteSpace(student.Address2) ? null : student.Address2;
                            student.City = string.IsNullOrWhiteSpace(student.City) ? null : student.City;
                            student.State = string.IsNullOrWhiteSpace(student.State) ? null : student.State;
                            student.ZipCode = string.IsNullOrWhiteSpace(student.ZipCode) ? null : student.ZipCode;
                            student.Phone = string.IsNullOrWhiteSpace(student.Phone) ? null : student.Phone;
                            student.Mobile = string.IsNullOrWhiteSpace(student.Mobile) ? null : student.Mobile;
                            student.Email = string.IsNullOrWhiteSpace(student.Email) ? null : student.Email;
                            student.Standard = string.IsNullOrWhiteSpace(student.Standard) ? null : student.Standard;
                            student.Division = string.IsNullOrWhiteSpace(student.Division) ? null : student.Division;
                        });

                        ErrorCta.Visibility = Visibility.Collapsed;
                        DataUploadInfoBar.IsOpen = false;
                        SetValidationStatus(false);
                        UploadStudentDetailsAsync(students);
                    }
                }
                catch (Exception ex)
                {
                    if(ex is HeaderValidationException)
                    {
                        ErrorCta.Visibility = Visibility.Visible;
                        DataUploadInfoBar.Severity = InfoBarSeverity.Error;
                        DataUploadInfoBar.Message = "The File consist of invalid headers please check the column headings and try again";
                        DataUploadInfoBar.IsOpen = true;
                        SetValidationStatus(true);
                        SetUploadStatus(true);
                    }
                    else
                    {
                        Debug.WriteLine(ex.Message);
                        SetValidationStatus(true);
                        SetUploadStatus(true);
                        ErrorCta.Visibility = Visibility.Visible;
                        DataUploadInfoBar.Severity = InfoBarSeverity.Error;
                        DataUploadInfoBar.Message = ex.Message;
                        DataUploadInfoBar.IsOpen = true;
                    }
                }

            }
        }

        private void GoBackToUploads(object sender, RoutedEventArgs e)
        {
            FileValidator.Visibility = Visibility.Collapsed;
            FilePicker.Visibility = Visibility.Visible;
        }

        private void FinishClicked(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(this, new UploadStudentDetails());
        }

        private void ViewStudentsClicked(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(this, new Students());
        }
    }
}
