// Copyright (c) Microsoft Corporation and Contributors.
// Licensed under the MIT License.

using Fees_DBASC.Core.Routing;
using Fees_DBASC.Data.Models;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media.Animation;
using System.Collections.Generic;
using static iText.StyledXmlParser.Jsoup.Select.Evaluator;
using System.Linq.Expressions;
using NavigationEventArgs = Microsoft.UI.Xaml.Navigation.NavigationEventArgs;
using System;
using System.Linq;
using Fees_DBASC.Core.Authentication;

namespace Fees_DBASC.Views.Pages
{
    public sealed partial class Dashboard : Page
    {
        private MainWindow window;
        private List<Route> routes;

        public Dashboard()
        {
            this.InitializeComponent();
            this.InitializeRoutes();

        }

        private void InitializeRoutes()
        {
            routes = new List<Route>
            {
                new Route()
                {
                    Id = "Home",
                    Name = "Home",
                    Page = typeof(Home)
                },
                new Route()
                {
                    Id = "Courses",
                    Name = "Courses",
                    Page = typeof(Courses)
                },
                new Route()
                {
                    Id = "Students",
                    Name = "Students",
                    Page = typeof(Students)
                },
                new Route()
                {   
                    Id = "BankAccounts",
                    Name = "Bank Accounts",
                    Page = typeof(BankAccounts)
                },
                new Route()
                {   
                    Id = "FeesStructures",
                    Name = "Fees Structures",
                    Page = typeof(FeesStructures)
                },
                new Route()
                {
                    Id = "FeesReceipts",
                    Name = "Fees Receipts",
                    Page = typeof(FeesReceipts)
                },
                new Route()
                {   
                    Id = "FeePayment",
                    Name = "Fees Payment",
                    Page = typeof(FeePayment)
                },
                new Route()
                {
                    Id = "GenerateReport",
                    Name = "Generate Report",
                    Page = typeof(GenerateReport)
                },
                new Route()
                {   
                    Id = "UploadStudentDetails",
                    Name = "Upload Student Details",
                    Page = typeof(UploadStudentDetails)
                },
                new Route()
                {
                    Id = "UploadFeesStructure",
                    Name = "Upload Fees Structure",
                    Page = typeof(UploadFeesStructure)
                },
                new Route()
                {
                    Id = "PaymentStatistics",
                    Name = "Payment Statistics",
                    Page = typeof(PaymentStatisticsx)
                },
                new Route()
                {
                    Id = "ManageAccount",
                    Name = "Manage Account",
                    Page = typeof(ManageAccount)
                },
                new Route()
                {
                    Id = "CautionDeposits",
                    Name = "Caution Deposits",
                    Page = typeof(CautionDeposits)
                }
            };
        }

        private void ContentPresenterNavigated(object sender, NavigationEventArgs e)
        {
            var pageType = e.SourcePageType;

            foreach (var topLevelItem in Navigation.MenuItems)
            {
                if (topLevelItem is NavigationViewItem navigationViewItem)
                {
                    if (navigationViewItem.Tag?.ToString() == pageType.Name)
                    {
                        navigationViewItem.IsExpanded = true;
                        Navigation.SelectedItem = navigationViewItem;
                        window?.SetBackButtonStatus(false);
                        return;
                    }

                    foreach (var subItem in navigationViewItem.MenuItems)
                    {
                        if (subItem is NavigationViewItem subNavigationViewItem && subNavigationViewItem.Tag?.ToString() == pageType.Name)
                        {
                            navigationViewItem.IsExpanded = true;
                            Navigation.SelectedItem = subNavigationViewItem;
                            window?.SetBackButtonStatus(false);
                            return;
                        }
                    }
                }
            }

            window?.SetBackButtonStatus(true);

        }

        private void NavigationSelectionChanged(NavigationView sender, NavigationViewSelectionChangedEventArgs args)
        {
            NavigationViewItem item = args.SelectedItem as NavigationViewItem;
            EntranceNavigationTransitionInfo entranceTransition = new();

            Route selectedRoute = routes.FirstOrDefault(r => r.Id == item.Tag.ToString());

            if (selectedRoute != null)
            {
                ContentPresenter.Navigate(selectedRoute.Page, null, entranceTransition);
            }
        }

        private void PageLoaded(object sender, RoutedEventArgs e)
        {
            HandleUserRoleType();
            App app = Application.Current as App;
            window = app.ApplicationWindow as MainWindow;

            if (window != null)
            {
                window.NavigatedBack += WindowNavigatedBack;
            }
        }

        private void HandleUserRoleType()
        {
            if(GlobalUserRole.Role == 0)
            {
                ReportsHeader.Visibility = Visibility.Collapsed;
                HomeButton.Visibility = Visibility.Collapsed;
                UploadButton.Visibility = Visibility.Collapsed;
                FeePaymentButton.Visibility = Visibility.Collapsed;
                GenerateReportButton.Visibility = Visibility.Collapsed;
                //CautionDepositButton.Visibility = Visibility.Collapsed;
                ContentPresenter.Content = new Students();
                Navigation.SelectedItem = StudentsNavButton;
                Navigation.IsSettingsVisible = false;
            }
            else if(GlobalUserRole.Role == 2)
            {
                PaymentStatisticsButton.Visibility = Visibility.Collapsed;
                BankAccountsButton.Visibility = Visibility.Collapsed;
                PaymentsHeader.Visibility = Visibility.Collapsed;
                CoursesNavButton.Visibility = Visibility.Collapsed;
                StudentsNavButton.Visibility = Visibility.Collapsed;
                ReportsHeader.Visibility = Visibility.Collapsed;
                HomeButton.Visibility = Visibility.Collapsed;
                UploadButton.Visibility = Visibility.Collapsed;
                FeePaymentButton.Visibility = Visibility.Collapsed;
                GenerateReportButton.Visibility = Visibility.Collapsed;
                CautionDepositButton.Visibility = Visibility.Collapsed;
                ContentPresenter.Content = new FeesStructures();
                Navigation.SelectedItem = FeesStructuresNavButton;
                Navigation.IsSettingsVisible = false;
            }
            else
            {
                ContentPresenter.Content = new Home();
            }
        }

        private void WindowNavigatedBack(object sender, Core.Routing.NavigationEventArgs e)
        {
            NavigationService.GoBack(ContentPresenter);
        }

    }
}
