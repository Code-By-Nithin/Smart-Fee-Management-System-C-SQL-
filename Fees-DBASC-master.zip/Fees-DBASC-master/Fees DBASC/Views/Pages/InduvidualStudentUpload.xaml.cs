// Copyright (c) Microsoft Corporation and Contributors.
// Licensed under the MIT License.

using Fees_DBASC.Core.Database;
using Fees_DBASC.Core.Exceptions;
using Fees_DBASC.Data.Models;
using Fees_DBASC.Data.Sources;
using Microsoft.UI.Text;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Documents;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Windows.UI.Popups;
using static iText.Kernel.Pdf.Colorspace.PdfDeviceCs;

namespace Fees_DBASC.Views.Pages
{
    public sealed partial class InduvidualStudentUpload : Page
    {

        public InduvidualStudentUpload()
        {
            this.InitializeComponent();
        }

        private async void FetchCourseData()
        {
            List<Course> courses = new();
            Course course = null;
            await Task.Run(async () =>
            {
                try
                {
                    using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                    await connection.OpenAsync();

                    MySqlCommand command = connection.CreateCommand();
                    command.CommandText = "SELECT * FROM courses";

                    using MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync();
                    while (await reader.ReadAsync())
                    {
                        int idOrdinal = reader.GetOrdinal("id");
                        int nameOrdinal = reader.GetOrdinal("name");
                        int semestersOrdinal = reader.GetOrdinal("semesters");
                        int TimestampOrdinal = reader.GetOrdinal("Timestamp");

                        course = new()
                        {
                            Id = reader.IsDBNull(idOrdinal) ? -1 : reader.GetInt32(idOrdinal),
                            Name = reader.IsDBNull(nameOrdinal) ? null : reader.GetString(nameOrdinal),
                            Semesters = reader.IsDBNull(semestersOrdinal) ? 0 : reader.GetInt32(semestersOrdinal),
                            Timestamp = reader.IsDBNull(TimestampOrdinal) ? DateTime.Now : reader.GetDateTime(TimestampOrdinal),
                        };

                        courses.Add(course);
                    }
                    await reader.CloseAsync();
                }
                catch (Exception e)
                {
                    Debug.WriteLine(e.Message);
                    throw;
                }
            }).ContinueWith(t =>
            {
                if (t.Exception != null)
                {
                    MessageDialog.IsOpen = true;
                    MessageDialog.Message = t.Exception.Message;
                }
                else
                {
                    ProgressBar.Visibility = Visibility.Collapsed;
                    MessageDialog.IsOpen = false;
                    PreFillData(courses);
                }

            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        private void PreFillData(List<Course> courses)
        {
            State.ItemsSource = new StateDataSource().GetStates();
            State.SelectedItem = "Kerala";

            List<int> academicYear = new();
            for(int i= DateTime.Now.Year - 20; i<DateTime.Now.Year+5;i++)
            {
                academicYear.Add(i);
            }

            AcademicYear.ItemsSource = academicYear;
            AcademicYear.SelectedItem = DateTime.Now.Year;

            Course.ItemsSource = courses;
            Course.SelectedIndex = 0;
        }

        private async void ValidateStudentData()
        {
            List<string> errors = new();

            if (string.IsNullOrEmpty(AdmissionNumber.Text)) errors.Add("admission number");
            if (string.IsNullOrEmpty(StudentName.Text)) errors.Add("student name");
            if (string.IsNullOrEmpty(Course.SelectedValue.ToString())) errors.Add("course");
            if (string.IsNullOrEmpty(AcademicYear.SelectedValue.ToString())) errors.Add("academic year");

            if (errors.Any())
            {
                string errorMessage = $"Please enter the {string.Join(", ", errors)}";
                if (errors.Count > 1)
                {
                    int lastIndex = errorMessage.LastIndexOf(", ");
                    errorMessage = errorMessage.Substring(0, lastIndex) + $" and{errorMessage.Substring(lastIndex + 1)}";
                }
                errorMessage += ".";
                MessageDialog.Severity = InfoBarSeverity.Error;
                MessageDialog.Message = errorMessage;
                MessageDialog.IsOpen = true;
            }
            else
            {
                MessageDialog.IsOpen = false;
                int admissionNumber = Int32.Parse(AdmissionNumber.Text);

                await Task.Run(async () =>
                {
                    try
                    {
                        using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                        await connection.OpenAsync();

                        MySqlCommand command = connection.CreateCommand();
                        command.CommandText = "SELECT * FROM students where id=@id";
                        command.Parameters.AddWithValue("id", admissionNumber);

                        int count = Convert.ToInt32(command.ExecuteScalar());
                        if (count > 0)
                        {
                            throw new StudentAlreadyExistException("Sorry a student with same admission number already exists");
                        }
                    }
                    catch (Exception e)
                    {
                        Debug.WriteLine(e.Message);
                        throw;
                    }
                }).ContinueWith(t =>
                {
                    if (t.Exception != null)
                    {
                        MessageDialog.Severity = InfoBarSeverity.Error;

                        if (t.Exception.InnerException is StudentAlreadyExistException)
                        {
                            MessageDialog.IsOpen = true;
                            MessageDialog.Message = t.Exception.InnerException.Message;
                        }
                        else
                        {
                            MessageDialog.IsOpen = true;
                            MessageDialog.Message = t.Exception.Message;
                        }
                    }
                    else
                    {
                        SaveStudentData();
                    }

                }, TaskScheduler.FromCurrentSynchronizationContext()); 
            }
        }

        private async void SaveStudentData()
        {
            string address1 = string.Empty;
            string address2 = string.Empty;
            Address1.Document.GetText(TextGetOptions.None, out address1);
            Address2.Document.GetText(TextGetOptions.None, out address2);

            var selectedCourse = Course.SelectedItem as Course;
            int courseId = selectedCourse.Id;

            int admissionNumber = Int32.Parse(AdmissionNumber.Text);
            string studentName = StudentName.Text;
            string academicYear = AcademicYear.SelectedValue.ToString();
            string fathersName = FathersName.Text;
            string mothersName = MothersName.Text;
            string city = City.Text;
            string state = State.SelectedItem.ToString();
            string zipcode = ZipCode.Text;
            string phone = Phone.Text;
            string mobile = Mobile.Text;
            string email = Email.Text;

            await Task.Run(async () =>
            {
                try
                {
                    using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                    await connection.OpenAsync();

                    MySqlCommand command = connection.CreateCommand();
                    command.CommandText = "INSERT INTO students(id,school_code,student_name,academic_year,fathers_name,mothers_name,address_line1,address_line2,city,state,zip_code,phone,mobile,email,course_id,standard,division) VALUES(@id,@school_code,@name,@academic_year,@fathers_name,@mothers_name,@address_line1,@address_line2,@city,@state,@zip_code,@phone,@mobile,@email,@course_id,@standard,@division) ON DUPLICATE KEY UPDATE school_code=VALUES(school_code),student_name=VALUES(student_name),academic_year=VALUES(academic_year),fathers_name=VALUES(fathers_name),mothers_name=VALUES(mothers_name),address_line1=VALUES(address_line1),address_line2=VALUES(address_line2),city=VALUES(city),state=VALUES(state),zip_code=VALUES(zip_code),phone=VALUES(phone),mobile=VALUES(mobile),email=VALUES(email),course_id=VALUES(course_id),standard=VALUES(standard),division=VALUES(division);";
                    command.Parameters.Clear();
                    command.Parameters.AddWithValue("@id", admissionNumber);
                    command.Parameters.AddWithValue("@school_code", "DBASC");
                    command.Parameters.AddWithValue("@name", studentName);
                    command.Parameters.AddWithValue("@academic_year", academicYear);
                    command.Parameters.AddWithValue("@fathers_name", fathersName);
                    command.Parameters.AddWithValue("@mothers_name", mothersName);
                    command.Parameters.AddWithValue("@address_line1", address1);
                    command.Parameters.AddWithValue("@address_line2", address2);
                    command.Parameters.AddWithValue("@city", city);
                    command.Parameters.AddWithValue("@state", state);
                    command.Parameters.AddWithValue("@zip_code", zipcode);
                    command.Parameters.AddWithValue("@phone", phone);
                    command.Parameters.AddWithValue("@mobile", mobile);
                    command.Parameters.AddWithValue("@email", email);
                    command.Parameters.AddWithValue("@course_id", courseId);
                    command.Parameters.AddWithValue("@standard", null);
                    command.Parameters.AddWithValue("@division",null);
                    await command.ExecuteNonQueryAsync();
                }
                catch (Exception e)
                {
                    Debug.WriteLine(e.Message);
                    throw;
                }
            }).ContinueWith(t =>
            {
                if (t.Exception != null)
                {
                    MessageDialog.Severity = InfoBarSeverity.Error;
                    MessageDialog.IsOpen = true;
                    MessageDialog.Message = t.Exception.Message;
                }
                else
                {
                    ProgressBar.Visibility = Visibility.Collapsed;
                    MessageDialog.Severity = InfoBarSeverity.Success;
                    MessageDialog.IsOpen = true;
                    MessageDialog.Message = "Student Data Added Successfully";
                }

            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        private void HandleResetForm(object sender, RoutedEventArgs e)
        {
            AdmissionNumber.Text = string.Empty;
            StudentName.Text = string.Empty;
            FathersName.Text = string.Empty;
            MothersName.Text = string.Empty;
            Course.SelectedIndex = 0;
            AcademicYear.SelectedValue = DateTime.Now.Year;
            Address1.Document.SetText(TextSetOptions.None, string.Empty);
            Address2.Document.SetText(TextSetOptions.None, string.Empty);
            City.Text = string.Empty;
            State.SelectedIndex = 0;
            ZipCode.Text = string.Empty;
            Phone.Text = string.Empty;
            Mobile.Text = string.Empty;
            Email.Text = string.Empty;
        }

        private void HandleSaveData(object sender, RoutedEventArgs e)
        {
            ValidateStudentData();
        }

        private void AdmissionNumberTextChanging(TextBox sender, TextBoxBeforeTextChangingEventArgs args)
        {
            if (args.NewText.Length > 0)
            {
                if (!int.TryParse(args.NewText, out _))
                {
                    args.Cancel = true;
                }
            }
        }

        private void PageLoaded(object sender, RoutedEventArgs e)
        {
            FetchCourseData();
        }
    }
}
