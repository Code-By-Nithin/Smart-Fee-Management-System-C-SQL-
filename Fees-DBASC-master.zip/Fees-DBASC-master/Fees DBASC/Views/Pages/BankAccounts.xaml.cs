using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Controls.Primitives;
using Microsoft.UI.Xaml.Data;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Navigation;
using Fees_DBASC.Data.Sources;
using CommunityToolkit.WinUI;
using Fees_DBASC.Data.Models;
using System.Threading.Tasks;
using Fees_DBASC.Core.Database;
using MySql.Data.MySqlClient;
using System.Diagnostics;
using Fees_DBASC.Core.Authentication;
using Fees_DBASC.Core.Routing;
using static iText.StyledXmlParser.Jsoup.Select.Evaluator;

namespace Fees_DBASC.Views.Pages
{
    public sealed partial class BankAccounts : Page
    {
        private IncrementalLoadingCollection<BankDataSource, Bank> collection;
        private BankDataSource bankDataSource;

        public BankAccounts()
        {
            this.InitializeComponent();
        }

        private async void PageLoaded(object sender, RoutedEventArgs e)
        {
            HandleUserRoleType();

            await Task.Run(() =>
            {
                bankDataSource = new BankDataSource();
                collection = new IncrementalLoadingCollection<BankDataSource, Bank>(bankDataSource, 20, null, null, null);
                collection.OnStartLoading += CollectionLoading;
                collection.OnEndLoading += CollectionLoaded;
                collection.OnError += OnError;
            });

            BankList.ItemsSource = collection;
            await BankList.LoadMoreItemsAsync();
        }

        private void CollectionLoaded()
        {
            Task.Delay(800).ContinueWith(t =>
            {
                ProgressBar.Visibility = Visibility.Collapsed;
                ProgressBar.IsIndeterminate = false;
            }, TaskScheduler.FromCurrentSynchronizationContext());

            if (SelectAllCheckbox.IsChecked == true)
            {
                BankList.SelectAll();
            }

            if (collection.Count <= 0 && ListErrorMessage.Visibility == Visibility.Collapsed)
            {
                EmptyListMessage.Visibility = Visibility.Visible;
            }
            else
            {
                EmptyListMessage.Visibility = Visibility.Collapsed;
            }
        }

        private void OnError(Exception e)
        {
            if (collection.Count > 0)
            {
                ListErrorMessage.Visibility = Visibility.Collapsed;
                ErrorInfoBar.Message = e.Message;
                ErrorInfoBar.IsOpen = true;
            }
            else
            {
                ListErrorMessage.Visibility = Visibility.Visible;
                ErrorMessage.Text = e.Message;
            }
        }

        private void CollectionLoading()
        {
            ProgressBar.IsIndeterminate = true;
            ProgressBar.Visibility = Visibility.Visible;
        }

        private void SelectAll(object sender, RoutedEventArgs e)
        {
            BankList.SelectAll();
        }

        private void UnSelectAll(object sender, RoutedEventArgs e)
        {
            BankList.SelectedItems.Clear();
        }

        private async void DeleteBanks(bool deleteAll)
        {
            var banksToRemove = BankList.SelectedItems.Cast<Bank>().Join(collection, c => c.Id, ci => ci.Id, (c, ci) => ci).ToList();
            string idList = string.Join(",", banksToRemove.Select(x => x.Id));

            await Task.Run(async () =>
            {
                using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                await connection.OpenAsync();

                MySqlCommand command = connection.CreateCommand();
                MySqlTransaction transaction = connection.BeginTransaction();
                command.Connection = connection;
                command.Transaction = transaction;

                try
                {
                    if (deleteAll)
                    {
                        command.CommandText = "TRUNCATE TABLE banks;";
                        await command.ExecuteNonQueryAsync();
                    }
                    else
                    {
                        command.CommandText = $"DELETE FROM banks WHERE id in({idList});";
                        await command.ExecuteNonQueryAsync();
                    }

                    await transaction.CommitAsync();
                }
                catch (Exception)
                {
                    transaction.Rollback();
                    throw;
                }
            }).ContinueWith(t =>
            {
                if (t.Exception != null)
                {
                    InfoBar.IsOpen = false;
                    ErrorInfoBar.IsOpen = true;
                    ErrorInfoBar.Message = t.Exception.Message;
                }
                else
                {
                    int selectedItemsCount = BankList.SelectedItems.Count;
                    banksToRemove.ForEach(c => collection.Remove(c));
                    BankList.UpdateLayout();

                    ErrorInfoBar.IsOpen = false;
                    InfoBar.IsOpen = true;
                    InfoBar.Title = "Delete Bank Details";

                    if (deleteAll)
                    {
                        InfoBar.Message = $"All bank details has been removed.";
                    }
                    else
                    {
                        if (selectedItemsCount > 1)
                        {
                            InfoBar.Message = $"{selectedItemsCount} Bank datas has been removed.";
                        }
                        else
                        {
                            InfoBar.Message = $"{selectedItemsCount} Bank data has been removed.";
                        }
                    }

                    if (collection.Count <= 0)
                    {
                        EmptyListMessage.Visibility = Visibility.Visible;
                    }
                    else
                    {
                        EmptyListMessage.Visibility = Visibility.Collapsed;
                    }
                }
            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        private async void HandleDeleteBank(object sender, RoutedEventArgs e)
        {
            var result = await DeleteConfirmDialog.ShowAsync();
            if (result == ContentDialogResult.Primary)
            {
                if (SelectAllCheckbox.IsChecked == true)
                {
                    DeleteBanks(true);
                }
                else
                {
                    DeleteBanks(false);
                }
            }
        }

        private void BankListSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (BankList.SelectedItems.Count <= 0)
            {
                SelectAllCheckbox.IsChecked = false;
            }
            else if (collection.Count == BankList.SelectedItems.Count)
            {
                SelectAllCheckbox.IsChecked = true;
            }
            else if (collection.Count > BankList.SelectedItems.Count)
            {
                SelectAllCheckbox.IsChecked = null;
            }
        }

        private void BankListRightTapped(object sender, RightTappedRoutedEventArgs e)
        {
            if (GlobalUserRole.Role != 0)
            {
                ListView listView = (ListView)sender;
                Delete.IsEnabled = listView.SelectedItems.Count > 0;
                Edit.IsEnabled = listView.SelectedItems.Count == 1;
                ContextMenu.ShowAt(listView, e.GetPosition(listView));
            }
        }

        private async void HandleAddBankAccount(object sender, RoutedEventArgs e)
        {
            BankName.Text = "";
            AccountNo.Text = "";
            IFSCCode.Text = "";
            AddBankAccountDialog.Tag = "Add";
            await AddBankAccountDialog.ShowAsync();
        }

        private void HandleAddBankAccount(ContentDialog sender, ContentDialogButtonClickEventArgs args)
        {
            List<string> errors = new();

            if (string.IsNullOrEmpty(BankName.Text)) errors.Add("bank name");
            if (string.IsNullOrEmpty(AccountNo.Text)) errors.Add("account number");
            if (string.IsNullOrEmpty(IFSCCode.Text)) errors.Add("IFSC code");

            if (errors.Any())
            {
                string errorMessage = $"Please enter the {string.Join(", ", errors)}";
                if (errors.Count > 1)
                {
                    int lastIndex = errorMessage.LastIndexOf(", ");
                    errorMessage = errorMessage.Substring(0, lastIndex) + $" and{errorMessage.Substring(lastIndex + 1)}";
                }
                errorMessage += ".";
                AddBankErrorWrap.Message = errorMessage;
                AddBankErrorWrap.IsOpen = true;
                args.Cancel = true;
            }
            else
            {
                AddBankErrorWrap.IsOpen = false;
                args.Cancel = false;

                if (AddBankAccountDialog.Tag.ToString() == "Add")
                {
                    AddOrEditBankDetails(false);
                }
                else if(AddBankAccountDialog.Tag.ToString() == "Edit")
                {
                    AddOrEditBankDetails(true);
                }
            }
        }

        private async void AddOrEditBankDetails(bool edit)
        {
            Bank bank = (edit) ? BankList.SelectedItem as Bank : null;
            int id = (bank != null) ? bank.Id : 0;

            string bankName = BankName.Text.ToString();
            string accountNumber = AccountNo.Text.ToString();
            string IFSC_Code = IFSCCode.Text.ToString();

            await Task.Run(async () =>
            {
                using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                await connection.OpenAsync();

                MySqlCommand command = connection.CreateCommand();

                if (edit)
                {
                    command.CommandText = $"UPDATE banks SET name=@name,account_number=@account_number,ifsc_code=@ifsc_code WHERE id=@id;";
                    command.Parameters.AddWithValue("@id", id);
                    command.Parameters.AddWithValue("@name", bankName);
                    command.Parameters.AddWithValue("@account_number", accountNumber);
                    command.Parameters.AddWithValue("@ifsc_code", IFSC_Code);
                }
                else
                {
                    command.CommandText = $"INSERT INTO banks (name,account_number,ifsc_code) VALUES(@name,@account_number,@ifsc_code);";
                    command.Parameters.AddWithValue("@name", bankName);
                    command.Parameters.AddWithValue("@account_number", accountNumber);
                    command.Parameters.AddWithValue("@ifsc_code", IFSC_Code);
                }

                await command.ExecuteNonQueryAsync();
            }).ContinueWith(async t =>
            {
                if (t.Exception != null)
                {
                    InfoBar.IsOpen = false;
                    ErrorInfoBar.IsOpen = true;
                    ErrorInfoBar.Message = t.Exception.Message;
                }
                else
                {
                    if (edit)
                    {
                        InfoBar.Message = $"Bank Details Updated Successfully";
                    }
                    else
                    {
                        InfoBar.Message = $"Bank Details Added Successfully";
                    }

                    bankDataSource.EmptyCollection();
                    await collection.RefreshAsync();
                    InfoBar.IsOpen = true;
                }

                foreach (var c in collection)
                {
                    Debug.WriteLine(c.Name);
                }
            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        private void AccountNumberChanging(TextBox sender, TextBoxBeforeTextChangingEventArgs args)
        {
            if (args.NewText.Length > 0)
            {
                if (!double.TryParse(args.NewText, out _))
                {
                    args.Cancel = true;
                }
            }
        }

        private async void HandleEditDetails(object sender, RoutedEventArgs e)
        {
            if (BankList.SelectedItem is Bank selectedItem)
            {
                BankName.Text = selectedItem.Name;
                AccountNo.Text = selectedItem.AccountNumber;
                IFSCCode.Text = selectedItem.IFSCCode;
                AddBankAccountDialog.Tag = "Edit";
                await AddBankAccountDialog.ShowAsync();
            }
        }

        private void HandleUserRoleType()
        {
            if (GlobalUserRole.Role == 0)
            {
                AddBankButton.Visibility = Visibility.Collapsed;
                Edit.Visibility = Visibility.Collapsed;
                Delete.Visibility = Visibility.Collapsed;
            }
        }
    }
}
