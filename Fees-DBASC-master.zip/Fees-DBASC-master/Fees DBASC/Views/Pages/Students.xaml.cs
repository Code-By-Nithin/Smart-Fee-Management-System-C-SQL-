using CommunityToolkit.WinUI;
using Fees_DBASC.Core.Authentication;
using Fees_DBASC.Core.Database;
using Fees_DBASC.Core.Routing;
using Fees_DBASC.Data.Models;
using Fees_DBASC.Data.Sources;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Input;
using Microsoft.VisualBasic;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Fees_DBASC.Views.Pages
{
    public sealed partial class Students : Page
    {
        private IncrementalLoadingCollection<StudentDataSource, Student> collection;
        private StudentDataSource studentDataSource;
        private ObservableCollection<Student> pagedItems;
        private bool isSearching = false;

        public Students()
        {
            this.InitializeComponent();
        }

        private async void PageLoaded(object sender, RoutedEventArgs e)
        {
            HandleUserRoleType();
            await Task.Run(() =>
            {
                studentDataSource = new StudentDataSource();
                collection = new IncrementalLoadingCollection<StudentDataSource, Student>(studentDataSource, 20, null, null, null);
                collection.OnStartLoading += CollectionLoading;
                collection.OnEndLoading += CollectionLoaded;
                collection.OnError += OnError;
            });

            StudentList.ItemsSource = collection;
            await StudentList.LoadMoreItemsAsync();
        }

        private void HandleUserRoleType()
        {
            if (GlobalUserRole.Role == 0)
            {
                AddStudentButton.Visibility = Visibility.Collapsed;
                Edit.Visibility = Visibility.Collapsed;
                Delete.Visibility = Visibility.Collapsed;
                View.Visibility = Visibility.Visible;
            }
        }

        private void CollectionLoaded()
        {
            Task.Delay(800).ContinueWith(t =>
            {
                ProgressBar.Visibility = Visibility.Collapsed;
                ProgressBar.IsIndeterminate = false;
            }, TaskScheduler.FromCurrentSynchronizationContext());

            if (SelectAllCheckbox.IsChecked == true)
            {
                StudentList.SelectAll();
            }

            if (collection.Count <= 0 && ListErrorMessage.Visibility == Visibility.Collapsed)
            {
                EmptyListMessage.Visibility = Visibility.Visible;
            }
            else
            {
                EmptyListMessage.Visibility = Visibility.Collapsed;
            }
        }

        private void OnError(Exception e)
        {
            if (collection.Count > 0)
            {
                ListErrorMessage.Visibility = Visibility.Collapsed;
                ErrorInfoBar.Message = e.Message;
                ErrorInfoBar.IsOpen = true;
            }
            else
            {
                ListErrorMessage.Visibility = Visibility.Visible;
                ErrorMessage.Text = e.Message;
            }
        }

        private void CollectionLoading()
        {
            ProgressBar.IsIndeterminate = true;
            ProgressBar.Visibility = Visibility.Visible;
        }

        private void SelectAll(object sender, RoutedEventArgs e)
        {
            StudentList.SelectAll();
        }

        private void UnSelectAll(object sender, RoutedEventArgs e)
        {
            StudentList.SelectedItems.Clear();
        }

        private async void DeleteStudents(bool deleteAll)
        {
            var renderedStudentsToRemove = StudentList.SelectedItems.Cast<Student>().Join(collection, c => c.Id, ci => ci.Id, (c, ci) => ci).ToList();
            var searchedStudentsToRemove = StudentList.SelectedItems.Cast<Student>().ToList();

            var studentsToRemove = StudentList.SelectedItems.Cast<Student>().ToList();
            string idList = string.Join(",", studentsToRemove.Select(x => x.Id));

            var x = StudentList.SelectedItems.Cast<Student>().ToList();
    
            await Task.Run(async () =>
            {
                using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                await connection.OpenAsync();

                MySqlCommand command = connection.CreateCommand();
                MySqlTransaction transaction = connection.BeginTransaction();
                command.Connection = connection;
                command.Transaction = transaction;

                try
                {
                    if (deleteAll)
                    {
                        command.CommandText = "TRUNCATE TABLE students;";
                        await command.ExecuteNonQueryAsync();
                    }
                    else
                    {
                        command.CommandText = $"DELETE FROM students WHERE id in({idList});";
                        await command.ExecuteNonQueryAsync();
                    }
                    await transaction.CommitAsync();
                }
                catch (Exception)
                {
                    transaction.Rollback();
                    throw;
                }
            }).ContinueWith(t =>
            {
                if (t.Exception != null)
                {
                    InfoBar.IsOpen = false;
                    ErrorInfoBar.IsOpen = true;
                    ErrorInfoBar.Message = t.Exception.Message;
                }
                else
                {
                    int selectedItemsCount = StudentList.SelectedItems.Count;
                    renderedStudentsToRemove.ForEach(c => collection.Remove(c));
                    
                    if(pagedItems!=null && isSearching)
                    {
                        foreach (var student in searchedStudentsToRemove)
                        {
                            pagedItems.Remove(student);
                            StudentList.ItemsSource = pagedItems;
                        }
                    }

                    StudentList.UpdateLayout();

                    ErrorInfoBar.IsOpen = false;
                    InfoBar.IsOpen = true;
                    InfoBar.Title = "Delete Student";

                    if(deleteAll)
                    {
                        InfoBar.Message = $"All Students data has been removed.";
                    }
                    else
                    {
                        if (selectedItemsCount > 1)
                        {
                            InfoBar.Message = $"{selectedItemsCount} Students data has been removed.";
                        }
                        else
                        {
                            InfoBar.Message = $"{selectedItemsCount} Student data has been removed.";
                        }
                    }

                    if (collection.Count <= 0)
                    {
                        EmptyListMessage.Visibility = Visibility.Visible;
                    }
                    else
                    {
                        EmptyListMessage.Visibility = Visibility.Collapsed;
                    }
                }
            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        private async void DeleteStudent(object sender, RoutedEventArgs e)
        {
            var result = await DeleteConfirmDialog.ShowAsync();
            if (result == ContentDialogResult.Primary)
            {
                if (SelectAllCheckbox.IsChecked == true)
                {
                    DeleteStudents(true);
                }
                else
                {
                    DeleteStudents(false);
                }
            }
        }

        private void StudentListSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (StudentList.SelectedItems.Count <= 0)
            {
                SelectAllCheckbox.IsChecked = false;
            }
            else if (collection.Count == StudentList.SelectedItems.Count)
            {
                SelectAllCheckbox.IsChecked = true;
            }
            else if (collection.Count > StudentList.SelectedItems.Count)
            {
                SelectAllCheckbox.IsChecked = null;
            }
        }

        private void StudentListRightTapped(object sender, RightTappedRoutedEventArgs e)
        {
            if(GlobalUserRole.Role != 0)
            {
                ListView listView = (ListView)sender;
                Delete.IsEnabled = listView.SelectedItems.Count > 0;
                Edit.IsEnabled = listView.SelectedItems.Count == 1;
                ContextMenu.ShowAt(listView, e.GetPosition(listView));
            }
            else if(GlobalUserRole.Role ==0)
            {
                ListView listView = (ListView)sender;
                View.Visibility = Visibility.Visible;
                ContextMenu.ShowAt(listView, e.GetPosition(listView));
            }
        }

        private void HandleAddStudent(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(this, new UploadStudentDetails());
        }

        private async void AutoSuggestBoxTextChanged(AutoSuggestBox sender, AutoSuggestBoxTextChangedEventArgs args)
        {
            string searchQuery = searchBox.Text; 
            CancellationToken cancellationToken = default;

            if(searchQuery.Length > 0)
            {
                int id = -1;
                if(int.TryParse(searchQuery,out id))
                {
                    studentDataSource.EmptyCollection();
                    studentDataSource.Search(searchQuery, 0);
                    pagedItems = new(await studentDataSource.GetPagedItemsAsync(0, 40, cancellationToken));
                    StudentList.ItemsSource = pagedItems.ToList();
                    isSearching = true;
                }
                else
                {
                    studentDataSource.EmptyCollection();
                    studentDataSource.Search(searchQuery,1);
                    pagedItems = new(await studentDataSource.GetPagedItemsAsync(0, 40, cancellationToken));
                    StudentList.ItemsSource = pagedItems.ToList();
                    isSearching = true;
                }
            }
            else
            {

                studentDataSource.Search(null,-1);
                await Task.Run(() =>
                {
                    studentDataSource = new StudentDataSource();
                    collection = new IncrementalLoadingCollection<StudentDataSource, Student>(studentDataSource, 20, null, null, null);
                    collection.OnStartLoading += CollectionLoading;
                    collection.OnEndLoading += CollectionLoaded;
                    collection.OnError += OnError;
                });
                isSearching = false;
                StudentList.ItemsSource = collection;
                await StudentList.LoadMoreItemsAsync();
            }
            
        }

        private void EditStudent(object sender, RoutedEventArgs e)
        {
            Student student = StudentList.SelectedItem as Student;
            if(student != null) 
            {
                NavigationService.Navigate(this,new EditStudent(),student);
            }
        }

        private void ViewStudent(object sender, RoutedEventArgs e)
        {
            Student student = StudentList.SelectedItem as Student;
            if (student != null)
            {
                NavigationService.Navigate(this, new EditStudent(), student);
            }
        }
    }
}
