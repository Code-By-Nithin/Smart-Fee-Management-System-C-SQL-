using Fees_DBASC.Core.Authentication;
using Fees_DBASC.Core.Database;
using Fees_DBASC.Core.Exceptions;
using Fees_DBASC.Core.Routing;
using Fees_DBASC.Data.Models;
using Fees_DBASC.Data.Parsers;
using Microsoft.UI.Text;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Navigation;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using Windows.UI;
using static iText.StyledXmlParser.Jsoup.Select.Evaluator;

namespace Fees_DBASC.Views.Pages
{
    public sealed partial class ViewFeesStructure : Page
    {
        private FeesData feesData = null;
        private int feesStructureActiveStatus = 0;

        public ViewFeesStructure()
        {
            this.InitializeComponent();
        }

        protected override void OnNavigatedTo(Microsoft.UI.Xaml.Navigation.NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);
            if (e.Parameter != null && e.Parameter is FeesData data)
            {
                feesData = data;

                if(feesData.Active)
                {
                    ApproveButton.Content = "Deactivate Fees Structure";
                    feesStructureActiveStatus = 1;
                }
            }
        }

        private static string GetRomanNumber(int num)
        {
            string number;
            switch (num)
            {
                case 1:
                    number = "I";
                    break;
                case 2:
                    number = "II";
                    break;
                case 3:
                    number = "III";
                    break;
                case 4:
                    number = "IV";
                    break;
                case 5:
                    number = "V";
                    break;
                case 6:
                    number = "VI";
                    break;
                case 7:
                    number = "VII";
                    break;
                case 8:
                    number = "VIII";
                    break;
                case 9:
                    number = "IX";
                    break;
                case 10:
                    number = "X";
                    break;
                default:
                    return num.ToString();
            }

            return number;
        }

        private void PageLoaded(object sender, RoutedEventArgs e)
        {
            if(GlobalUserRole.Role==2)
            {
                ApproverSection.Visibility = Visibility.Visible;
            }

            var totalColumnCount = 0;

            if (feesData != null)
            {
                FeesStructureName.Text = "FEE STRUCTURE OF " + feesData.CourseName + " (" + feesData.AcademicYear + " Batch)";
                Dictionary<string, object> feesStructure = JsonSerializer.Deserialize<Dictionary<string, object>>(new JsonParser().Sort(feesData.Json));

                // Generate Column Header

                //Generate columns for sl.no and particulars
                FeesStructureContent.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(60) });
                FeesStructureContent.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(250) });

                for (var i = 0; i < feesData.Semesters; i++)
                {
                    FeesStructureHeader.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(100) });
                    FeesStructureContent.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(100) });

                    var semesterName = new TextBlock()
                    {
                        Text = GetRomanNumber(i + 1) + " Sem",
                        Padding = new Thickness(10),
                        TextAlignment = TextAlignment.Center
                    };

                    // Ignore Sl.No and Particulars Column
                    totalColumnCount++;
                    Grid.SetColumn(semesterName, i + 2);
                    FeesStructureHeader.Children.Add(semesterName);
                }

                // Colum Header Generation Completed Here

                // Start Rendering Rows

                int rowCount = 0;
                string categoryRow = null;
                foreach (var row in feesStructure)
                {
                    Dictionary<string, object> rowData = JsonSerializer.Deserialize<Dictionary<string, object>>(row.Value.ToString());

                    // Add New Grid Row Definition for each row
                    FeesStructureContent.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(50) });

                    // Iterate Each Cell
                    foreach (var cell in rowData)
                    {
                        if (cell.Key == "label")
                        {
                            var cellContent = new TextBlock()
                            {
                                Text = cell.Value.ToString(),
                                Padding = new Thickness(10),
                                TextAlignment = TextAlignment.Start,
                                FontWeight = FontWeights.SemiBold,
                                VerticalAlignment  = VerticalAlignment.Center
                            };

                            Grid.SetColumn(cellContent, 1);
                            Grid.SetRow(cellContent, rowCount);
                            FeesStructureContent.Children.Add(cellContent);

                        }
                        else if (cell.Key == "serialNumber")
                        {
                            var cellContent = new TextBlock()
                            {
                                Text = cell.Value.ToString(),
                                Padding = new Thickness(10),
                                TextAlignment = TextAlignment.Center,
                                FontWeight = FontWeights.SemiBold,
                                VerticalAlignment = VerticalAlignment.Center
                            };

                            Grid.SetColumn(cellContent, 0);
                            if (categoryRow != null)
                            {
                                Grid.SetRow(cellContent, int.Parse(categoryRow));
                                categoryRow = null;
                            }
                            else
                            {
                                Grid.SetRow(cellContent, rowCount);
                            }
                            FeesStructureContent.Children.Add(cellContent);
                        }
                        else if (cell.Key == "fees")
                        {
                            Dictionary<string, object> semesters = JsonSerializer.Deserialize<Dictionary<string, object>>(cell.Value.ToString());
                            var j = 2;
                            foreach (var semester in semesters)
                            {
                                var amount = semester.Value.ToString();

                                var cellContent = new TextBlock()
                                {
                                    Text = amount,
                                    Padding = new Thickness(10),
                                    TextAlignment = TextAlignment.Center,
                                    VerticalAlignment = VerticalAlignment.Center
                                };

                                Grid.SetColumn(cellContent, j);
                                Grid.SetRow(cellContent, rowCount);
                                FeesStructureContent.Children.Add(cellContent);
                                j++;
                            }
                        }
                        else if (cell.Key == "categories")
                        {
                            categoryRow = rowCount.ToString();
                            List<Dictionary<string, object>> feesList = JsonSerializer.Deserialize<List<Dictionary<string, object>>>(cell.Value.ToString());

                            foreach (var item in feesList)
                            {
                                FeesStructureContent.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(50) });
                                rowCount++;

                                foreach (var cellItem in item)
                                {
                                    if (cellItem.Key == "label")
                                    {
                                        var cellContent = new TextBlock()
                                        {
                                            Text = cellItem.Value.ToString(),
                                            Padding = new Thickness(10),
                                            TextAlignment = TextAlignment.Start,
                                            VerticalAlignment = VerticalAlignment.Center
                                        };

                                        Grid.SetColumn(cellContent, 1);
                                        Grid.SetRow(cellContent, rowCount);
                                        FeesStructureContent.Children.Add(cellContent);
                                    }
                                    else if (cellItem.Key == "serialNumber")
                                    {
                                        var cellContent = new TextBlock()
                                        {
                                            Text = cellItem.Value.ToString(),
                                            Padding = new Thickness(10),
                                            TextAlignment = TextAlignment.End,
                                            VerticalAlignment = VerticalAlignment.Center
                                        };

                                        Grid.SetColumn(cellContent, 0);
                                        Grid.SetRow(cellContent, rowCount);
                                        FeesStructureContent.Children.Add(cellContent);
                                    }
                                    else if (cellItem.Key == "fees")
                                    {
                                        Dictionary<string, object> semesters = JsonSerializer.Deserialize<Dictionary<string, object>>(cellItem.Value.ToString());
                                        var j = 2;
                                        foreach (var semester in semesters)
                                        {
                                            var amount = semester.Value.ToString();

                                            var cellContent = new TextBlock()
                                            {
                                                Text = amount,
                                                Padding = new Thickness(10),
                                                TextAlignment = TextAlignment.Center,
                                                VerticalAlignment = VerticalAlignment.Center
                                            };

                                            Grid.SetColumn(cellContent, j);
                                            Grid.SetRow(cellContent, rowCount);
                                            FeesStructureContent.Children.Add(cellContent);
                                            j++;
                                        }
                                    }

                                }
                            }
                        }
                    }
                    rowCount++;
                }
            }

        }

        private async void UpdateFeesStructureStatus(int active)
        {
            ProgressBar.Visibility = Visibility.Visible;

            if (active==0)
            {
                await Task.Run(async () =>
                {
                    using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                    await connection.OpenAsync();

                    MySqlCommand command = connection.CreateCommand();
                    command.CommandText = $"UPDATE fees_structure SET active=@status WHERE id=@id;";
                    command.Parameters.AddWithValue("@id", feesData.Id);
                    command.Parameters.AddWithValue("@status", active);

                    await command.ExecuteNonQueryAsync();
                }).ContinueWith(t =>
                {
                    ProgressBar.Visibility = Visibility.Collapsed;
                    if (t.Exception != null)
                    {
                        MessageBox.Severity = InfoBarSeverity.Error;
                        MessageBox.IsOpen = true;
                        MessageBox.Message = t.Exception.Message;
                    }
                    else
                    {
                        MessageBox.Severity = InfoBarSeverity.Success;
                        MessageBox.IsOpen = true;
                        MessageBox.Message = "Fees Structure Updated Successfully";
                        feesStructureActiveStatus = 0;
                        ApproveButton.Content = "Approve Fees Structure";
                    }

                }, TaskScheduler.FromCurrentSynchronizationContext());
            }
            else
            {
                await Task.Run(async () =>
                {
                    using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                    await connection.OpenAsync();

                    MySqlCommand command = connection.CreateCommand();
                    command.CommandText = $"select * from fees_structure WHERE academic_year=@academic_year AND course_id=@course_id AND active=@status";
                    command.Parameters.AddWithValue("@id", feesData.Id);
                    command.Parameters.AddWithValue("@course_id", feesData.CourseId);
                    command.Parameters.AddWithValue("@academic_year", feesData.AcademicYear);
                    command.Parameters.AddWithValue("@status", 1);

                    int count = Convert.ToInt32(await command.ExecuteScalarAsync());
                    if (count > 0)
                    {
                        throw new FeesStructureAlreadyActiveException("A Fees Structure associated with same course and academic year is active, please deactivate it to continue");
                    }
                }).ContinueWith(async t =>
                {
                    if (t.Exception != null)
                    {
                        ProgressBar.Visibility = Visibility.Collapsed;
                        MessageBox.Severity = InfoBarSeverity.Error;
                        MessageBox.IsOpen = true;
                        MessageBox.Message = t.Exception.Message;
                    }
                    else
                    {
                        await Task.Run(async () =>
                        {
                            using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                            await connection.OpenAsync();

                            MySqlCommand command = connection.CreateCommand();
                            command.CommandText = $"UPDATE fees_structure SET active=@status WHERE id=@id;";
                            command.Parameters.AddWithValue("@id", feesData.Id);
                            command.Parameters.AddWithValue("@status", active);

                            await command.ExecuteNonQueryAsync();
                        }).ContinueWith(t =>
                        {
                            ProgressBar.Visibility = Visibility.Collapsed;
                            if (t.Exception != null)
                            {
                                MessageBox.Severity = InfoBarSeverity.Error;
                                MessageBox.IsOpen = true;
                                MessageBox.Message = t.Exception.Message;
                            }
                            else
                            {
                                MessageBox.Severity = InfoBarSeverity.Success;
                                MessageBox.IsOpen = true;
                                MessageBox.Message = "Fees Structure Updated Successfully";
                                feesStructureActiveStatus = 1;
                                ApproveButton.Content = "Deactivate Fees Structure";
                            }

                        }, TaskScheduler.FromCurrentSynchronizationContext());
                    }

                }, TaskScheduler.FromCurrentSynchronizationContext());
            }
        }

        private void ApproveFeesStructure(object sender, RoutedEventArgs e)
        {
            int activeStatus = (feesStructureActiveStatus==1)?0:1;
            UpdateFeesStructureStatus(activeStatus);
        }

        private void HandleGoBack(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(this, new FeesStructures());
        }
    }
}
