// Copyright (c) Microsoft Corporation and Contributors.
// Licensed under the MIT License.

using Fees_DBASC.Core.Authentication;
using Fees_DBASC.Core.Routing;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Controls.Primitives;
using Microsoft.UI.Xaml.Data;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Navigation;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;

// To learn more about WinUI, the WinUI project structure,
// and more about our project templates, see: http://aka.ms/winui-project-info.

namespace Fees_DBASC.Views.Pages
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class ManageAccount : Page
    {
        public ManageAccount()
        {
            this.InitializeComponent();
        }

        private void HandleSignOut(object sender, RoutedEventArgs e)
        {
            if (NavigationService.RootFrame != null)
            {
                NavigationService.RootFrame.Navigate(typeof(SignIn));
            }
        }

        private void PageLoaded(object sender, RoutedEventArgs e)
        {
            string role = string.Empty;

            switch(GlobalUserRole.Role)
            {
                case 0:
                    role = "Viewer";
                    break;
                case 1:
                    role = "Editor";
                    break;
                case 2:
                    role = "Approver";
                    break;
            }

            Username.Text = GlobalUserRole.Name.Substring(0, 1).ToUpper() + GlobalUserRole.Name.Substring(1); ;
            Role.Text = role;

        }
    }
}
