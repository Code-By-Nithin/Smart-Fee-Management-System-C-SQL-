// Copyright (c) Microsoft Corporation and Contributors.
// Licensed under the MIT License.

using Fees_DBASC.Core.Routing;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Controls.Primitives;
using Microsoft.UI.Xaml.Data;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Navigation;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;

namespace Fees_DBASC.Views.Pages
{
    public sealed partial class UploadFeesStructure : Page
    {
        public UploadFeesStructure()
        {
            this.InitializeComponent();
        }

        private void FeesStructureUploaderClicked(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(this, new FeesStructureUploader());
        }

        private void FeesStructureCreatorClicked(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(this, new FeesStructureCreator());
        }
    }
}
