using Fees_DBASC.Core.Authentication;
using Fees_DBASC.Core.Database;
using Fees_DBASC.Core.Routing;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace Fees_DBASC.Views.Pages
{
    public sealed partial class SignIn : Page
    {
        public SignIn()
        {
            this.InitializeComponent();
        }

        #region Other Methods

        private async void UpdateDatabaseStatus()
        {
            bool isConnected = false;

            RefreshIcon.Visibility = Visibility.Collapsed;
            RefreshProgress.Visibility = Visibility.Visible;

            await Task.Run(async () =>
            {
                try
                {
                    using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                    await connection.OpenAsync();
                    isConnected = await connection.PingAsync();
                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.Message);
                    throw;
                }

            }).ContinueWith(t =>
            {
                if (t.Exception != null)
                {
                    isConnected = false;
                }
                else
                {
                    isConnected = true;
                }

                DatabaseStatus.Text = $"Database Status: {(isConnected ? "Online" : "Offline")}";
                RefreshIcon.Visibility = Visibility.Visible;
                RefreshProgress.Visibility = Visibility.Collapsed;

            }, TaskScheduler.FromCurrentSynchronizationContext());

        }

        private async void SubmitForm()
        {
            List<string> errors = new();

            if (string.IsNullOrEmpty(Username.Text)) errors.Add("username");
            if (string.IsNullOrEmpty(Password.Password)) errors.Add("password");

            if (errors.Any())
            {
                ErrorInfoBar.Message = $"Please enter the {string.Join(" and ", errors)}.";
                ErrorInfoBar.IsOpen = true;
            }
            else
            {
                ErrorInfoBar.IsOpen = false;
                ProgressBar.Visibility = Visibility.Visible;

                string username = Username.Text;
                string password = Password.Password;

                try
                {
                    AuthenticationController authController = new();
                    bool authenticated = await Task.Run(() => authController.AuthenticateUserAsync(username, password));
                    if (authenticated)
                    {
                        GlobalUserRole.Role = authController.GetRole();
                        GlobalUserRole.Id = authController.GetId();
                        GlobalUserRole.Name = authController.GetName();

                        Dashboard dashboard = new();
                        NavigationService.Navigate(this, dashboard);
                    }
                    else
                    {
                        ErrorInfoBar.Message = "Invalid username or password";
                        ErrorInfoBar.IsOpen = true;
                    }
                }
                catch (Exception ex)
                {
                    ErrorInfoBar.Message = "Database connection failed. Please contact support if the issue persists.";
                    ErrorInfoBar.IsOpen = true;
                    Debug.WriteLine(ex.Message);
                }
                finally
                {
                    ProgressBar.Visibility = Visibility.Collapsed;
                }
            }
        }

        #endregion

        #region Event Handlers

        private void HandleSignIn(object sender, RoutedEventArgs e)
        {
            SubmitForm();
        }

        private async void OpenConfigurationWizard(object sender, RoutedEventArgs e)
        {
            DatabaseServer.Text = GlobalDatabaseConfiguration.Server;
            DatabasePort.Text = GlobalDatabaseConfiguration.Port;
            DatabaseName.Text = GlobalDatabaseConfiguration.Database;
            DatabaseUsername.Text = GlobalDatabaseConfiguration.Username;
            DatabasePassword.Password = GlobalDatabaseConfiguration.Password;

            await MySqlConfigurationWizard.ShowAsync();
        }

        private void HandleExit(object sender, RoutedEventArgs e)
        {
            Application.Current.Exit();
        }

        private void PageLoaded(object sender, RoutedEventArgs e)
        {
            UpdateDatabaseStatus();
        }

        private void HandleRefresh(object sender, RoutedEventArgs e)
        {
            UpdateDatabaseStatus();
        }

        private void HandleSaveConfiguration(ContentDialog sender, ContentDialogButtonClickEventArgs args)
        {
            List<string> errors = new();

            if (string.IsNullOrEmpty(DatabaseServer.Text)) errors.Add("server address");
            if (string.IsNullOrEmpty(DatabasePort.Text)) errors.Add("port number");
            if (string.IsNullOrEmpty(DatabaseUsername.Text)) errors.Add("username");
            if (string.IsNullOrEmpty(DatabasePassword.Password)) errors.Add("password");
            if (string.IsNullOrEmpty(DatabaseName.Text)) errors.Add("database name");

            if (errors.Any())
            {
                args.Cancel = true;
                ConfigurationErrorInfoBar.Message = $"Please enter the {string.Join(" and ", errors)}.";
                ConfigurationErrorInfoBar.IsOpen = true;
            }
            else
            {
                DatabaseConfiguration configuration = new()
                {
                    Server = DatabaseServer.Text,
                    Port = DatabasePort.Text,
                    Database = DatabaseName.Text,
                    Username = DatabaseUsername.Text,
                    Password = DatabasePassword.Password
                };

                configuration.Save();
            }
        }

        #endregion

        private void UsernameKeyDown(object sender, Microsoft.UI.Xaml.Input.KeyRoutedEventArgs e)
        {
            if (e.Key == Windows.System.VirtualKey.Enter)
            {
                e.Handled = true;
                Password.Focus(FocusState.Programmatic);
            }
        }

        private void PasswordKeyDown(object sender, Microsoft.UI.Xaml.Input.KeyRoutedEventArgs e)
        {
            if (e.Key == Windows.System.VirtualKey.Enter)
            {
                e.Handled = true;
                SubmitForm();
            }
        }
    }
}
