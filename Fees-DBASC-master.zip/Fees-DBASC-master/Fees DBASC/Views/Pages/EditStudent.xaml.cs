// Copyright (c) Microsoft Corporation and Contributors.
// Licensed under the MIT License.

using Fees_DBASC.Core.Authentication;
using Fees_DBASC.Core.Database;
using Fees_DBASC.Core.Exceptions;
using Fees_DBASC.Data.Models;
using Fees_DBASC.Data.Sources;
using Microsoft.UI.Text;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Controls.Primitives;
using Microsoft.UI.Xaml.Data;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Navigation;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.Foundation.Collections;

// To learn more about WinUI, the WinUI project structure,
// and more about our project templates, see: http://aka.ms/winui-project-info.

namespace Fees_DBASC.Views.Pages
{
    public sealed partial class EditStudent : Page
    {
        Student studentData = null;

        public EditStudent()
        {
            this.InitializeComponent();
        }

        protected override void OnNavigatedTo(Microsoft.UI.Xaml.Navigation.NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);
            FetchCourseData();
            if (e.Parameter != null && e.Parameter is Student data)
            {
                studentData = data;
            }
        }

        private async void FetchCourseData()
        {
            List<Course> courses = new();
            Course course = null;
            await Task.Run(async () =>
            {
                try
                {
                    using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                    await connection.OpenAsync();

                    MySqlCommand command = connection.CreateCommand();
                    command.CommandText = "SELECT * FROM courses";

                    using MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync();
                    while (await reader.ReadAsync())
                    {
                        int idOrdinal = reader.GetOrdinal("id");
                        int nameOrdinal = reader.GetOrdinal("name");
                        int semestersOrdinal = reader.GetOrdinal("semesters");
                        int TimestampOrdinal = reader.GetOrdinal("Timestamp");

                        course = new()
                        {
                            Id = reader.IsDBNull(idOrdinal) ? -1 : reader.GetInt32(idOrdinal),
                            Name = reader.IsDBNull(nameOrdinal) ? null : reader.GetString(nameOrdinal),
                            Semesters = reader.IsDBNull(semestersOrdinal) ? 0 : reader.GetInt32(semestersOrdinal),
                            Timestamp = reader.IsDBNull(TimestampOrdinal) ? DateTime.Now : reader.GetDateTime(TimestampOrdinal),
                        };

                        courses.Add(course);
                    }
                    await reader.CloseAsync();
                }
                catch (Exception e)
                {
                    Debug.WriteLine(e.Message);
                    throw;
                }
            }).ContinueWith(t =>
            {
                if (t.Exception != null)
                {
                    MessageDialog.IsOpen = true;
                    MessageDialog.Message = t.Exception.Message;
                }
                else
                {
                    ProgressBar.Visibility = Visibility.Collapsed;
                    MessageDialog.IsOpen = false;
                    PreFillData(courses);
                }

            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        private void PreFillData(List<Course> courses)
        {
            State.ItemsSource = new StateDataSource().GetStates();
            State.SelectedItem = "Kerala";

            List<int> academicYear = new();
            for (int i = DateTime.Now.Year - 20; i < DateTime.Now.Year + 5; i++)
            {
                academicYear.Add(i);
            }

            AcademicYear.ItemsSource = academicYear;
            AcademicYear.SelectedItem = DateTime.Now.Year;

            Course.ItemsSource = courses;
            Course.SelectedIndex = 0;

            if (studentData != null)
            {
                FillDataForEditing();
            }
        }

        private void ValidateStudentData()
        {
            List<string> errors = new();

            if (string.IsNullOrEmpty(AdmissionNumber.Text)) errors.Add("admission number");
            if (string.IsNullOrEmpty(StudentName.Text)) errors.Add("student name");
            if (string.IsNullOrEmpty(Course.SelectedValue.ToString())) errors.Add("course");
            if (string.IsNullOrEmpty(AcademicYear.SelectedValue.ToString())) errors.Add("academic year");

            if (errors.Any())
            {
                string errorMessage = $"Please enter the {string.Join(", ", errors)}";
                if (errors.Count > 1)
                {
                    int lastIndex = errorMessage.LastIndexOf(", ");
                    errorMessage = errorMessage.Substring(0, lastIndex) + $" and{errorMessage.Substring(lastIndex + 1)}";
                }
                errorMessage += ".";
                MessageDialog.Severity = InfoBarSeverity.Error;
                MessageDialog.Message = errorMessage;
                MessageDialog.IsOpen = true;
            }
            else
            {
                MessageDialog.IsOpen = false;
                SaveStudentData();
            }
        }

        private void FillDataForEditing()
        {
            AdmissionNumber.Text = studentData.Id.ToString();
            AdmissionNumber.IsEnabled = false;
            StudentName.Text = studentData.Name;
            FathersName.Text = studentData.FathersName;
            MothersName.Text = studentData.MothersName;
            Course.SelectedValue = studentData.CourseId;
            AcademicYear.SelectedValue = int.Parse(studentData.AcademicYear.Trim());
            Address1.Document.SetText(TextSetOptions.None, studentData.Address1);
            Address2.Document.SetText(TextSetOptions.None, studentData.Address2);
            City.Text = studentData.City;
            State.SelectedValue = studentData.State;
            ZipCode.Text = studentData.ZipCode;
            Phone.Text = studentData.Phone;
            Mobile.Text = studentData.Mobile;
            Email.Text = studentData.Email;

            if (GlobalUserRole.Role != 1)
            {
                AdmissionNumber.IsReadOnly = true;
                AdmissionNumber.IsReadOnly = true;
                StudentName.IsReadOnly = true;
                FathersName.IsReadOnly = true;
                MothersName.IsReadOnly = true;
                Course.IsEnabled = false;
                AcademicYear.IsEnabled = false;
                Address1.IsReadOnly = true;
                Address2.IsReadOnly = true;
                City.IsReadOnly = true;
                State.IsEnabled = false;
                ZipCode.IsReadOnly = true;
                Phone.IsReadOnly = true;
                Mobile.IsReadOnly = true;
                Email.IsReadOnly = true;
                ResetBtn.Visibility = Visibility.Collapsed;
                UpdateBtn.Visibility = Visibility.Collapsed;
            }
        }

        private async void SaveStudentData()
        {
            string address1 = string.Empty;
            string address2 = string.Empty;
            Address1.Document.GetText(TextGetOptions.None, out address1);
            Address2.Document.GetText(TextGetOptions.None, out address2);

            var selectedCourse = Course.SelectedItem as Course;
            Debug.WriteLine(selectedCourse.Id);
            int courseId = selectedCourse.Id;

            int admissionNumber = Int32.Parse(AdmissionNumber.Text);
            string studentName = StudentName.Text;
            string academicYear = AcademicYear.SelectedValue.ToString();
            string fathersName = FathersName.Text;
            string mothersName = MothersName.Text;
            string city = City.Text;
            string state = State.SelectedItem.ToString();
            string zipcode = ZipCode.Text;
            string phone = Phone.Text;
            string mobile = Mobile.Text;
            string email = Email.Text;

            await Task.Run(async () =>
            {
                try
                {
                    using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                    await connection.OpenAsync();

                    MySqlCommand command = connection.CreateCommand();
                    command.CommandText = "update students set student_name=@name,academic_year=@academic_year,fathers_name=@fathers_name,mothers_name=@mothers_name,address_line1=@address_line1,address_line2=@address_line1,city=@city,state=@state,zip_code=@zip_code,phone=@phone,mobile=@mobile,email=@email,course_id=@course_id WHERE id=@id";
                    command.Parameters.Clear();

                    command.Parameters.AddWithValue("@id", studentData.Id);
                    command.Parameters.AddWithValue("@name", studentName);
                    command.Parameters.AddWithValue("@academic_year", academicYear);
                    command.Parameters.AddWithValue("@fathers_name", fathersName);
                    command.Parameters.AddWithValue("@mothers_name", mothersName);
                    command.Parameters.AddWithValue("@address_line1", address1);
                    command.Parameters.AddWithValue("@address_line2", address2);
                    command.Parameters.AddWithValue("@city", city);
                    command.Parameters.AddWithValue("@state", state);
                    command.Parameters.AddWithValue("@zip_code", zipcode);
                    command.Parameters.AddWithValue("@phone", phone);
                    command.Parameters.AddWithValue("@mobile", mobile);
                    command.Parameters.AddWithValue("@email", email);
                    command.Parameters.AddWithValue("@course_id", courseId);
                    command.Parameters.AddWithValue("@standard", null);
                    command.Parameters.AddWithValue("@division", null);
                    await command.ExecuteNonQueryAsync();
                }
                catch (Exception e)
                {
                    Debug.WriteLine(e.Message);
                    throw;
                }
            }).ContinueWith(t =>
            {
                if (t.Exception != null)
                {
                    MessageDialog.Severity = InfoBarSeverity.Error;
                    MessageDialog.IsOpen = true;
                    MessageDialog.Message = t.Exception.Message;
                }
                else
                {
                    ProgressBar.Visibility = Visibility.Collapsed;
                    MessageDialog.Severity = InfoBarSeverity.Success;
                    MessageDialog.IsOpen = true;
                    MessageDialog.Message = "Student Data Updated Successfully";
                }

            }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        private void HandleResetForm(object sender, RoutedEventArgs e)
        {
            StudentName.Text = string.Empty;
            FathersName.Text = string.Empty;
            MothersName.Text = string.Empty;
            Course.SelectedIndex = 0;
            AcademicYear.SelectedIndex = 0;
            Address1.Document.SetText(TextSetOptions.None, string.Empty);
            Address2.Document.SetText(TextSetOptions.None, string.Empty);
            City.Text = string.Empty;
            State.SelectedIndex = 0;
            ZipCode.Text = string.Empty;
            Phone.Text = string.Empty;
            Mobile.Text = string.Empty;
            Email.Text = string.Empty;
        }

        private void HandleSaveData(object sender, RoutedEventArgs e)
        {
            ValidateStudentData();
        }

        private void PageLoaded(object sender, RoutedEventArgs e)
        {

        }

        private void AdmissionNumberTextChanging(TextBox sender, TextBoxBeforeTextChangingEventArgs args)
        {
            if (args.NewText.Length > 0)
            {
                if (!int.TryParse(args.NewText, out _))
                {
                    args.Cancel = true;
                }
            }
        }
    }
}
