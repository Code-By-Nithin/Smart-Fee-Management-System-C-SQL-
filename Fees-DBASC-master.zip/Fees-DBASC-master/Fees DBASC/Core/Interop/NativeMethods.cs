﻿using System;
using System.Runtime.InteropServices;
using static Fees_DBASC.Core.Interop.NativeTypes;

namespace Fees_DBASC.Core.Interop
{
    internal static class NativeMethods
    {
        [DllImport("CoreMessaging.dll")]
        internal static extern int CreateDispatcherQueueController([In] DispatcherQueueOptions options, [In, Out, MarshalAs(UnmanagedType.IUnknown)] ref object dispatcherQueueController);

        [DllImport("user32.dll", ExactSpelling = true, CharSet = CharSet.Auto, PreserveSig = true, SetLastError = false)]
        public static extern IntPtr GetActiveWindow();

        [DllImport("user32.dll")]
        public static extern uint GetDpiForWindow(IntPtr hwnd);
    }
}
