﻿using System.Runtime.InteropServices;

namespace Fees_DBASC.Core.Interop
{
    internal static class NativeTypes
    {
        [StructLayout(LayoutKind.Sequential)]
        internal struct DispatcherQueueOptions
        {
            internal int dwSize;
            internal int threadType;
            internal int apartmentType;
        }
    }
}
