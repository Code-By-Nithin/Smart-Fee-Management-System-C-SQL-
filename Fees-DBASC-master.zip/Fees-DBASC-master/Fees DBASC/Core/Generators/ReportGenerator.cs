﻿using Fees_DBASC.Data.Models;
using Fees_DBASC.Data.Parsers;
using iText.IO.Font.Constants;
using iText.Kernel.Font;
using iText.Kernel.Geom;
using iText.Kernel.Pdf;
using iText.Layout;
using iText.Layout.Borders;
using iText.Layout.Element;
using iText.Layout.Properties;
using NumericWordsConversion;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text.Json;

namespace Fees_DBASC.Core.Generators
{
    public class ReportGenerator
    {
        private const int fontSize = 8;
        public ReportGenerator() 
        {
        
        }

        private double CalculateTotal(JsonElement element)
        {
            double total = 0;

            foreach (JsonProperty property in element.EnumerateObject())
            {
                if (property.Name != "serialNumber")
                {
                    if (property.Value.ValueKind == JsonValueKind.Object)
                    {
                        total += CalculateTotal(property.Value);
                    }
                    else if (property.Value.ValueKind == JsonValueKind.String)
                    {
                        string valueStr = property.Value.GetString();
                        if (double.TryParse(valueStr, out double numericValue))
                        {
                            total += numericValue;
                        }
                    }
                    else if (property.Value.ValueKind == JsonValueKind.Number)
                    {
                        total += property.Value.GetDouble();
                    }
                }
            }

            return total;
        }

        public void GenerateReport(List<FeesReport> reports, string outputPath, bool preview=false)
        {
            using var writer = new PdfWriter(outputPath);
            using var pdf = new PdfDocument(writer);
            using var document = new Document(pdf,PageSize.A4.Rotate());
            document.SetFontSize(fontSize);
            document.SetMargins(10, 10, 10, 10);

            PdfFont headingFont = PdfFontFactory.CreateFont(StandardFonts.HELVETICA_BOLD);
            PdfFont textFont = PdfFontFactory.CreateFont(StandardFonts.HELVETICA);
            Style headingStyle = new Style().SetFont(headingFont).SetFontSize(14).SetBold().SetTextAlignment(TextAlignment.CENTER);
            Style addressStyle = new Style().SetFont(headingFont).SetFontSize(10).SetBold().SetTextAlignment(TextAlignment.CENTER);
            Style captionStyle = new Style().SetFont(headingFont).SetFontSize(9).SetTextAlignment(TextAlignment.CENTER);


            foreach (var report in reports)
            {
                int finalSerialNumber = 0;

                Table splitSectionTable = new(3);
                splitSectionTable.SetWidth(UnitValue.CreatePercentValue(100));
                splitSectionTable.SetBorder(Border.NO_BORDER);
                splitSectionTable.SetMargin(10);

                Cell leftSectionCell = new();
                leftSectionCell.SetPadding(10);
                leftSectionCell.SetMarginLeft(10);

                Cell middleSectionCell = new();
                middleSectionCell.SetBorder(Border.NO_BORDER);
                middleSectionCell.SetPadding(10);


                Cell rightSectionCell = new();
                rightSectionCell.SetPadding(10);

                // Add Title 'DON BOSCO ARTS & SCIENCE COLLEGE'
                Paragraph heading = new Paragraph("DON BOSCO ARTS & SCIENCE COLLEGE").AddStyle(headingStyle).SetHorizontalAlignment(HorizontalAlignment.CENTER);
                leftSectionCell.Add(heading);
                rightSectionCell.Add(heading);

                Paragraph address = new Paragraph("ANGADIKADAVU, KANNUR - 670706").AddStyle(addressStyle).SetHorizontalAlignment(HorizontalAlignment.CENTER).SetFixedLeading(5);
                leftSectionCell.Add(address);
                rightSectionCell.Add(address);


                Paragraph caption = new Paragraph("DAILY FEE COLLECTION RECEIPT").AddStyle(captionStyle).SetHorizontalAlignment(HorizontalAlignment.CENTER).SetMarginTop(5);
                leftSectionCell.Add(caption);
                caption = new Paragraph("DAILY FEE COLLECTION RECEIPT").AddStyle(captionStyle).SetHorizontalAlignment(HorizontalAlignment.CENTER).SetMarginTop(5);
                rightSectionCell.Add(caption);

                // Receipt Number and Date
                Table receiptDetailsTable = new(2);
                receiptDetailsTable.SetMarginTop(15);
                receiptDetailsTable.SetWidth(UnitValue.CreatePercentValue(100));
                receiptDetailsTable.SetBorder(Border.NO_BORDER);

                Cell leftCell = new();
                Cell rightCell = new();

                leftCell.SetBorder(Border.NO_BORDER);
                leftCell.SetTextAlignment(TextAlignment.LEFT);

                Table labelWrapLeft = new(1);
                labelWrapLeft.AddCell(new Cell().Add(new Paragraph("COPY").AddStyle(captionStyle).SetFontSize(8).SetHorizontalAlignment(HorizontalAlignment.CENTER)));
                labelWrapLeft.SetWidth(50);
                labelWrapLeft.SetBorder(new SolidBorder(1));
                leftSectionCell.Add(labelWrapLeft);

                rightCell.SetBorder(Border.NO_BORDER);
                rightCell.SetTextAlignment(TextAlignment.RIGHT);

                Table labelWrapRight = new(1);
                labelWrapRight.AddCell(new Cell().Add(new Paragraph("ORIGINAL").AddStyle(captionStyle).SetFontSize(8).SetHorizontalAlignment(HorizontalAlignment.CENTER)));
                labelWrapRight.SetWidth(50);
                labelWrapRight.SetBorder(new SolidBorder(1));
                rightSectionCell.Add(labelWrapRight);

                Paragraph receiptNo = new();
                receiptNo.SetFontSize(fontSize);
                receiptNo.Add(new Text("Receipt No: ").SetFont(headingFont));
                receiptNo.Add(new Text($"{report.Id}").SetFont(textFont).SetFontSize(8));


                Paragraph receiptDate = new();
                receiptDate.SetFontSize(fontSize);
                receiptDate.Add(new Text("Date: ").SetFont(headingFont));
                receiptDate.Add(new Text($"{report.Date:dd-MM-yyyy}").SetFont(textFont).SetFontSize(8));

                if(!preview)
                {
                    leftCell.Add(receiptNo);
                }

                rightCell.Add(receiptDate);
                receiptDetailsTable.AddCell(leftCell);
                receiptDetailsTable.AddCell(rightCell);

                leftSectionCell.Add(receiptDetailsTable);
                rightSectionCell.Add(receiptDetailsTable);

                // Course Name,Semester, Academic year
                Paragraph courseDetails = new();
                courseDetails.SetMarginTop(5);
                courseDetails.SetMarginLeft(2);
                courseDetails.SetFontSize(fontSize);
                courseDetails.Add(new Text("Course: ").SetFont(headingFont));
                courseDetails.Add(new Text($"{report.CourseName}, Semester {report.Semesters}, Academic Year {report.AcademicYears}").SetFont(textFont).SetFontSize(8));
                leftSectionCell.Add(courseDetails);
                rightSectionCell.Add(courseDetails);

                // Payment Method
                Paragraph paymentDetails = new();
                paymentDetails.SetMarginTop(5);
                paymentDetails.SetMarginLeft(2);
                paymentDetails.SetFontSize(fontSize);
                paymentDetails.Add(new Text("Payment Method: ").SetFont(headingFont));

                if(report.PaymentMethod=="Bank")
                {
                    paymentDetails.Add(new Text($"{report.PaymentMethod}, {report.BankName}").SetFont(textFont).SetFontSize(10).SetBold());
                }
                else
                {
                    paymentDetails.Add(new Text($"{report.PaymentMethod}").SetFont(textFont).SetFontSize(10).SetBold());
                }

                leftSectionCell.Add(paymentDetails);
                rightSectionCell.Add(paymentDetails);

                // Render Fees Table
                JsonDocument jsonDocument = JsonDocument.Parse(new JsonParser().Sort(report.ReportData));
                JsonElement root = jsonDocument.RootElement;

                Table feesTable = new Table(UnitValue.CreatePercentArray(new float[] { 10, 45f, 45f })).UseAllAvailableWidth();
                feesTable.SetMarginTop(10);

                feesTable.AddCell(new Cell().Add(new Paragraph("SL No.").SetTextAlignment(TextAlignment.CENTER).SetBold()));
                feesTable.AddCell(new Cell().Add(new Paragraph("Particulars").SetBold()));
                feesTable.AddCell(new Cell().Add(new Paragraph("Amount").SetBold()));

                foreach (JsonProperty property in root.EnumerateObject())
                {
                    if (property.Value.ValueKind == JsonValueKind.Object)
                    {
                        string label = property.Value.GetProperty("label").GetString().Replace(": -", "");
                        string serialNumber = property.Value.GetProperty("serialNumber").GetString();

                        if (property.Value.TryGetProperty("categories", out JsonElement categories) && categories.ValueKind == JsonValueKind.Array && categories.GetArrayLength() > 0)
                        {
                            feesTable.AddCell(new Cell().Add(new Paragraph(serialNumber).SetTextAlignment(TextAlignment.CENTER)));
                            feesTable.AddCell(new Cell(1, 2).Add(new Paragraph(label)));

                            foreach (JsonElement category in categories.EnumerateArray())
                            {
                                if (category.ValueKind == JsonValueKind.Object)
                                {
                                    string serialNumberSub = category.GetProperty("serialNumber").GetString();
                                    string fees = category.GetProperty("fees").GetString();
                                    string categoryLabel = category.GetProperty("label").GetString().Replace(": -", "");

                                    feesTable.AddCell(new Cell().Add(new Paragraph(serialNumberSub).SetTextAlignment(TextAlignment.CENTER)));
                                    feesTable.AddCell(new Cell().Add(new Paragraph(categoryLabel)));
                                    feesTable.AddCell(new Cell().Add(new Paragraph(fees)));
                                }
                            }
                        }
                        else
                        {
                            string fees = property.Value.GetProperty("fees").GetString();
                            string serialNumberSub = property.Value.GetProperty("serialNumber").GetString();

                            feesTable.AddCell(new Cell().Add(new Paragraph(serialNumberSub).SetTextAlignment(TextAlignment.CENTER)));
                            feesTable.AddCell(new Cell().Add(new Paragraph(label)));
                            feesTable.AddCell(new Cell().Add(new Paragraph(fees)));
                        }

                        finalSerialNumber = int.Parse(serialNumber);
                    }
                }


                var total = CalculateTotal(root);

                if (report.Fine>0)
                {
                    int slno = int.Parse(finalSerialNumber.ToString())+1;
                    feesTable.AddCell(new Cell().Add(new Paragraph(slno.ToString()).SetTextAlignment(TextAlignment.CENTER)));
                    feesTable.AddCell(new Cell().Add(new Paragraph("Late Fees")));
                    feesTable.AddCell(new Cell().Add(new Paragraph(report.Fine.ToString())));
                    total += report.Fine;
                }

                if(report.PartialPayment > 0)
                {
                    int slno = int.Parse(finalSerialNumber.ToString()) + 1;
                    feesTable.AddCell(new Cell().Add(new Paragraph(slno.ToString()).SetTextAlignment(TextAlignment.CENTER)));
                    feesTable.AddCell(new Cell().Add(new Paragraph("Partial Payments")));
                    feesTable.AddCell(new Cell().Add(new Paragraph(report.PartialPayment.ToString())));
                    total += report.PartialPayment;
                }

                feesTable.AddCell(new Cell().Add(new Paragraph(" ").SetTextAlignment(TextAlignment.CENTER).SetBold()));
                feesTable.AddCell(new Cell().Add(new Paragraph("GRAND TOTAL").SetBold().SetTextAlignment(TextAlignment.LEFT)));
                feesTable.AddCell(new Cell().Add(new Paragraph(total.ToString()).SetBold()));

                leftSectionCell.Add(feesTable);
                rightSectionCell.Add(feesTable);



                var format = new CurrencyFormat
                {
                    CurrencyCode = "INR",
                    CurrencyName = "Indian Rupee",
                    Culture = Culture.Hindi,
                    CurrencyUnit = "rupees",
                    SubCurrencyUnit = "paisa"
                };

                var converter = new CurrencyWordsConverter(new CurrencyWordsConversionOptions()
                {
                    Culture = format.Culture,
                    OutputFormat = OutputFormat.English,
                    CurrencyUnitSeparator = "and",
                    CurrencyUnit = format.CurrencyUnit,
                    SubCurrencyUnit = format.SubCurrencyUnit,
                    EndOfWordsMarker = "only"
                });


                Paragraph totalAmountWords = new();
                totalAmountWords.SetFontSize(fontSize);
                totalAmountWords.SetMarginTop(15);
                totalAmountWords.Add(new Text("Rupees: ").SetFont(headingFont));
                totalAmountWords.Add(new Text($"{converter.ToWords((decimal)total)}").SetFont(textFont).SetFontSize(8));
                //totalAmountWords.SetNextRenderer(new DottedUnderlineRenderer(totalAmountWords));

                leftSectionCell.Add(totalAmountWords);
                rightSectionCell.Add(totalAmountWords);


                // Add Signature Columns
                Table signatureTable = new(2);
                signatureTable.SetMarginTop(40);
                signatureTable.SetWidth(UnitValue.CreatePercentValue(100));
                signatureTable.SetBorder(Border.NO_BORDER);

                signatureTable.AddCell(new Cell().SetBorder(Border.NO_BORDER).SetTextAlignment(TextAlignment.CENTER).Add(new Paragraph("Name & Signature")));
                signatureTable.AddCell(new Cell().SetBorder(Border.NO_BORDER).SetTextAlignment(TextAlignment.CENTER).Add(new Paragraph("Name & Signature")));
                signatureTable.AddCell(new Cell().SetBorder(Border.NO_BORDER).SetTextAlignment(TextAlignment.CENTER).Add(new Paragraph("Clerk").SetFont(headingFont)));
                signatureTable.AddCell(new Cell().SetBorder(Border.NO_BORDER).SetTextAlignment(TextAlignment.CENTER).Add(new Paragraph("Administrator").SetFont(headingFont)));

                leftSectionCell.Add(signatureTable);
                rightSectionCell.Add(signatureTable);

                splitSectionTable.AddCell(leftSectionCell);
                splitSectionTable.AddCell(middleSectionCell);
                splitSectionTable.AddCell(rightSectionCell);

                document.Add(splitSectionTable);

                var index = reports.IndexOf(report);
                if (index != reports.Count - 1)
                {
                    document.Add(new AreaBreak());
                }
            }
        }
    }
}
