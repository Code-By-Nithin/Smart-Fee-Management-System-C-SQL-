﻿using Fees_DBASC.Data.Models;
using iText.Forms;
using iText.Forms.Fields;
using iText.IO.Font.Constants;
using iText.Kernel.Font;
using iText.Kernel.Pdf;
using NumericWordsConversion;
using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Windows.Storage;
using Windows.System;

namespace Fees_DBASC.Core.Generators
{
    public class ReceiptGenerator
    {
        private readonly Receipt receipt;
        private readonly string path;

        public ReceiptGenerator(Receipt receipt,string path)
        {
            this.receipt = receipt;
            this.path = path;
        }

        public async Task GenerateReceipt()
        {
            string resourcePath = "Data/Documents/receipt.pdf";
            StorageFile file = await StorageFile.GetFileFromApplicationUriAsync(new Uri($"ms-appx:///{resourcePath}"));
            using Stream stream = await file.OpenStreamForReadAsync();
            PdfDocument receiptPdf = new(new PdfReader(stream), new PdfWriter(path));
            PdfAcroForm receiptForm = PdfAcroForm.GetAcroForm(receiptPdf, true);


            var format = new CurrencyFormat 
            { 
                CurrencyCode = "INR", 
                CurrencyName = "Indian Rupee",
                Culture = Culture.Hindi, 
                CurrencyUnit = "rupees", 
                SubCurrencyUnit = "paisa" 
            };

            var converter = new CurrencyWordsConverter(new CurrencyWordsConversionOptions()
            {
                Culture = format.Culture,
                OutputFormat = OutputFormat.English,
                CurrencyUnitSeparator = "and",
                CurrencyUnit = format.CurrencyUnit,
                SubCurrencyUnit = format.SubCurrencyUnit,
                EndOfWordsMarker = "only"
            });

            receiptForm.GetField("receiptNo").SetValue(receipt.Id.ToString());
            receiptForm.GetField("name").SetValue(receipt.Name);
            receiptForm.GetField("date").SetValue(receipt.Date.ToString("dd-MM-yyyy"));
            receiptForm.GetField("course").SetValue(receipt.Course);
            receiptForm.GetField("admission_no").SetValue(receipt.Student);
            receiptForm.GetField("sum_of_rupees").SetValue(converter.ToWords((decimal)receipt.Amount));
            receiptForm.GetField("payment_method").SetValue(receipt.PaymentMethod);
            receiptForm.GetField("bank_name").SetValue((receipt.PaymentMethod=="Cash")?"": receipt.Bank);
            receiptForm.GetField("towards").SetValue(receipt.Towards);

            PdfFormField total = receiptForm.GetField("total").SetValue(receipt.Amount.ToString()+" /-");
            PdfFont boldFont = PdfFontFactory.CreateFont(StandardFonts.HELVETICA_BOLD);
            total.SetFont(boldFont);

            receiptForm.FlattenFields();
            receiptPdf.Close();
            Thread.Sleep(1);
        }

        public string GetPath()
        {
            return path;
        }
    }
}
