﻿using Microsoft.UI.Composition;
using Microsoft.UI.Composition.SystemBackdrops;
using Microsoft.UI.Xaml;
using WinRT;

namespace Fees_DBASC.Core.UI
{
    public class MicaBackdropController
    {
        public MicaBackdropController(Window window) 
        {
            ApplicationWindow = window;

            Configuration = new SystemBackdropConfiguration
            {
                IsInputActive = true
            };

            Controller = new MicaController();
            Controller.AddSystemBackdropTarget(ApplicationWindow.As<ICompositionSupportsSystemBackdrop>());
            Controller.SetSystemBackdropConfiguration(Configuration);

            ApplicationWindow.Activated += WindowActivated;
            ApplicationWindow.Closed += WindowClosed;

            ((FrameworkElement)window.Content).ActualThemeChanged += ThemeChanged;
        }

        #region Event Listeners

        private void ThemeChanged(FrameworkElement sender, object args)
        {
            switch (sender.ActualTheme)
            {
                case ElementTheme.Dark:
                    Configuration.Theme = SystemBackdropTheme.Dark;
                    break;
                case ElementTheme.Light:
                    Configuration.Theme = SystemBackdropTheme.Light;
                    break;
                case ElementTheme.Default:
                    Configuration.Theme = SystemBackdropTheme.Default;
                    break;
            }
        }

        private void WindowActivated(object sender, WindowActivatedEventArgs args)
        {
            Configuration.IsInputActive = args.WindowActivationState != WindowActivationState.Deactivated;
        }

        private void WindowClosed(object sender, WindowEventArgs args)
        {
            if (Controller != null)
            {
                Controller.Dispose();
                Controller = null;
            }

            ApplicationWindow.Activated -= WindowActivated;
            Configuration = null;
        }

        #endregion

        #region Core Properties

        public Window ApplicationWindow
        {
            get;
            private set;
        }
        
        public MicaController Controller
        {
            get;
            private set;
        }

        public SystemBackdropConfiguration Configuration
        {
            get;
            private set;
        }

        #endregion
    }
}
