﻿using Fees_DBASC.Core.Interop;
using Fees_DBASC.Core.Threading;
using Microsoft.UI;
using Microsoft.UI.Dispatching;
using Microsoft.UI.Windowing;
using Microsoft.UI.Xaml;
using System;
using Windows.Graphics;
using WinRT.Interop;

namespace Fees_DBASC.Core.UI
{
    public class ApplicationWindow : Window
    {
        public ApplicationWindow() 
        {
            DispatcherQueueHelper.Initialize();

            Handle = WindowNative.GetWindowHandle(this);
            Window = AppWindow.GetFromWindowId(Win32Interop.GetWindowIdFromWindow(Handle));
            Presenter = (OverlappedPresenter)Window.Presenter;
            Dpi = NativeMethods.GetDpiForWindow(Handle);

            if (AppWindowTitleBar.IsCustomizationSupported())
            {
                if (Window != null)
                {
                    TitleBar = Window.TitleBar;
                    TitleBar.ExtendsContentIntoTitleBar = true;
                    TitleBar.BackgroundColor = Colors.Transparent;
                    TitleBar.ButtonBackgroundColor = Colors.Transparent;

                    DispatcherQueue.GetForCurrentThread().TryEnqueue(DispatcherQueuePriority.High, new DispatcherQueueHandler(() =>
                    {
                        BackdropController = new MicaBackdropController(this);
                    }));
                }
            }
        }

        public void RedrawDragRegion(int width, int height, int x, int y)
        {
            Window?.TitleBar.SetDragRectangles(new[]
            {
                new RectInt32()
                {
                    Width = width,
                    Height = height,
                    X = x,
                    Y = y,
                }
            });
        }

        #region Core Properties

        public IntPtr Handle
        {
            get;
            private set;
        }

        public AppWindow Window
        {
            get;
            private set;
        }

        public AppWindowTitleBar TitleBar
        {
            get;
            private set;
        }

        public MicaBackdropController BackdropController
        {
            get;
            private set;
        }

        public OverlappedPresenter Presenter
        {
            get;
            private set;
        }

        public uint Dpi
        {
            get;
            set;
        }

        #endregion
    }
}
