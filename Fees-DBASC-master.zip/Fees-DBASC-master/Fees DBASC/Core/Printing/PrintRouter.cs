﻿using Fees_DBASC.Core.Exceptions;
using Fees_DBASC.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Storage;
using Windows.System;

namespace Fees_DBASC.Core.Printing
{
    public class PrintRouter
    {
        private readonly LauncherOptions launcherOptions;

        public PrintRouter() 
        {
            launcherOptions = new()
            {
                DisplayApplicationPicker = false,
            };
        }

        public async Task SendForPrinting(string filePath)
        {
            if (System.IO.File.Exists(filePath))
            {
                StorageFile file = await StorageFile.GetFileFromPathAsync(filePath);
                await Launcher.LaunchFileAsync(file, launcherOptions);
            }
            else
            {
                throw new InvalidLauncherSourceException("Sorry, Printing task failed becaause the source file does not exist.");
            }
        }
    }
}
