﻿using System.Runtime.InteropServices;
using Windows.System;
using static Fees_DBASC.Core.Interop.NativeMethods;
using static Fees_DBASC.Core.Interop.NativeTypes;

namespace Fees_DBASC.Core.Threading
{
    internal static class DispatcherQueueHelper
    {
        private static object dispatcherQueueController = null;

        internal static void Initialize()
        {
            if (DispatcherQueue.GetForCurrentThread() == null && dispatcherQueueController == null)
            {
                DispatcherQueueOptions options = new()
                {
                    dwSize = Marshal.SizeOf(typeof(DispatcherQueueOptions)),
                    threadType = 2,
                    apartmentType = 2
                };

                int result = CreateDispatcherQueueController(options, ref dispatcherQueueController);
                if (result != 0)
                {
                    Marshal.ThrowExceptionForHR(result);
                }
            }
        }
    }
}
