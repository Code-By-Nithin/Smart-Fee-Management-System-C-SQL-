﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fees_DBASC.Core.Routing
{
    public class NavigationEventArgs : EventArgs
    {
        public NavigationEventArgs() { }
    }
}
