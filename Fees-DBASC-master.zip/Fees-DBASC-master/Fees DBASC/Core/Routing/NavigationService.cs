﻿using CommunityToolkit.WinUI.UI;
using Fees_DBASC.Data.Models;
using Fees_DBASC.Views.Pages;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;
using System;
using System.Diagnostics;

namespace Fees_DBASC.Core.Routing
{
    public static class NavigationService
    {
        public static void Navigate(DependencyObject parent, Page page)
        {
            Frame container = null;

            while (parent != null && container == null)
            {
                parent = VisualTreeHelper.GetParent(parent);
                container = parent as Frame;
            }

            container?.Navigate(page.GetType());
        }

        public static void Navigate(DependencyObject parent, Page page, object args)
        {
            Frame container = null;

            while (parent != null && container == null)
            {
                parent = VisualTreeHelper.GetParent(parent);
                container = parent as Frame;
            }

            container?.Navigate(page.GetType(),args);
        }

        public static void GoBack(Frame container)
        {
            Type destination = null;
            Debug.WriteLine(container.Content.GetType());
            switch(container.Content.GetType())
            {
                case Type page when page == typeof(InduvidualStudentUpload):
                    destination = typeof(UploadStudentDetails);
                    break;
                case Type page when page == typeof(StudentGroupUpload):
                    destination = typeof(UploadStudentDetails);
                    break;
                case Type page when page == typeof(FeesStructureUploader):
                    destination = typeof(UploadFeesStructure);
                    break;
                case Type page when page == typeof(ViewFeesStructure):
                    destination = typeof(FeesStructures);
                    break;
                case Type page when page == typeof(Report):
                    destination = typeof(GenerateReport);
                    break;
                case Type page when page == typeof(EditFeesStructures):
                    destination = typeof(FeesStructures);
                    break;
                case Type page when page == typeof(EditStudent):
                    destination = typeof(Students);
                    break;
            }

            if(destination!=null)
            {
                container.Navigate(destination);
            }

        }

        public static Frame RootFrame
        {
            get;
            set;
        }
    }
}
