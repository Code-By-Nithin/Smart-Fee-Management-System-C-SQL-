﻿using iText.Kernel.Pdf.Canvas;
using iText.Layout.Element;
using iText.Layout.Renderer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fees_DBASC.Core.Renderer
{
    public class DottedUnderlineRenderer : ParagraphRenderer
    {
        public DottedUnderlineRenderer(Paragraph modelElement) : base(modelElement)
        {

        }

        public override void Draw(DrawContext drawContext)
        {
            base.Draw(drawContext);
            float x = GetOccupiedAreaBBox().GetLeft();
            float y = GetOccupiedAreaBBox().GetBottom()+5;
            float width = GetOccupiedAreaBBox().GetWidth();
            float courseX = GetChildRenderers()[0].GetOccupiedArea().GetBBox().GetRight();
            float courseWidth = width - (courseX - x);
            PdfCanvas canvas = drawContext.GetCanvas();
            canvas.SetLineDash(1, 3);
            canvas.MoveTo(courseX, y).LineTo(courseX + courseWidth, y).Stroke().SetLineWidth(3.0f);
        }
    }
}
