﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Storage;

namespace Fees_DBASC.Core.Database
{
    public class DatabaseConfiguration
    {
        private readonly ApplicationDataContainer settings;
        private readonly ApplicationDataCompositeValue databaseSettings;

        public DatabaseConfiguration() 
        {
            settings = ApplicationData.Current.LocalSettings;

            if(settings.Values["DatabaseConfiguration"] != null)
            {
                databaseSettings = (ApplicationDataCompositeValue)settings.Values["DatabaseConfiguration"];
            }
            else
            {
                databaseSettings = new ApplicationDataCompositeValue
                {
                    ["Server"] = "127.0.0.1",
                    ["Port"] = "3306",
                    ["Database"] = "dbasc",
                    ["Username"] = "extrimis",
                    ["Password"] = "root123"
                };
            }

            Server = databaseSettings["Server"] as string;
            Port = databaseSettings["Port"] as string;
            Database = databaseSettings["Database"] as string;
            Username = databaseSettings["Username"] as string;
            Password = databaseSettings["Password"] as string;
        }

        #region Core Functions

        public string GetConnectionUrl()
        {
            return $"Server={Server};Port={Port};Database={Database};Uid={Username};Pwd={Password};Pooling=true;";
        }

        public void Save()
        {
            databaseSettings["Server"] = Server;
            databaseSettings["Port"] = Port;
            databaseSettings["Database"] = Database;
            databaseSettings["Username"] = Username;
            databaseSettings["Password"] = Password;
            settings.Values["DatabaseConfiguration"] = databaseSettings;

            GlobalDatabaseConfiguration.Server = Server;
            GlobalDatabaseConfiguration.Port = Port;
            GlobalDatabaseConfiguration.Database = Database;
            GlobalDatabaseConfiguration.Username = Username;
            GlobalDatabaseConfiguration.Password = Password;
            GlobalDatabaseConfiguration.Url = GetConnectionUrl();
        }

        #endregion

        #region Core Properties

        public string Server
        {
            get;
            set;
        }

        public string Port
        {
            get;
            set;
        }

        public string Database
        {
            get;
            set;
        }

        public string Username
        {
            get;
            set;
        }

        public string Password
        {
            get;
            set;
        }

        #endregion
    }
}
