﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fees_DBASC.Core.Database
{
    public static class GlobalDatabaseConfiguration
    {
        public static string Server
        {
            get;
            set;
        }

        public static string Port
        {
            get;
            set;
        }

        public static string Database
        {
            get;
            set;
        }

        public static string Username
        {
            get;
            set;
        }

        public static string Password
        {
            get;
            set;
        }

        public static string Url
        {
            get;
            set;
        }
    }
}
