﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fees_DBASC.Core.Database
{
    public class DatabaseManager
    {
        private readonly DatabaseConfiguration configuration;

        public DatabaseManager(DatabaseConfiguration configuration) 
        {
            this.configuration = configuration;
        }

        public async Task<bool> PingAsync()
        {
            using MySqlConnection connection = new(configuration.GetConnectionUrl());
            await connection.OpenAsync();
            return connection.Ping();
        }
    }
}
