﻿using System;

namespace Fees_DBASC.Core.Exceptions
{
    public class UnknownCourseException : Exception
    {
        public UnknownCourseException(string message) : base(message)
        {

        }
    }
}
