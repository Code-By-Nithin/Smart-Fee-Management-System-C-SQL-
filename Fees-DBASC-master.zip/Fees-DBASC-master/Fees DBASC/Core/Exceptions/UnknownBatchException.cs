﻿using System;

namespace Fees_DBASC.Core.Exceptions
{
    public class UnknownBatchException : Exception
    {
        public UnknownBatchException(String message) : base(message)
        {

        }
    }
}
