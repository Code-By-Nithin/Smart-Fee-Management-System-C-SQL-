﻿using System;

namespace Fees_DBASC.Core.Exceptions
{
    internal class CourseProximityException : Exception
    {
        public CourseProximityException(String message) : base(message)
        {
        }
    }
}
