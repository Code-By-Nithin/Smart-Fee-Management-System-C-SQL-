﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fees_DBASC.Core.Exceptions
{
    public class StudentAlreadyExistException:Exception
    {
        public StudentAlreadyExistException(string message) : base(message)
        {

        }
    }
}
