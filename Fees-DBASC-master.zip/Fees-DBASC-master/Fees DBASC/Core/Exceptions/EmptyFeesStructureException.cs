﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fees_DBASC.Core.Exceptions
{
    public class EmptyFeesStructureException:Exception
    {
        public EmptyFeesStructureException(string message) : base(message)
        { 
        
        }
    }
}
