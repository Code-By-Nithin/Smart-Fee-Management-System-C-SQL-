﻿using System;

namespace Fees_DBASC.Core.Exceptions
{
    public class CSVParsingException : Exception
    {
        public CSVParsingException(string message) : base(message)
        {

        }
    }
}
