﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fees_DBASC.Core.Authentication
{
    public static class GlobalUserRole
    {
        public static int Id
        {
            get;
            set;
        }

        public static string Name
        {
            get;
            set;
        }

        public static int Role 
        { 
            get;
            set; 
        }
    }
}
