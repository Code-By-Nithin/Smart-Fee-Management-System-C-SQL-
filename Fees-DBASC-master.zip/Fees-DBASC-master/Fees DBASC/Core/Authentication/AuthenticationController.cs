﻿using Fees_DBASC.Core.Database;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Windows.Services.Maps;

namespace Fees_DBASC.Core.Authentication
{
    public class AuthenticationController
    {
        public DatabaseConfiguration configuration;
        private int role = 1;
        private int id = -1;
        private string name = string.Empty;

        public AuthenticationController()
        {
            configuration = new DatabaseConfiguration();
        }

        public async Task<bool> AuthenticateUserAsync(string username, string password)
        {
            int count = 0;
            using MySqlConnection connection = new(configuration.GetConnectionUrl());
            string query = $"SELECT COUNT(*) as count,id as uid,username as username,role FROM users WHERE username = @username AND password = @password";

            using MySqlCommand command = new(query, connection);
            command.Parameters.AddWithValue("@username", username);
            command.Parameters.AddWithValue("@password", Cryptography.ComputeHash(password));

            await connection.OpenAsync();

            using MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync();
            while (await reader.ReadAsync())
            {
                int idOrdinal = reader.GetOrdinal("uid");
                int roleOrdinal = reader.GetOrdinal("role");
                int usernameOrdinal = reader.GetOrdinal("username");
                int countOrdinal = reader.GetOrdinal("count");
                role = reader.IsDBNull(roleOrdinal) ? -1 : reader.GetInt32(roleOrdinal);
                count = reader.IsDBNull(countOrdinal) ? -1 : reader.GetInt32(countOrdinal);
                id = reader.IsDBNull(idOrdinal) ? -1 : reader.GetInt32(idOrdinal);
                name = reader.IsDBNull(usernameOrdinal) ? null : reader.GetString(usernameOrdinal);
            }

            return (count > 0);
        }

        public int GetRole()
        {
            return role;
        }

        public int GetId()
        {
            return id;
        }

        public string GetName()
        {
            return name;
        }
    }
}
