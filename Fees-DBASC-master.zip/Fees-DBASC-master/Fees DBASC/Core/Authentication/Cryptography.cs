﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Fees_DBASC.Core.Authentication
{
    public static class Cryptography
    {
        public static string ComputeHash(string text)
        {
            using MD5 md5 = MD5.Create();
            StringBuilder hash = new();

            byte[] inputBytes = Encoding.UTF8.GetBytes(text);
            byte[] hashBytes = md5.ComputeHash(inputBytes);

            for (int i = 0; i < hashBytes.Length; i++)
            {
                hash.Append(hashBytes[i].ToString("x2"));
            }

            return hash.ToString();
        }
    }
}
