using Fees_DBASC.Core.Database;
using Fees_DBASC.Core.Routing;
using Fees_DBASC.Core.UI;
using Fees_DBASC.Views.Pages;
using Microsoft.UI.Xaml;
using System;
using System.Diagnostics;
using Windows.Graphics;

namespace Fees_DBASC
{
    public sealed partial class MainWindow : ApplicationWindow
    {
        public event EventHandler<NavigationEventArgs> NavigatedBack;
        const int backButtonWidth = 35;

        public MainWindow()
        {
            this.InitializeComponent();

            SetTitleBar(AppTitleBar);
            RootContentPresenter.Content = new SignIn();
            RootContentPresenter.Loaded += ContentPresenterLoaded;

            DatabaseConfiguration configuration = new();
            GlobalDatabaseConfiguration.Server = configuration.Server;
            GlobalDatabaseConfiguration.Port = configuration.Port;
            GlobalDatabaseConfiguration.Database = configuration.Database;
            GlobalDatabaseConfiguration.Username = configuration.Username;
            GlobalDatabaseConfiguration.Password = configuration.Password;
            GlobalDatabaseConfiguration.Url = configuration.GetConnectionUrl();

        }

        private void ContentPresenterLoaded(object sender, RoutedEventArgs e)
        {
            NavigationService.RootFrame = RootContentPresenter;
            App app = Application.Current as App;
            app.ApplicationWindow.SizeChanged += ApplicationWindowSizeChanged;

            if (RootContentPresenter.Content.GetType() == typeof(SignIn))
            {
                BackButton.Visibility = Visibility.Collapsed;
            }
            else
            {
                BackButton.Visibility = Visibility.Visible;
            }

            int padding = (int)BackButton.Padding.Left;
            int width = (int)(Window.Size.Width * Dpi / 96);
            int height = TitleBar.Height;
            int left = backButtonWidth;
            RedrawDragRegion(width, height, left + padding, 0);
        }

        private void ApplicationWindowSizeChanged(object sender, WindowSizeChangedEventArgs args)
        {
            int padding = (int)BackButton.Padding.Left;
            int width = (int)(args.Size.Width * Dpi / 96);
            int height = TitleBar.Height;
            int left = backButtonWidth;

            RedrawDragRegion(width, height, left + padding, 0);
        }

        private void HandleNavigateBack(object sender, RoutedEventArgs e)
        {
            OnNavigatedBack(new NavigationEventArgs());
        }

        public void SetBackButtonStatus(bool enabled)
        {
            BackButton.IsEnabled = enabled;
        }

        private void OnNavigatedBack(NavigationEventArgs e)
        {
            NavigatedBack?.Invoke(this, e);
        }

        private void ContentPresenterNavigated(object sender, Microsoft.UI.Xaml.Navigation.NavigationEventArgs e)
        {
            if (RootContentPresenter.Content.GetType() == typeof(SignIn))
            {
                BackButton.Visibility = Visibility.Collapsed;
            }
            else
            {
                BackButton.Visibility = Visibility.Visible;
            }

            int padding = (int)BackButton.Padding.Left;
            int width = (int)(Window.Size.Width * Dpi / 96);
            int height = TitleBar.Height;
            int left = backButtonWidth;
            RedrawDragRegion(width, height, left + padding, 0);
        }

    }
}
