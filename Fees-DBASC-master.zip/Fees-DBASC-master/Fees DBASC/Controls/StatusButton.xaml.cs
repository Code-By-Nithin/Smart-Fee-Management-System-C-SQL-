// Copyright (c) Microsoft Corporation and Contributors.
// Licensed under the MIT License.

using Microsoft.UI;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Controls.Primitives;
using Microsoft.UI.Xaml.Data;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Navigation;
using Microsoft.UI.Xaml.Shapes;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI;

namespace Fees_DBASC.Controls
{
    public sealed partial class StatusButton : UserControl
    {
        public StatusButton()
        {
            this.InitializeComponent();
        }


        #region Dependency Properties

        public string StatusText
        {
            get { return (string)GetValue(StatusTextProperty); }
            set { SetValue(StatusTextProperty, value); }
        }

        public static readonly DependencyProperty StatusTextProperty =DependencyProperty.Register("StatusText", typeof(string), typeof(StatusButton), new PropertyMetadata("OK"));

        public string Glyph
        {
            get { return (string)GetValue(GlyphProperty); }
            set { SetValue(GlyphProperty, value); }
        }

        public static readonly DependencyProperty GlyphProperty = DependencyProperty.Register("Glyph", typeof(string), typeof(StatusButton), new PropertyMetadata("\uf13e"));

        public SolidColorBrush GlyphBackground
        {
            get { return (SolidColorBrush)GetValue(GlyphBackgroundProperty); }
            set { SetValue(GlyphBackgroundProperty, value); }
        }

        public static readonly DependencyProperty GlyphBackgroundProperty = DependencyProperty.Register("GlyphBackground", typeof(SolidColorBrush), typeof(StatusButton), new PropertyMetadata(new SolidColorBrush((Color)Application.Current.Resources["SystemAccentColor"])));

        public SolidColorBrush GlyphForeground
        {
            get { return (SolidColorBrush)GetValue(GlyphForegroundProperty); }
            set { SetValue(GlyphForegroundProperty, value); }
        }

        public static readonly DependencyProperty GlyphForegroundProperty = DependencyProperty.Register("GlyphForeground", typeof(SolidColorBrush), typeof(StatusButton), new PropertyMetadata(new SolidColorBrush(Colors.White)));


        public bool Error
        {
            get { return (bool)GetValue(ErrorProperty); }
            set { SetValue(ErrorProperty, value); }
        }

        public static readonly DependencyProperty ErrorProperty = DependencyProperty.Register("Error", typeof(bool), typeof(StatusButton), new PropertyMetadata(false));


        #endregion

        private void ControlLoaded(object sender, RoutedEventArgs e)
        {
            if(Error)
            {
                GlyphBackground = new SolidColorBrush(Colors.Red);
                Glyph = "\uf13d";
            }
            else
            {
                GlyphBackground = new SolidColorBrush((Color)Application.Current.Resources["SystemAccentColor"]);
                Glyph = "\uf13e";
            }
        }
    }
}
