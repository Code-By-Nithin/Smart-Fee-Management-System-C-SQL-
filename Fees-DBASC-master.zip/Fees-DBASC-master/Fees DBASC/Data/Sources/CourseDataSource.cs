﻿using CommunityToolkit.Common.Collections;
using Fees_DBASC.Core.Database;
using Fees_DBASC.Data.Models;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Fees_DBASC.Data.Sources
{
    public class CourseDataSource : IIncrementalSource<Course>
    {
        private readonly ObservableCollection<Course> courseList;

        public CourseDataSource()
        {
            courseList = new();
        }

        public void EmptyCollection()
        {
            courseList.Clear();
        }

        public async Task<IEnumerable<Course>> GetPagedItemsAsync(int pageIndex, int pageSize, CancellationToken cancellationToken = default)
        {
            try
            {
                using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                await connection.OpenAsync(cancellationToken);

                MySqlCommand command = connection.CreateCommand();
                command.CommandText = "SELECT c.*, (SELECT COUNT(*) FROM students s WHERE s.course_id = c.id) AS students FROM courses c ORDER BY id LIMIT @startIndex, @pageSize";
                command.Parameters.AddWithValue("@startIndex", pageIndex * pageSize);
                command.Parameters.AddWithValue("@pageSize", pageSize);

                using MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync(cancellationToken);
                while (await reader.ReadAsync(cancellationToken))
                {
                    Course course = new()
                    {
                        Id = reader.GetInt32("id"),
                        Name = reader.GetString("name"),
                        Semesters = reader.GetInt32("semesters"),
                        Timestamp = DateTime.Parse(reader.GetString("timestamp")),
                        Students = reader.GetInt32("students"),
                        Type = reader.GetInt32("type")
                    };

                    courseList.Add(course);
                }
            }
            catch (MySqlException)
            {
                throw;
            }

            await Task.Delay(1, cancellationToken);
            return (from course in courseList select course).Skip(pageIndex * pageSize).Take(pageSize);
        }
    }
}
