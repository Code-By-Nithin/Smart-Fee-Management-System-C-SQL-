﻿using CommunityToolkit.Common.Collections;
using Fees_DBASC.Core.Database;
using Fees_DBASC.Data.Models;
using iText.Kernel.Geom;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Fees_DBASC.Data.Sources
{
    public class StudentDataSource : IIncrementalSource<Student>
    {
        private string searchQuery = null;
        private int queryType = -1;
        private readonly ObservableCollection<Student> studentList;

        public StudentDataSource()
        {
            studentList = new();
        }

        public void EmptyCollection()
        {
            studentList.Clear();
        }

        public void Search(string searchQuery,int type)
        {
            this.searchQuery = searchQuery;
            queryType = type;
        }

        public async Task<IEnumerable<Student>> GetPagedItemsAsync(int pageIndex, int pageSize, CancellationToken cancellationToken = default)
        {
            try
            {
                using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                await connection.OpenAsync(cancellationToken);

                MySqlCommand command = connection.CreateCommand();
                if (!string.IsNullOrEmpty(searchQuery))
                {
                    if(queryType==0)
                    {
                        command.CommandText = @"SELECT s.*, c.name AS course_name, c.type AS course_type 
                                   FROM students s 
                                   JOIN courses c ON s.course_id = c.id 
                                   WHERE s.Id LIKE @searchQuery 
                                   ORDER BY s.id 
                                   LIMIT @startIndex, @pageSize;";
                        command.Parameters.AddWithValue("@searchQuery", $"{searchQuery}%");
                    }
                    else
                    {
                        command.CommandText = @"SELECT s.*, c.name AS course_name, c.type AS course_type 
                                   FROM students s 
                                   JOIN courses c ON s.course_id = c.id 
                                   WHERE s.student_name LIKE @searchQuery 
                                   ORDER BY s.id 
                                   LIMIT @startIndex, @pageSize;";
                        command.Parameters.AddWithValue("@searchQuery", $"{searchQuery}%");
                    }
                }
                else
                {
                    command.CommandText = @"SELECT s.*, c.name AS course_name, c.type AS course_type 
                                   FROM students s 
                                   JOIN courses c ON s.course_id = c.id 
                                   ORDER BY s.id 
                                   LIMIT @startIndex, @pageSize;";
                }
                command.Parameters.AddWithValue("@startIndex", pageIndex * pageSize);
                command.Parameters.AddWithValue("@pageSize", pageSize);

                using MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync(cancellationToken);
                while (await reader.ReadAsync(cancellationToken))
                {
                    int courseNameOrdinal = reader.GetOrdinal("course_name");
                    int academicYearOrdinal = reader.GetOrdinal("academic_year");
                    int fathersNameOrdinal = reader.GetOrdinal("fathers_name");
                    int motherssNameOrdinal = reader.GetOrdinal("mothers_name");
                    int address1Ordinal = reader.GetOrdinal("address_line1");
                    int address2Ordinal = reader.GetOrdinal("address_line2");
                    int cityOrdinal = reader.GetOrdinal("city");
                    int stateOrdinal = reader.GetOrdinal("state");
                    int zipCodeOrdinal = reader.GetOrdinal("zip_code");
                    int phoneOrdinal = reader.GetOrdinal("phone");
                    int mobileOrdinal = reader.GetOrdinal("mobile");
                    int emailOrdinal = reader.GetOrdinal("email");
                    int courseIdOrdinal = reader.GetOrdinal("course_id");
                    int standardOrdinal = reader.GetOrdinal("standard");
                    int divisionOrdinal = reader.GetOrdinal("division");
                    int courseTypeOrdinal = reader.GetOrdinal("course_type");

                    Student student = new()
                    {
                        Id = reader.GetInt32("id"),
                        Name = reader.GetString("student_name"),
                        CourseName = reader.IsDBNull(courseNameOrdinal) ? null : reader.GetString(courseNameOrdinal),
                        AcademicYear = reader.IsDBNull(academicYearOrdinal) ? null : reader.GetString(academicYearOrdinal),
                        FathersName = reader.IsDBNull(fathersNameOrdinal) ? null : reader.GetString(fathersNameOrdinal),
                        MothersName = reader.IsDBNull(motherssNameOrdinal) ? null : reader.GetString(motherssNameOrdinal),
                        Address1 = reader.IsDBNull(address1Ordinal) ? null : reader.GetString(address1Ordinal),
                        Address2 = reader.IsDBNull(address2Ordinal) ? null : reader.GetString(address2Ordinal),
                        City = reader.IsDBNull(cityOrdinal) ? null : reader.GetString(cityOrdinal),
                        State = reader.IsDBNull(stateOrdinal) ? null : reader.GetString(stateOrdinal),
                        ZipCode = reader.IsDBNull(zipCodeOrdinal) ? null : reader.GetString(zipCodeOrdinal),
                        Phone = reader.IsDBNull(phoneOrdinal) ? null : reader.GetString(phoneOrdinal),
                        Mobile = reader.IsDBNull(mobileOrdinal) ? null : reader.GetString(mobileOrdinal),
                        Email = reader.IsDBNull(emailOrdinal) ? null : reader.GetString(emailOrdinal),
                        CourseId = reader.IsDBNull(courseIdOrdinal) ? 0 : reader.GetInt32(courseIdOrdinal),
                        CourseType = reader.IsDBNull(courseTypeOrdinal) ? 0 : reader.GetInt32(courseTypeOrdinal),
                        Standard = reader.IsDBNull(standardOrdinal) ? null : reader.GetString(standardOrdinal),
                        Division = reader.IsDBNull(divisionOrdinal) ? null : reader.GetString(divisionOrdinal),
                    };

                    studentList.Add(student);
                }
            }
            catch (MySqlException ex)
            {
                Debug.WriteLine(ex.Message);
                throw;
            }

            await Task.Delay(1, cancellationToken);
            return (from student in studentList select student).Skip(pageIndex * pageSize).Take(pageSize);
        }
    }
}
