﻿using CommunityToolkit.Common.Collections;
using Fees_DBASC.Core.Database;
using Fees_DBASC.Data.Models;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Fees_DBASC.Data.Sources
{
    public class BankDataSource : IIncrementalSource<Bank>
    {
        private readonly ObservableCollection<Bank> bankList;

        public BankDataSource()
        {
            bankList = new();
        }

        public void EmptyCollection()
        {
            bankList.Clear();
        }

        public async Task<IEnumerable<Bank>> GetPagedItemsAsync(int pageIndex, int pageSize, CancellationToken cancellationToken = default)
        {
            try
            {
                using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                await connection.OpenAsync(cancellationToken);

                MySqlCommand command = connection.CreateCommand();
                command.CommandText = "SELECT * FROM banks ORDER BY id LIMIT @startIndex, @pageSize;";
                command.Parameters.AddWithValue("@startIndex", pageIndex * pageSize);
                command.Parameters.AddWithValue("@pageSize", pageSize);

                using MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync(cancellationToken);
                while (await reader.ReadAsync(cancellationToken))
                {
                    int idOrdinal = reader.GetOrdinal("id");
                    int nameOrdinal = reader.GetOrdinal("name");
                    int accountNoOrdinal = reader.GetOrdinal("account_number");
                    int ifscOrdinal = reader.GetOrdinal("ifsc_code");
                    int dateOrdinal = reader.GetOrdinal("date");

                    Bank bank = new()
                    {
                        Id = reader.IsDBNull(idOrdinal) ? -1 : reader.GetInt32(idOrdinal),
                        Name = reader.IsDBNull(nameOrdinal) ? null : reader.GetString(nameOrdinal),
                        AccountNumber = reader.IsDBNull(accountNoOrdinal) ? null : reader.GetString(accountNoOrdinal),
                        IFSCCode = reader.IsDBNull(ifscOrdinal) ? null : reader.GetString(ifscOrdinal),
                        Date = reader.IsDBNull(dateOrdinal) ? DateTime.Now : reader.GetDateTime(dateOrdinal),
                    };

                    bankList.Add(bank);
                }
            }
            catch (MySqlException)
            {
                throw;
            }

            await Task.Delay(1, cancellationToken);
            return (from bank in bankList select bank).Skip(pageIndex * pageSize).Take(pageSize);
        }
    }
}
