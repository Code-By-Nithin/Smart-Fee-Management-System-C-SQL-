﻿using CommunityToolkit.Common.Collections;
using Fees_DBASC.Core.Database;
using Fees_DBASC.Data.Models;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Fees_DBASC.Data.Sources
{
    public class FeesStructureDataSource : IIncrementalSource<FeesData>
    {
        private readonly ObservableCollection<FeesData> feesStructureList;
        private string query = string.Empty;
        private string academicYear="";

        public FeesStructureDataSource() 
        {
            feesStructureList = new();
            query="SELECT fs.*, c.name as course_name,c.semesters as semesters FROM fees_structure fs JOIN courses c ON fs.course_id = c.id ORDER BY fs.id LIMIT @startIndex, @pageSize;";
        }

        public void SetAcademicYear(string year)
        {
            academicYear = year;
        }

        public void EmptyCollection()
        {
            feesStructureList.Clear();
        }

        public async Task<IEnumerable<FeesData>> GetPagedItemsAsync(int pageIndex, int pageSize, CancellationToken cancellationToken = default)
        {
            try
            {
                using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
                await connection.OpenAsync(cancellationToken);

                MySqlCommand command = connection.CreateCommand();

                if (string.IsNullOrEmpty(academicYear))
                {
                    query = "SELECT fs.*, c.name as course_name,c.semesters as semesters FROM fees_structure fs JOIN courses c ON fs.course_id = c.id ORDER BY fs.id LIMIT @startIndex, @pageSize;";
                }
                else
                {
                    query = "SELECT fs.*, c.name as course_name,c.semesters as semesters FROM fees_structure fs JOIN courses c ON fs.course_id = c.id WHERE fs.academic_year = @academicYear ORDER BY fs.id LIMIT @startIndex, @pageSize;";
                }

                command.CommandText = query;
                command.Parameters.AddWithValue("@startIndex", pageIndex * pageSize);
                command.Parameters.AddWithValue("@pageSize", pageSize);
                command.Parameters.AddWithValue("@academicYear", academicYear);

                using MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync(cancellationToken);
                while (await reader.ReadAsync(cancellationToken))
                {
                    int courseIdOrdinal = reader.GetOrdinal("course_id");
                    int courseNameOrdinal = reader.GetOrdinal("course_name");
                    int academicYearOrdinal = reader.GetOrdinal("academic_year");
                    int activeOrdinal = reader.GetOrdinal("active");
                    int jsonOrdinal = reader.GetOrdinal("data");
                    int dateOrdinal = reader.GetOrdinal("date");
                    int semestersOrdinal = reader.GetOrdinal("semesters");

                    FeesData feesStructure = new()
                    {
                       Id = reader.GetInt32("id"),
                       CourseId = reader.IsDBNull(courseIdOrdinal) ? 0 : reader.GetInt32(courseIdOrdinal),
                       CourseName = reader.IsDBNull(courseNameOrdinal) ? null : reader.GetString(courseNameOrdinal),
                       AcademicYear = reader.IsDBNull(academicYearOrdinal) ? null : reader.GetString(academicYearOrdinal),
                       Active = !reader.IsDBNull(activeOrdinal) && reader.GetBoolean(activeOrdinal),
                       Json = reader.IsDBNull(jsonOrdinal) ? null : reader.GetString(jsonOrdinal),
                       Date = reader.IsDBNull(dateOrdinal) ? DateTime.Now : reader.GetDateTime(dateOrdinal),
                       Semesters = reader.IsDBNull(semestersOrdinal) ? 0 : reader.GetInt32(semestersOrdinal),
                    };
                    feesStructureList.Add(feesStructure);
                }
            }
            catch (MySqlException)
            {
                throw;
            }

            await Task.Delay(1, cancellationToken);
            return (from student in feesStructureList select student).Skip(pageIndex * pageSize).Take(pageSize);
        }
    }
}
