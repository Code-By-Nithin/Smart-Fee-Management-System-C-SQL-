﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fees_DBASC.Data.Models
{
    public class Route
    {
        public string Id 
        { 
            get; 
            set; 
        }

        public string Name 
        { 
            get;
            set; 
        }

        public Type Page 
        { 
            get;
            set; 
        }
    }
}
