﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fees_DBASC.Data.Models
{
    public class CourseMap
    {
        public CourseMap() { }

        public int Id 
        { 
            get; set; 
        }

        public string Name 
        { 
            get; set; 
        }
    }
}
