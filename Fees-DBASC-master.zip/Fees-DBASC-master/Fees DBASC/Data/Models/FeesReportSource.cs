﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fees_DBASC.Data.Models
{
    public class FeesReportSource
    {
        public Payment Payment
        {
            get;
            set;
        }

        public FeesData FeesStructure
        {
            get;
            set;
        }
    }
}
