﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fees_DBASC.Data.Models
{
    public class Payment
    {
        public int Id 
        { 
            get;
            set;
        }

        public int StudentId
        { 
            get;
            set;
        }

        public int CourseId
        {
            get;
            set;
        }

        public string CourseName
        {
            get;
            set;
        }

        public string StudentName
        {
            get;
            set;
        }

        public double Amount
        {
            get;
            set;
        }

        public int Semester
        {
            get;
            set;
        }

        public string PaymentMethod
        {
            get;
            set;
        }

        public bool Partial
        {
            get;
            set;
        }

        public int BankId
        {
            get;
            set;
        }

        public double Fine
        {
            get;
            set;
        }

        public DateTime Date
        {
            get;
            set;
        }

        public string ReceiptId
        {
            get;
            set;
        }

        public double TotalFees
        {
            get;
            set;
        }
    }
}
