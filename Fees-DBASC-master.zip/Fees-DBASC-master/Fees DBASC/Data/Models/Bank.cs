﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fees_DBASC.Data.Models
{
    public class Bank
    {
        public int Id 
        { 
            get; 
            set; 
        }

        public string Name 
        { 
            get; 
            set; 
        }

        public string AccountNumber
        {
            get;
            set;
        }

        public string IFSCCode
        {
            get;
            set;
        }

        public DateTime Date
        {
            get;
            set;
        }
    }
}
