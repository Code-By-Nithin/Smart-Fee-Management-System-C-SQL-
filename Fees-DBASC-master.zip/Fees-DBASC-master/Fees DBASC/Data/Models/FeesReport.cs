﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fees_DBASC.Data.Models
{
    public class FeesReport
    {
        public int Id
        {
            get;
            set;
        }

        public DateTime Date
        {
            get;
            set;
        }

        public int Count
        {
            get;
            set;
        }

        public int PartialPaymentCount
        {
            get;
            set;
        }

        public int Course
        {
            get;
            set;
        }

        public string CourseName
        {
            get;
            set;
        }

        public string AcademicYear
        {
            get;
            set;
        }

        public int Semester
        {
            get;
            set;
        }

        public string PaymentMethod
        {
            get;
            set;
        }

        public int Bank
        {
            get;
            set;
        }

        public string BankName
        {
            get;
            set;
        }

        public string SourceFeesData
        {
            get;
            set;
        }

        public string Reference
        {
            get;
            set;
        }

        public bool IsPartialPayment
        {
            get;
            set;
        }

        public double Fine
        {
            get;
            set;
        }

        public double PartialPayment
        {
            get;
            set;
        }

        public string ReportData
        {
            get;
            set;
        }

        public string Semesters
        {
            get;
            set;
        }

        public string AcademicYears
        {
            get;
            set;
        }

        public int PaymentsReceived
        {
            get;
            set;
        }
    }
}
