﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fees_DBASC.Data.Models
{
    public class Course
    {
        public Course() { }

        public Course(int id, string name, int semesters, DateTime timestamp)
        {
            Id = id;
            Name = name;
            Semesters = semesters;
            Timestamp = timestamp;
        }

        public int Id
        {
            get;
            set;
        }

        public string Name
        {
            get;
            set;
        }

        public int Semesters
        {
            get;
            set;
        }

        public DateTime Timestamp
        {
            get;
            set;
        }

        public int Students
        {
            get;
            set;
        }

        public double Proximity
        {
            get;
            set;
        }

        public int Type
        {
            get;
            set;
        }
    }
}
