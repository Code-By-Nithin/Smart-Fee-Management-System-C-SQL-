﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fees_DBASC.Data.Models
{
    public  class Student
    {
        public Student() { }

        public int Id 
        { 
            get; 
            set; 
        }

        public string SchoolCode
        {
            get;
            set;
        }

        public string Name
        {
            get;
            set;
        }

        public string AcademicYear
        {
            get;
            set;
        }

        public string Standard
        {
            get;
            set;
        }

        public string Division
        {
            get;
            set;
        }

        public string FathersName
        {
            get;
            set;
        }

        public string MothersName
        {
            get;
            set;
        }

        public string Address1
        {
            get;
            set;
        }

        public string Address2
        {
            get;
            set;
        }

        public string City
        {
            get;
            set;
        }

        public string State
        {
            get;
            set;
        }

        public string ZipCode
        {
            get;
            set;
        }

        public string Phone
        {
            get;
            set;
        }

        public string Mobile
        {
            get;
            set;
        }

        public string Email
        {
            get;
            set;
        }

        public int CourseId
        {
            get;
            set;
        }

        public string CourseName
        {
            get;
            set;
        }

        public int CourseType
        {
            get;
            set;
        }

        public int Semesters
        {
            get;
            set;
        }
    }
}
