﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fees_DBASC.Data.Models
{
    public class TransactionModel
    {
        public int StudentId 
        { 
            get; 
            set; 
        }

        public int CourseId
        {
            get;
            set;
        }

        public int Semesters
        {
            get;
            set;
        }

        public string CourseName
        {
            get;
            set;
        }

        public string StudentName
        {
            get;
            set;
        }

        public List<Payment> Transactions
        {
            get;
            set;
        }
    }
}
