﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fees_DBASC.Data.Models
{
    public class FeesData
    {
        public int Id
        {
            get;
            set;
        }

        public List<string> Data
        {
            get;
            set;
        }

        public string CourseName
        {
            get;
            set;
        }

        public string AcademicYear
        {
            get;
            set;
        }

        public int CourseId
        {
            get;
            set;
        }

        public DateTime Date
        {
            get;
            set;
        }

        public int Semesters
        {
            get;
            set;
        }

        public string Json
        {
            get;
            set;
        }

        public bool Active
        {
            get;
            set;
        }
    }
}
