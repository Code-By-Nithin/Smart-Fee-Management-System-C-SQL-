﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fees_DBASC.Data.Models
{
    public class TransactionStatistics
    {
        public TransactionModel TransactionModel 
        { 
            get; 
            set; 
        }

        public List<int> SemestersPaid
        {
            get;
            set;
        }

        public List<int> SemestersNotPaid
        {
            get;
            set;
        }

        public List<int> SemestersPartiallyPaid
        {
            get;
            set;
        }
    }
}
