﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fees_DBASC.Data.Models
{
    public class PaymentStatisticsModel
    {
        public int Id 
        { 
            get;
            set; 
        }

        public string Name 
        { 
            get; 
            set; 
        }

        public string Course
        {
            get;
            set;
        }

        public string SemestersPaid
        {
            get;
            set;
        }

        public string SemestersPartiallyPaid
        {
            get;
            set;
        }

        public int StudentId
        {
            get;
            set;
        }

        public List<double> TotalFees
        {
            get;
            set;
        }
    }
}
