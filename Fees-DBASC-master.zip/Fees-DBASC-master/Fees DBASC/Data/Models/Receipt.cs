﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fees_DBASC.Data.Models
{
    public class Receipt
    {
        public int Id 
        { 
            get; 
            set; 
        }

        public string Name
        {
            get; 
            set;
        }

        public string Course
        {
            get; 
            set;
        }

        public string Bank
        {
            get;
            set;
        }

        public DateTime Date
        {
            get;
            set;
        }

        public string Student
        {
            get; 
            set;
        }

        public double Amount
        {
            get;
            set;
        }

        public string PaymentMethod
        {
            get;
            set;
        }

        public string Towards
        {
            get;
            set;
        }
    }
}
