﻿using NumericWordsConversion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fees_DBASC.Data.Models
{
    public class CurrencyFormat
    {
        public string CurrencyCode 
        { 
            get;
            set; 
        }

        public string CurrencyName 
        {
            get;
            set; 
        }

        public Culture Culture 
        { 
            get; 
            set; 
        }

        public string CurrencyUnit 
        { 
            get; 
            set; 
        }

        public string SubCurrencyUnit 
        { 
            get; 
            set; 
        }
    }
}
