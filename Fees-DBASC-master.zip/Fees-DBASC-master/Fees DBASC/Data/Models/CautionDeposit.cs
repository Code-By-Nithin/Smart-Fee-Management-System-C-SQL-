﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fees_DBASC.Data.Models
{
    public class CautionDeposit
    {
        public Student Student
        {
            get;
            set;
        }

        public bool IsRefunded
        {
            get;
            set;
        }

        public DateTime Date
        {
            get;
            set;
        }

        public string DateString
        {
            get;
            set;
        }
    }
}
