﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fees_DBASC.Data.Models
{
    public class ReportPayments
    {
        public int Id
        {
            get;
            set;
        }

        public string Name
        {
            get;
            set;
        }

        public string Course
        {
            get;
            set;
        }

        public int CourseId
        {
            get;
            set;
        }

        public string Semester
        {
            get;
            set;
        }

        public string AcademicYear
        {
            get;
            set;
        }
    }
}
