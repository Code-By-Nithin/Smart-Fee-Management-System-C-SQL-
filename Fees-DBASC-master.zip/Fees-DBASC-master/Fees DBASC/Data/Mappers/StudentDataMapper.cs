﻿using CsvHelper.Configuration;
using Fees_DBASC.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fees_DBASC.Data.Mappers
{
    public class StudentDataMapper:ClassMap<Student>
    {
        public StudentDataMapper()
        {
            Map(m => m.Id).Name("Student_Id", "Id","id","student_id","student id", "studentid", "StudentId");
            Map(m => m.SchoolCode).Name("School_Code", "school code", "schoolcode", "school_code", "SchoolCode");
            Map(m => m.Name).Name("Student Name", "student_name", "StudentName", "student name", "studentname");
            Map(m => m.AcademicYear).Name("Academic Year", "year", "academic_year", "AcademicYear", "academicyear","Year");
            Map(m => m.Standard).Name("Standard", "standard", "student standard", "StudentStandard", "student_standard");
            Map(m => m.Division).Name("Division", "sivision", "student division", "StudentDivision", "student_division");
            Map(m => m.FathersName).Name("Fathers Name", "FathersName", "fathers name", "fathers_name", "Fathers name");
            Map(m => m.MothersName).Name("Mothers Name", "MothersName", "mothers name", "mothers_name", "Mothers name");
            Map(m => m.Address1).Name("Address Line 1", "AddressLine1", "Address Line1", "address line 1", "address line1", "address_line_1");
            Map(m => m.Address2).Name("Address Line 2", "AddressLine2", "Address Line2", "address line 2", "address line2", "address_line_2");
            Map(m => m.City).Name("City", "city", "Student City", "Student city", "student_city", "StudentCity", "studentcity");
            Map(m => m.State).Name("State", "state", "Student State", "Student state", "student_state", "StudentState", "studentstate");
            Map(m => m.ZipCode).Name("Pin", "pin", "Pin Code", "pin code", "PinCode", "pincode", "pin_code", "Zip", "Zip Code", "zip", "zip_code", "ZipCode");
            Map(m => m.Phone).Name("phone", "Phone", "Ph", "PH", "P.H", "Phone Number", "PhoneNumber", "phone_number", "phonenumber");
            Map(m => m.Mobile).Name("mobile", "Mobile", "Mob", "MOB","Mobile Number","Mobile No.");
            Map(m => m.Email).Name("email", "Email", "Mail", "mail","Mail Id","Email Id","mail_id","email_id");
        }
    }
}
