﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Fees_DBASC.Data.Parsers
{
    public class FeesReportParser
    {
        public FeesReportParser() 
        {
            
        }

        public static string Multiply(string json,int amount)
        {
            var updatedJson = "";
            JsonDocument document = JsonDocument.Parse(json);

            using (MemoryStream stream = new())
            using (Utf8JsonWriter writer = new(stream))
            {
                MultiplyValuesRecursive(document.RootElement, writer, amount);
                writer.Flush();
                stream.Position = 0;
                updatedJson = JsonDocument.Parse(stream).RootElement.ToString();
            }

            return updatedJson;
        }

        private static void MultiplyValuesRecursive(JsonElement element, Utf8JsonWriter writer, int amount)
        {
            switch (element.ValueKind)
            {
                case JsonValueKind.Object:
                    writer.WriteStartObject();

                    foreach (var property in element.EnumerateObject())
                    {
                        if (property.Name == "fees" && property.Value.ValueKind == JsonValueKind.Object)
                        {
                            writer.WritePropertyName(property.Name);
                            writer.WriteStartObject();

                            foreach (var feeProperty in property.Value.EnumerateObject())
                            {
                                if (feeProperty.Value.ValueKind == JsonValueKind.String && IsNumeric(feeProperty.Value.GetString()))
                                {
                                    double currentValue = Convert.ToDouble(feeProperty.Value.GetString());
                                    double multipliedValue = currentValue * amount; 

                                    writer.WritePropertyName(feeProperty.Name);
                                    writer.WriteNumberValue(multipliedValue);
                                }
                                else
                                {
                                    writer.WritePropertyName(feeProperty.Name);
                                    MultiplyValuesRecursive(feeProperty.Value, writer,amount);
                                }
                            }

                            writer.WriteEndObject();
                        }
                        else
                        {
                            writer.WritePropertyName(property.Name);
                            MultiplyValuesRecursive(property.Value, writer, amount);
                        }
                    }

                    writer.WriteEndObject();
                    break;

                case JsonValueKind.Array:
                    writer.WriteStartArray();

                    foreach (var arrayElement in element.EnumerateArray())
                    {
                        MultiplyValuesRecursive(arrayElement, writer, amount);
                    }

                    writer.WriteEndArray();
                    break;

                default:
                    element.WriteTo(writer);
                    break;
            }
        }

        private static bool IsNumeric(string value)
        {
            return double.TryParse(value, out _);

        }

        public static string MergeJson(string json1, string json2)
        {
            var jsonObject1 = JsonSerializer.Deserialize<JsonElement>(json1);
            var jsonObject2 = JsonSerializer.Deserialize<JsonElement>(json2);

            var combinedFees = CombineFees(jsonObject1, jsonObject2);

            string newJson = JsonSerializer.Serialize(combinedFees, new JsonSerializerOptions { WriteIndented = true });
            return newJson;
        }

        static JsonElement CombineFees(JsonElement json1, JsonElement json2)
        {
            var combinedObject = new Dictionary<string, JsonElement>();

            foreach (var property in json1.EnumerateObject())
            {
                var fee = property.Value.GetProperty("fees").GetString();
                var label = property.Value.GetProperty("label").GetString();
                var serialNumber = property.Value.GetProperty("serialNumber").GetString();

                combinedObject[property.Name] = CreateFeeObject(fee, label, serialNumber);
            }

            foreach (var property in json2.EnumerateObject())
            {
                var fee = property.Value.GetProperty("fees").GetString();
                var label = property.Value.GetProperty("label").GetString();
                var serialNumber = property.Value.GetProperty("serialNumber").GetString();

                if (combinedObject.ContainsKey(property.Name))
                {
                    var existingFee = combinedObject[property.Name];
                    var existingFeeValue = existingFee.GetProperty("fees").GetString();
                    int sum = int.Parse(existingFeeValue) + int.Parse(fee);
                    fee = sum.ToString();
                }

                combinedObject[property.Name] = CreateFeeObject(fee, label, serialNumber);
            }

            return JsonDocument.Parse(JsonSerializer.Serialize(combinedObject)).RootElement;
        }

        static JsonElement CreateFeeObject(string fee, string label, string serialNumber)
        {
            var feeObject = new Dictionary<string, JsonElement>
            {
                { "fees", JsonDocument.Parse(JsonSerializer.Serialize(fee)).RootElement },
                { "label", JsonDocument.Parse(JsonSerializer.Serialize(label)).RootElement },
                { "serialNumber", JsonDocument.Parse(JsonSerializer.Serialize(serialNumber)).RootElement }
            };

            return JsonDocument.Parse(JsonSerializer.Serialize(feeObject)).RootElement;
        }
    }
}
