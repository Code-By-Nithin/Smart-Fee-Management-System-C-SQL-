﻿using CommunityToolkit.WinUI.UI.Controls.TextToolbarSymbols;
using Fees_DBASC.Core.Database;
using Fees_DBASC.Core.Exceptions;
using Fees_DBASC.Data.Comparators;
using Fees_DBASC.Data.Models;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Windows.Storage;

namespace Fees_DBASC.Data.Parsers
{
    public class FeesStructureParser
    {
        private readonly StorageFile csvFile;
        private readonly List<FeesData> feesData;

        public FeesStructureParser(StorageFile file)
        {
            csvFile = file;
            feesData = new List<FeesData>();
        }

        public List<FeesData> GetFeesStructureList()
        {
            List<string> data = new();

            if (csvFile != null)
            {
                try
                {
                    using var reader = new StreamReader(csvFile.Path);
                    while (!reader.EndOfStream)
                    {
                        var line = reader.ReadLine();
                        var fields = Regex.Split(line, ",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");

                        if (!fields.All(string.IsNullOrEmpty))
                        {
                            foreach (var field in fields)
                            {
                                var proximity = JaroWinklerDistance.Proximity(field.Replace(",", ""), "DON BOSCO ARTS & SCIENCE COLLEGE ANGADIKADAVU");
                                if (proximity >= 0.9)
                                {
                                    if (data.Count > 0)
                                    {
                                        List<string> feeData = new();
                                        feeData.AddRange(data);

                                        feesData.Add(new FeesData()
                                        {
                                            Data = feeData
                                        });

                                        data.Clear();
                                    }
                                }
                            }
                            data.Add(line);
                        }
                    }

                    // Add the final data
                    feesData.Add(new FeesData()
                    {
                        Data = data
                    });
                }
                catch (Exception)
                {
                    throw;
                }
            }
            return feesData;
        }

        public async Task<List<FeesData>> FillCourseData(List<FeesData> feesData)
        {
            List<Course> courses = new();
            using MySqlConnection connection = new(GlobalDatabaseConfiguration.Url);
            await connection.OpenAsync();

            MySqlCommand courseFetchCommand = connection.CreateCommand();
            courseFetchCommand.CommandText = "SELECT * FROM courses";
            using MySqlDataReader reader = (MySqlDataReader)await courseFetchCommand.ExecuteReaderAsync();
            while (await reader.ReadAsync())
            {
                Course course = new()
                {
                    Id = reader.GetInt32("id"),
                    Name = reader.GetString("name"),
                    Semesters = reader.GetInt32("semesters"),
                    Timestamp = DateTime.Parse(reader.GetString("timestamp"))
                };
                courses.Add(course);
            }

            reader.Close();
            courseFetchCommand.Dispose();

            foreach (var feesStructure in feesData)
            {
                List<string> data = feesStructure.Data;
                var feesStructureDictionary = new Dictionary<string, Dictionary<string, object>>();

                foreach (var line in data)
                {
                    // Academic Details

                    var searchKeyList = new List<string>
                    {
                        "fee structure of",
                        "fees structure of",
                        "fees of",
                        "fee of"
                    };

                    bool containsSubstring = searchKeyList.Any(s => line.Contains(s, StringComparison.OrdinalIgnoreCase));
                    if (containsSubstring)
                    {
                        // Regex patters to fetch Batch year
                        var patternList = new List<string>()
                        {
                            @"\((\d{4}\s*-\s*\d{2}\s*Batch)\)",
                            @"(?<=\()(?<batch>\d{4}\s*-\s*\d{2})\s+Batch(?=\))",
                            @"\((\d{4})\s*-\s*(\d{2})\s*Batch\)",
                            @"(?<=\()\d{4}\s*-\s*\d{2}(?=\s*Batch\))",
                            @"(\d{4})-(\d{2})[^\d]*Batch",
                            @"(\d{4})\D*(\d{2})\D*Batch",
                            @"Batch\D*(\d{2})\D*(\d{4})Batch\D*(\d{2})\D*(\d{4})",
                            @"\b(\d{2}[-]\d{2}\sBatch|\d{4}[-]\d{2}\sBatch)\b"
                        };
                        var courseDetails = line;

                        var match = patternList.Select(pattern => Regex.Match(courseDetails, pattern, RegexOptions.IgnoreCase)).FirstOrDefault(m => m.Success);

                        if (match != null && match.Success)
                        {
                            var batchStr = match.Groups[1].Value;
                            courseDetails = courseDetails.Replace(batchStr, "####");
                            batchStr = batchStr.Replace("Batch", "").Replace("(", "").Replace(")", "").Trim();
                            var batchNumbers = batchStr.Split("-");

                            int startYear = int.Parse(batchNumbers[0]);
                            int endYear = int.Parse(batchNumbers[1]);

                            //feesStructure.AcademicYear = $"{startYear} - {endYear}";
                            //only start year is used
                            feesStructure.AcademicYear = $"{startYear}";

                        }
                        else
                        {
                            throw new UnknownBatchException("Sorry, We're unable to obtain the batch year from the csv file");
                        }

                        // Section to extract course name and save course Id to the object attribute based on proximity
                        // Regex to obtain course name
                        var coursePatternList = new List<string>()
                        {
                            @"(?<=OF\s)(?<course>.*?\(.*?\))(?=\s*\()",
                            @"FEE\S* STRUCTURE\S* OF\s*(?<course>.+?)(?:\s*\(.+?\))?\s*\(\#{4}\)",
                        };

                        var courseMatch = coursePatternList.Select(pattern => Regex.Match(courseDetails, pattern, RegexOptions.IgnoreCase)).FirstOrDefault(m => m.Success);
                        if (courseMatch != null && courseMatch.Success)
                        {
                            var courseStr = courseMatch.Groups[1].Value;

                            foreach (var course in courses)
                            {
                                var expectedCourseName = new string(course.Name.Where(c => Char.IsLetterOrDigit(c)).ToArray()).ToLower();
                                var obtainedCourseName = new string(courseStr.Where(c => Char.IsLetterOrDigit(c)).ToArray()).ToLower();
                                bool isSimilar = string.Compare(expectedCourseName, obtainedCourseName, StringComparison.InvariantCultureIgnoreCase) == 0;
                                bool isSubstring = courseStr.Contains(course.Name);

                                if (isSimilar || isSubstring)
                                {
                                    feesStructure.CourseId = course.Id;
                                    feesStructure.Semesters = course.Semesters;
                                }
                            }

                            if (feesStructure.CourseId == 0)
                            {
                                throw new UnknownCourseException($"Sorry a course named '{courseStr}' does not exist, Please add the course to continue");
                            }
                        }
                        else
                        {
                            throw new CSVParsingException("Sorry, We're unable to parse the csv file, please check it's format and try again");
                        }
                    }
                    //Parsing of Course Name,CourseId and Academic Year is Completed Here


                    // Section to convert each of the course data to json object and store it in data attribute
                    // Ignore first 3 lines, which is the college name,course and batch details and the table header such as slno,particulars etc..

                    int index = data.IndexOf(line);
                    var courseData = line;

                    if (index > 2)
                    {
                        courseData = Regex.Replace(line, @"^.*\btotals*\b.*\r?\n?", "", RegexOptions.IgnoreCase);  // Remove Rows with string TOTAL or total
                        Debug.WriteLine(courseData);
                        if (courseData.Length > 0)
                        {
                            List<string> values = courseData.Split(',').ToList<string>();
                            var serial_no = values[0].Trim();
                            var key = Regex.Replace(values[1], @"[^\w\s]", "").Trim().Replace(" ", "_").ToLower();

                            //check if the serial number indicates a sub category
                            if (serial_no.Contains('(') || serial_no.Contains(')') || !Regex.IsMatch(serial_no, @"^\d+$"))
                            {
                                var item = new Dictionary<string, object>
                                    {
                                        { "serialNumber", values[0] },
                                        { "label", values[1] }
                                    };

                                // Add all semester fees
                                var fees = new Dictionary<string, object>();
                                for (var i = 0; i < feesStructure.Semesters; i++)
                                {
                                    //update fees to 0 if it is blank field
                                    if(values[i + 2] == "")
                                    {
                                        values[i + 2] = "0";
                                    }

                                    // First two lines are skipped
                                    fees.Add($"sem{i + 1}", values[i + 2]);
                                }

                                item.Add("fees", fees);

                                // Since it is a sub category, get last item and update it with subcategory

                                var lastInsertedItem = (Dictionary<string, object>)feesStructureDictionary.Last().Value;
                                // Remove its fees attribute since it is empty
                                lastInsertedItem.Remove("fees");

                                // if last inserted item already has category update it or else add category attribute
                                if (!lastInsertedItem.ContainsKey("categories"))
                                {
                                    lastInsertedItem.Add("categories", new List<object>() { item });
                                }
                                else
                                {
                                    var categories = (List<object>)lastInsertedItem["categories"];
                                    categories.Add(item);
                                }
                            }
                            else
                            {
                                var item = new Dictionary<string, object>() 
                                {
                                    { "serialNumber", values[0] },
                                    { "label", values[1] }
                                };

                                var fees = new Dictionary<string, object>();
                                for (var i = 0; i < feesStructure.Semesters; i++)
                                {
                                    //update fees to 0 if it is blank field
                                    if (values[i + 2] == "")
                                    {
                                        values[i + 2] = "0";
                                    }

                                    // First two lines are skipped
                                    fees.Add($"sem{i + 1}", values[i + 2]);
                                }

                                item.Add("fees", fees);
                                feesStructureDictionary.Add(key, item);
                            }

                        }
                    }
                }
                feesStructure.Json = JsonSerializer.Serialize(feesStructureDictionary);
            }
            return feesData;
        }
    }
}
