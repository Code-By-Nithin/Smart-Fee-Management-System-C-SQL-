﻿using Fees_DBASC.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Fees_DBASC.Data.Parsers
{
    public class JsonParser
    {
        public JsonParser() 
        { 
        
        }

        public string Sort(string json)
        {
            if (json != null)
            {
                Dictionary<string, object> sortedDict = new();
                Dictionary<string, object> feesStructure = JsonSerializer.Deserialize<Dictionary<string, object>>(json);
                List<KeyValuePair<string, object>> feesList = feesStructure.ToList();
                feesList.Sort((x, y) =>
                {
                    var compare1 = JsonSerializer.Deserialize<Dictionary<string, JsonElement>>(x.Value.ToString());
                    var compare2 = JsonSerializer.Deserialize<Dictionary<string, JsonElement>>(y.Value.ToString());

                    if (compare1.TryGetValue("serialNumber", out JsonElement serialNumber1)
                        && compare2.TryGetValue("serialNumber", out JsonElement serialNumber2))
                    {
                        int serialNumber1Value = Convert.ToInt32(serialNumber1.GetString());
                        int serialNumber2Value = Convert.ToInt32(serialNumber2.GetString());

                        return serialNumber1Value.CompareTo(serialNumber2Value);
                    }
                    else
                    {
                        return 0;
                    }
                });
                var dict = feesList.ToDictionary(x => x.Key, x => x.Value);
                return JsonSerializer.Serialize(dict);
            }
            else
            {
                return string.Empty;
            }
        }
    }
}
