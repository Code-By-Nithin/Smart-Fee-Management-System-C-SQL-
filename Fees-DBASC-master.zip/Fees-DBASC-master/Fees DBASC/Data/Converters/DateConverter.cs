﻿using Microsoft.UI.Xaml.Data;
using System;

namespace Fees_DBASC.Data.Converters
{
    public class DateConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, string language)
        {
            if (value is DateTime type)
            {
                return type.ToString("dd-MM-yyyy");
            }
            else
            {
                return "Invalid Date";
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, string language)
        {
            throw new NotImplementedException();
        }
    }
}
